export type OrbState = "idle" | "listening" | "thinking" | "speaking" | "error" | "working";

export type AssistantStatus =
  | "Ready"
  | "Listening"
  | "Thinking"
  | "Speaking"
  | "Working"
  | "Offline"
  | "Error";

export type PersonalityMode =
  | "Friend"
  | "Assistant"
  | "Study"
  | "Coding"
  | "Professional"
  | "Creative"
  | "Custom";

export type LanguageCode = "auto" | "en-US" | "bn-IN" | "hi-IN";

export type TaskStatus = "running" | "completed" | "failed" | "cancelled";

export type PermissionState = "PENDING" | "ALLOWED" | "DENIED";
export type PermissionStatus = PermissionState;

export type ThemeId =
  | "midnight"
  | "aurora"
  | "ocean"
  | "violet"
  | "crimson"
  | "emerald";

export type EmotionTone =
  | "Happy"
  | "Calm"
  | "Excited"
  | "Concerned"
  | "Sad"
  | "Playful"
  | "Neutral"
  | "Thinking"
  | "Celebrating";

export interface PermissionItem {
  id: string;
  name: string;
  description: string;
  status: PermissionStatus;
  required?: boolean;
}

export interface Message {
  id: string;
  role: "user" | "tani";
  content: string;
  timestamp: number;
  image?: string;
  codeBlocks?: {
    language: string;
    code: string;
    isWebsite?: boolean;
  }[];
  toolCall?: {
    name: string;
    arguments: Record<string, any>;
    status: "pending_confirmation" | "executed" | "cancelled" | "failed";
    result?: string;
  };
  confirmationAction?: {
    type: "MESSAGE" | "CALL" | "DELETE" | "ACTION";
    payload?: any;
    question: string;
    confirmLabel: string;
    cancelLabel: string;
    status: "pending" | "confirmed" | "cancelled";
  };
  isError?: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: number;
  messages: Message[];
}

export interface BackgroundTask {
  id: string;
  title: string;
  status: TaskStatus;
  progress: number; // 0 - 100
  createdTime: number;
  completedTime?: number;
  result?: string;
  codeOutput?: {
    language: string;
    code: string;
    htmlPreview?: string;
  };
  error?: string;
}

export interface PersonalityConfig {
  mode: PersonalityMode;
  tone: "warm" | "balanced" | "concise" | "technical";
  responseLength: "concise" | "normal" | "detailed";
  language: LanguageCode;
  friendliness: number; // 1-5
  technicalDepth: number; // 1-5
}

export interface UserPreferences {
  userName: string;
  profilePhoto?: string;
  onboardingCompleted: boolean;
  apiKey: string;
  hasCustomApiKey: boolean;
  personality: PersonalityConfig;
  voiceEnabled: boolean;
  voiceSpeed: number; // 0.8 - 1.5
  autoSpeak: boolean;
  wakeWordEnabled: boolean;
  backgroundAssistant: boolean;
  continuousVoice: boolean;
  floatingAssistantEnabled: boolean;
  proactiveAssistant: boolean;
  theme: ThemeId;
  darkMode: boolean;
  glowEffect: boolean;
  ambientGlowEnabled: boolean;
  ambientGlowIntensity: "low" | "medium" | "high";
  animationIntensity: "low" | "medium" | "high";
  appLockEnabled: boolean;
  pinCode: string;
  biometricEnabled: boolean;
  emotionTone: EmotionTone;
}

export interface ReminderItem {
  id: string;
  title: string;
  time: string;
  timestamp: number;
  completed: boolean;
}

export interface TimerItem {
  id: string;
  title: string;
  totalSeconds: number;
  remainingSeconds: number;
  isRunning: boolean;
}

export interface ContactItem {
  id: string;
  name: string;
  phone: string;
  email: string;
}

export interface ConfirmationState {
  isOpen: boolean;
  title?: string;
  description?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  isDestructive?: boolean;
  onConfirm?: () => void;
  onCancel?: () => void;
}

export interface MemoryItem {
  id: string;
  content: string;
  category?: string;
  timestamp: number;
}

export interface ProactiveAlert {
  id: string;
  title: string;
  message: string;
  timestamp: number;
  type: "timer" | "task" | "reminder" | "status";
  read?: boolean;
}

export interface AndroidProjectFile {
  path: string;
  language: "kotlin" | "xml" | "groovy" | "json" | "markdown";
  description: string;
  content: string;
}

export type DetectedLanguage = "bn" | "en" | "hi" | "bn-en" | "hi-en" | "mixed";

export type ConversationalTurnState =
  | "IDLE"
  | "USER_SPEAKING"
  | "USER_PAUSED"
  | "WAITING_FOR_COMPLETION"
  | "TANI_THINKING"
  | "TANI_SPEAKING";

export interface ResolvedEntity {
  name: string;
  type: "contact" | "app" | "ui_element" | "search_query" | "url" | "number" | "topic";
  originalText?: string;
  confidence: number;
}

export interface ConversationTurnContext {
  id: string;
  timestamp: number;
  modality: "voice" | "text";
  role: "user" | "tani";
  content: string;
  language: DetectedLanguage;
  intent?: string;
  activeApp?: string;
  toolResult?: any;
}

export interface MultiStepPlanStep {
  id: string;
  description: string;
  tool: string;
  args: Record<string, any>;
  status: "pending" | "executing" | "verified" | "failed";
  verificationExpected?: string;
  result?: string;
}

export interface ActionVerification {
  verified: boolean;
  message: string;
  details?: Record<string, any>;
}

export type ActionRiskLevel = "LOW" | "MEDIUM" | "HIGH";

export type AndroidActionType =
  | "OPEN_APP"
  | "CLOSE_APP"
  | "NAVIGATE_HOME"
  | "NAVIGATE_BACK"
  | "RECENT_APPS"
  | "TAP_ELEMENT"
  | "LONG_PRESS"
  | "SCROLL"
  | "SWIPE"
  | "TYPE_TEXT"
  | "READ_ACCESSIBILITY_UI"
  | "FIND_UI_ELEMENT"
  | "OPEN_SETTINGS"
  | "MEDIA_CONTROL"
  | "SEND_MESSAGE"
  | "MAKE_CALL"
  | "DELETE_ITEM";

export interface StructuredAndroidAction {
  action: AndroidActionType;
  target?: string;
  direction?: "UP" | "DOWN" | "LEFT" | "RIGHT";
  text?: string;
  appName?: string;
  packageName?: string;
  riskLevel: ActionRiskLevel;
  confirmation: boolean;
  confirmationQuestion?: string;
  params?: Record<string, any>;
}

export interface CommunicationMessagePayload {
  contactName: string;
  phoneNumber?: string;
  platform: "WhatsApp" | "SMS" | "Telegram" | "Default";
  messageText: string;
  confirmed: boolean;
}

export interface CallPayload {
  contactName: string;
  phoneNumber?: string;
  confirmed: boolean;
}

export interface DeletePayload {
  targetItem: string;
  itemType: "photo" | "file" | "message" | "item";
  confirmed: boolean;
}

export interface AndroidBridgeStatus {
  isNativeBridgeConnected: boolean;
  bridgeType: "NATIVE_ANDROID_ACCESSIBILITY" | "SIMULATED_PREVIEW_BRIDGE";
  accessibilityServiceEnabled: boolean;
  currentPackage: string;
  supportedActions: string[];
}
