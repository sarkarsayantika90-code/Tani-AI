export const GEMINI_MODELS = {
  TEXT: "gemini-3.8-flash",
  FALLBACK_TEXT: "gemini-3.6-flash",
  LIVE: "gemini-3.8-live",
} as const;

export const TANI_ASSISTANT_INFO = {
  name: "Tani",
  title: "Tani AI",
  creator: "Made by Anik",
  supportEmail: "anikmondal8680@gmail.com",
  defaultVoice: "Aoede", // Warm, clear, natural assistant voice
};
