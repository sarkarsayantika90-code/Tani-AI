import React, { useState } from "react";
import { BackgroundTask } from "../types";
import {
  Activity,
  CheckCircle2,
  XCircle,
  Clock,
  ExternalLink,
  Code2,
  Trash2,
  Play,
  RotateCcw,
} from "lucide-react";

interface TasksViewProps {
  tasks: BackgroundTask[];
  onClearTasks: () => void;
  onCancelTask: (taskId: string) => void;
  onRetryTask: (taskId: string) => void;
}

export const TasksView: React.FC<TasksViewProps> = ({
  tasks,
  onClearTasks,
  onCancelTask,
  onRetryTask,
}) => {
  const [filter, setFilter] = useState<"all" | "running" | "completed" | "failed">("all");
  const [previewHtml, setPreviewHtml] = useState<string | null>(null);

  const filteredTasks = tasks.filter((t) => {
    if (filter === "all") return true;
    return t.status === filter;
  });

  return (
    <div id="tani-tasks-view" className="flex-1 w-full overflow-y-auto px-4 py-4 space-y-4">
      {/* Header & Filter Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-white/10">
        <div>
          <h2 className="text-lg font-bold text-white tracking-wide">Background Tasks</h2>
          <p className="text-xs text-gray-400">
            WorkManager & asynchronous task processing pipeline
          </p>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {(["all", "running", "completed", "failed"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-3 py-1 rounded-xl text-xs font-semibold capitalize transition-all cursor-pointer ${
                filter === tab
                  ? "bg-purple-600 text-white shadow-sm"
                  : "bg-white/[0.05] hover:bg-white/[0.1] text-gray-400 hover:text-white"
              }`}
            >
              {tab}
            </button>
          ))}
          {tasks.length > 0 && (
            <button
              onClick={onClearTasks}
              title="Clear all tasks"
              className="p-1.5 ml-1 rounded-xl bg-white/[0.05] hover:bg-rose-500/20 text-gray-400 hover:text-rose-300 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Empty State */}
      {filteredTasks.length === 0 && (
        <div className="flex flex-col items-center justify-center h-64 text-center text-gray-400 space-y-2">
          <Activity className="w-8 h-8 text-purple-400/50" />
          <p className="text-sm font-medium text-gray-300">No tasks in this category</p>
          <p className="text-xs text-gray-500 max-w-xs">
            Ask Tani to build a website, compile an algorithm, or run background analysis to trigger tasks.
          </p>
        </div>
      )}

      {/* Tasks List */}
      <div className="space-y-3">
        {filteredTasks.map((task) => {
          const isRunning = task.status === "running";
          const isCompleted = task.status === "completed";
          const isFailed = task.status === "failed";

          return (
            <div
              key={task.id}
              className="rounded-2xl p-4 bg-[#111420]/80 border border-white/10 shadow-lg backdrop-blur-md space-y-3 transition-all"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div
                    className={`p-2 rounded-xl shrink-0 ${
                      isRunning
                        ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                        : isCompleted
                        ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                        : isFailed
                        ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                        : "bg-gray-500/20 text-gray-400"
                    }`}
                  >
                    {isRunning ? (
                      <Activity className="w-4 h-4 animate-spin" />
                    ) : isCompleted ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : isFailed ? (
                      <XCircle className="w-4 h-4" />
                    ) : (
                      <Clock className="w-4 h-4" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white tracking-wide">
                      {task.title}
                    </h3>
                    <span className="text-[11px] font-mono text-purple-300/70">
                      ID: {task.id}
                    </span>
                  </div>
                </div>

                {/* Status Badge */}
                <span
                  className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider ${
                    isRunning
                      ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30"
                      : isCompleted
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                      : isFailed
                      ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                      : "bg-gray-500/20 text-gray-300"
                  }`}
                >
                  {task.status}
                </span>
              </div>

              {/* Progress bar */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs text-gray-400">
                  <span>{isRunning ? "Task in progress..." : task.status}</span>
                  <span className="font-mono">{task.progress}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-white/[0.08] overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      isRunning
                        ? "bg-gradient-to-r from-cyan-500 to-purple-500 animate-pulse"
                        : isCompleted
                        ? "bg-emerald-500"
                        : isFailed
                        ? "bg-rose-500"
                        : "bg-gray-500"
                    }`}
                    style={{ width: `${task.progress}%` }}
                  />
                </div>
              </div>

              {/* Result or Error info */}
              {task.result && (
                <div className="p-2.5 rounded-xl bg-white/[0.04] border border-white/5 text-xs text-gray-300">
                  <span className="font-medium text-purple-300">Outcome:</span> {task.result}
                </div>
              )}

              {task.error && (
                <div className="p-2.5 rounded-xl bg-rose-950/40 border border-rose-800/40 text-xs text-rose-300">
                  <span className="font-medium text-rose-400">Error:</span> {task.error}
                </div>
              )}

              {/* Actions */}
              <div className="flex items-center justify-between pt-1 text-xs text-gray-400">
                <span>
                  {new Date(task.createdTime).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>

                <div className="flex items-center gap-2">
                  {task.codeOutput?.htmlPreview && (
                    <button
                      onClick={() => setPreviewHtml(task.codeOutput!.htmlPreview!)}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 transition-colors"
                    >
                      <ExternalLink className="w-3 h-3" />
                      <span>Preview Website</span>
                    </button>
                  )}
                  {isRunning && (
                    <button
                      onClick={() => onCancelTask(task.id)}
                      className="px-2.5 py-1 rounded-lg bg-white/[0.06] hover:bg-rose-500/20 text-rose-300 transition-colors"
                    >
                      Cancel
                    </button>
                  )}
                  {isFailed && (
                    <button
                      onClick={() => onRetryTask(task.id)}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 transition-colors"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Retry</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Website Preview modal */}
      {previewHtml && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
          <div className="w-full max-w-3xl h-[80vh] rounded-3xl bg-[#111420] border border-white/15 flex flex-col overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between px-4 py-3 bg-white/[0.04] border-b border-white/10">
              <div className="flex items-center gap-2 text-sm font-semibold text-white">
                <ExternalLink className="w-4 h-4 text-purple-400" />
                <span>Task Website Output</span>
              </div>
              <button
                onClick={() => setPreviewHtml(null)}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-gray-300"
              >
                Close
              </button>
            </div>
            <iframe
              title="Task Preview"
              srcDoc={previewHtml}
              className="w-full h-full border-0 bg-white"
              sandbox="allow-scripts allow-modals allow-forms"
            />
          </div>
        </div>
      )}
    </div>
  );
};
