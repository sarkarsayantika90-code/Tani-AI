import React, { useState, useRef } from "react";
import {
  UserPreferences,
  PersonalityMode,
  LanguageCode,
  ThemeId,
  EmotionTone,
} from "../types";
import { AiService } from "../services/aiService";
import {
  User,
  Cpu,
  Mic,
  Shield,
  Palette,
  Database,
  Info,
  Key,
  Eye,
  EyeOff,
  Check,
  AlertCircle,
  RefreshCw,
  Trash2,
  Smartphone,
  Camera,
  Upload,
  Sparkles,
} from "lucide-react";

interface SettingsViewProps {
  preferences: UserPreferences;
  onUpdatePreferences: (prefs: Partial<UserPreferences>) => void;
  onClearMemory: () => void;
  onClearAllData: () => void;
  onOpenAbout: () => void;
  onOpenPermissions: () => void;
  onOpenAndroidCode: () => void;
}

const THEMES: { id: ThemeId; name: string; previewColor: string }[] = [
  { id: "midnight", name: "Midnight", previewColor: "#06b6d4" },
  { id: "aurora", name: "Aurora", previewColor: "#10b981" },
  { id: "ocean", name: "Ocean", previewColor: "#0ea5e9" },
  { id: "violet", name: "Violet", previewColor: "#a855f7" },
  { id: "crimson", name: "Crimson", previewColor: "#f43f5e" },
  { id: "emerald", name: "Emerald", previewColor: "#059669" },
];

const EMOTIONS: EmotionTone[] = [
  "Neutral",
  "Calm",
  "Happy",
  "Excited",
  "Playful",
  "Thinking",
  "Concerned",
  "Celebrating",
];

export const SettingsView: React.FC<SettingsViewProps> = ({
  preferences,
  onUpdatePreferences,
  onClearMemory,
  onClearAllData,
  onOpenAbout,
  onOpenPermissions,
  onOpenAndroidCode,
}) => {
  const [apiKeyInput, setApiKeyInput] = useState(preferences.apiKey || "");
  const [showApiKey, setShowApiKey] = useState(false);
  const [testResult, setTestResult] = useState<{
    status: "idle" | "testing" | "success" | "error";
    message: string;
  }>({ status: "idle", message: "" });
  const [userNameInput, setUserNameInput] = useState(preferences.userName);

  const [pinInput, setPinInput] = useState(preferences.pinCode || "");
  const [pinMessage, setPinMessage] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === "string") {
          onUpdatePreferences({ profilePhoto: reader.result });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveApiKey = () => {
    onUpdatePreferences({
      apiKey: apiKeyInput.trim(),
      hasCustomApiKey: !!apiKeyInput.trim(),
    });
    setTestResult({
      status: "success",
      message: apiKeyInput.trim()
        ? "API key saved securely in Keystore."
        : "Reverted to backend default key.",
    });
  };

  const handleRemoveApiKey = () => {
    setApiKeyInput("");
    onUpdatePreferences({ apiKey: "", hasCustomApiKey: false });
    setTestResult({ status: "idle", message: "Custom key removed." });
  };

  const handleTestConnection = async () => {
    setTestResult({ status: "testing", message: "Connecting to Gemini 3.8-flash..." });
    const res = await AiService.testApiKey(apiKeyInput.trim() || undefined);
    if (res.success) {
      setTestResult({ status: "success", message: res.message });
    } else {
      setTestResult({ status: "error", message: res.message });
    }
  };

  const handleSaveUserName = () => {
    if (userNameInput.trim()) {
      onUpdatePreferences({ userName: userNameInput.trim() });
    }
  };

  const handleSavePin = () => {
    if (pinInput.trim().length >= 4) {
      onUpdatePreferences({ pinCode: pinInput.trim(), appLockEnabled: true });
      setPinMessage("PIN successfully configured & App Lock active.");
    } else {
      setPinMessage("PIN must be at least 4 digits.");
    }
  };

  return (
    <div
      id="tani-settings-view"
      className="flex-1 w-full overflow-y-auto px-4 py-4 space-y-6 select-none"
    >
      <div className="flex items-center justify-between pb-2 border-b border-white/10">
        <div>
          <h2 className="text-xl font-bold text-white tracking-wide">Settings</h2>
          <p className="text-xs text-gray-400">Configure Tani AI preferences & integrations</p>
        </div>
        <button
          onClick={onOpenAndroidCode}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-200 text-xs font-semibold border border-cyan-500/30 transition-colors"
        >
          <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
          <span>Android Source</span>
        </button>
      </div>

      {/* 1. PROFILE & ENERGY RING PHOTO */}
      <div className="rounded-3xl bg-[#111420]/80 border border-white/10 p-5 space-y-4 shadow-lg backdrop-blur-md">
        <div className="flex items-center gap-2 text-sm font-semibold text-cyan-300">
          <User className="w-4 h-4" />
          <span>PROFILE & PERSONALIZATION</span>
        </div>

        <div className="space-y-4">
          {/* Photo inside Energy Ring */}
          <div className="flex items-center gap-4">
            <div className="relative w-16 h-16 rounded-full flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border border-cyan-400/50 animate-pulse" />
              <div className="relative w-14 h-14 rounded-full overflow-hidden bg-[#131824] flex items-center justify-center border border-white/15">
                {preferences.profilePhoto ? (
                  <img
                    src={preferences.profilePhoto}
                    alt="Profile"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-6 h-6 text-gray-500" />
                )}
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-white">Energy Ring Photo</p>
              <p className="text-xs text-gray-400">
                Displays in the center of the Energy Ring on the home dashboard.
              </p>
              <div className="mt-2 flex items-center gap-2">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-medium border border-cyan-500/30 transition-colors cursor-pointer"
                >
                  <Upload className="w-3 h-3" />
                  <span>{preferences.profilePhoto ? "Change" : "Add Photo"}</span>
                </button>
                {preferences.profilePhoto && (
                  <button
                    onClick={() => onUpdatePreferences({ profilePhoto: "" })}
                    className="px-3 py-1 rounded-xl bg-white/5 hover:bg-rose-500/20 text-gray-400 hover:text-rose-300 text-xs transition-colors cursor-pointer"
                  >
                    Remove
                  </button>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoSelect}
                  className="hidden"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs text-gray-400 mb-1">User Name</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={userNameInput}
                onChange={(e) => setUserNameInput(e.target.value)}
                placeholder="What should Tani call you?"
                className="flex-1 px-3.5 py-2.5 rounded-xl bg-white/[0.06] border border-white/10 text-sm text-white focus:outline-none focus:border-cyan-400"
              />
              <button
                onClick={handleSaveUserName}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-xs font-semibold text-black transition-colors"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 2. THEME SYSTEM & APPEARANCE */}
      <div className="rounded-3xl bg-[#111420]/80 border border-white/10 p-5 space-y-4 shadow-lg backdrop-blur-md">
        <div className="flex items-center gap-2 text-sm font-semibold text-cyan-300">
          <Palette className="w-4 h-4" />
          <span>APPEARANCE & THEMES</span>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs text-gray-400 mb-2">Select Theme</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {THEMES.map((th) => {
                const isSelected = (preferences.theme || "midnight") === th.id;
                return (
                  <button
                    key={th.id}
                    onClick={() => onUpdatePreferences({ theme: th.id })}
                    className={`flex items-center justify-between p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? "bg-white/[0.09] border-cyan-400/70 shadow-sm"
                        : "bg-white/[0.03] border-white/5 hover:bg-white/[0.06]"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: th.previewColor }}
                      />
                      <span className="text-xs font-semibold text-gray-200">{th.name}</span>
                    </div>
                    {isSelected && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Ambient RGB Edge Lighting */}
          <div className="pt-2 border-t border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-white">Ambient RGB Edge Lighting</p>
                <p className="text-xs text-gray-400">
                  Dynamic screen edge aura responding to assistant state
                </p>
              </div>
              <input
                type="checkbox"
                checked={preferences.ambientGlowEnabled}
                onChange={(e) => onUpdatePreferences({ ambientGlowEnabled: e.target.checked })}
                className="w-4 h-4 accent-cyan-400 cursor-pointer"
              />
            </div>

            {preferences.ambientGlowEnabled && (
              <div className="flex items-center gap-2 pt-1">
                <span className="text-xs text-gray-400">Intensity:</span>
                {(["low", "medium", "high"] as const).map((level) => (
                  <button
                    key={level}
                    onClick={() => onUpdatePreferences({ ambientGlowIntensity: level })}
                    className={`px-3 py-1 rounded-lg text-xs capitalize transition-colors cursor-pointer ${
                      preferences.ambientGlowIntensity === level
                        ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                        : "bg-white/5 text-gray-400 hover:bg-white/10"
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Conversational Tone / Emotion */}
          <div className="pt-2 border-t border-white/10">
            <label className="block text-xs text-gray-400 mb-2">
              Conversational Tone & Emotion
            </label>
            <div className="flex flex-wrap gap-2">
              {EMOTIONS.map((emo) => {
                const isSelected = (preferences.emotionTone || "Neutral") === emo;
                return (
                  <button
                    key={emo}
                    onClick={() => onUpdatePreferences({ emotionTone: emo })}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                      isSelected
                        ? "bg-cyan-500/20 text-cyan-300 border border-cyan-400/50"
                        : "bg-white/[0.04] text-gray-400 hover:bg-white/[0.08]"
                    }`}
                  >
                    {emo}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* 3. VOICE & CONTINUOUS CONVERSATION */}
      <div className="rounded-3xl bg-[#111420]/80 border border-white/10 p-5 space-y-4 shadow-lg backdrop-blur-md">
        <div className="flex items-center gap-2 text-sm font-semibold text-cyan-300">
          <Mic className="w-4 h-4" />
          <span>VOICE & ASSISTANT MODES</span>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white">Continuous Conversation</p>
              <p className="text-xs text-gray-400">
                Automatically listen after Tani speaks without pressing mic again
              </p>
            </div>
            <input
              type="checkbox"
              checked={preferences.continuousVoice}
              onChange={(e) => onUpdatePreferences({ continuousVoice: e.target.checked })}
              className="w-4 h-4 accent-cyan-400 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white">Proactive Assistant</p>
              <p className="text-xs text-gray-400">
                Alert aloud when timers finish or background tasks complete
              </p>
            </div>
            <input
              type="checkbox"
              checked={preferences.proactiveAssistant}
              onChange={(e) => onUpdatePreferences({ proactiveAssistant: e.target.checked })}
              className="w-4 h-4 accent-cyan-400 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white">Floating Assistant Overlay</p>
              <p className="text-xs text-gray-400">
                Show mini energy-ring quick trigger button on screen
              </p>
            </div>
            <input
              type="checkbox"
              checked={preferences.floatingAssistantEnabled}
              onChange={(e) =>
                onUpdatePreferences({ floatingAssistantEnabled: e.target.checked })
              }
              className="w-4 h-4 accent-cyan-400 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white">Voice Response</p>
              <p className="text-xs text-gray-400">Speak AI responses aloud</p>
            </div>
            <input
              type="checkbox"
              checked={preferences.voiceEnabled}
              onChange={(e) => onUpdatePreferences({ voiceEnabled: e.target.checked })}
              className="w-4 h-4 accent-cyan-400 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white">Auto Speak</p>
              <p className="text-xs text-gray-400">Speak immediately upon response arrival</p>
            </div>
            <input
              type="checkbox"
              checked={preferences.autoSpeak}
              onChange={(e) => onUpdatePreferences({ autoSpeak: e.target.checked })}
              className="w-4 h-4 accent-cyan-400 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
              <span>Voice Speed</span>
              <span>{preferences.voiceSpeed}x</span>
            </div>
            <input
              type="range"
              min="0.8"
              max="1.5"
              step="0.1"
              value={preferences.voiceSpeed}
              onChange={(e) =>
                onUpdatePreferences({ voiceSpeed: parseFloat(e.target.value) })
              }
              className="w-full accent-cyan-400 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* 4. AI CONFIGURATION */}
      <div className="rounded-3xl bg-[#111420]/80 border border-white/10 p-5 space-y-4 shadow-lg backdrop-blur-md">
        <div className="flex items-center gap-2 text-sm font-semibold text-cyan-300">
          <Cpu className="w-4 h-4" />
          <span>AI & GEMINI CONFIGURATION</span>
        </div>

        <div className="space-y-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs text-gray-400">Gemini API Key</label>
              {preferences.hasCustomApiKey && (
                <span className="text-[10px] text-cyan-400">Custom Key Active</span>
              )}
            </div>
            <div className="relative">
              <input
                type={showApiKey ? "text" : "password"}
                value={apiKeyInput}
                onChange={(e) => setApiKeyInput(e.target.value)}
                placeholder="Server default key active"
                className="w-full pl-10 pr-24 py-2.5 rounded-xl bg-white/[0.06] border border-white/10 text-sm text-white focus:outline-none focus:border-cyan-400 select-text"
              />
              <Key className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
              <button
                type="button"
                onClick={() => setShowApiKey(!showApiKey)}
                className="absolute right-3 top-3 text-gray-400 hover:text-white"
              >
                {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveApiKey}
              className="flex-1 py-2 px-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-xs font-semibold text-black transition-colors"
            >
              Save Key
            </button>
            <button
              onClick={handleTestConnection}
              disabled={testResult.status === "testing"}
              className="flex-1 py-2 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition-colors flex items-center justify-center gap-1.5"
            >
              {testResult.status === "testing" ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <span>Test Connection</span>
              )}
            </button>
            {preferences.hasCustomApiKey && (
              <button
                onClick={handleRemoveApiKey}
                className="p-2 rounded-xl bg-rose-600/30 hover:bg-rose-600/50 text-rose-300"
                title="Remove Custom Key"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>

          {testResult.message && (
            <div
              className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                testResult.status === "success"
                  ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                  : testResult.status === "error"
                  ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                  : "bg-cyan-500/20 text-cyan-300"
              }`}
            >
              {testResult.status === "success" ? (
                <Check className="w-4 h-4 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              <span>{testResult.message}</span>
            </div>
          )}

          {/* Language Selection */}
          <div className="pt-2">
            <label className="block text-xs text-gray-400 mb-1">Language</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { code: "auto", label: "Auto Detect" },
                { code: "bn-IN", label: "বাংলা (Bengali)" },
                { code: "hi-IN", label: "हिन्दी (Hindi)" },
                { code: "en-US", label: "English" },
              ].map((lang) => (
                <button
                  key={lang.code}
                  onClick={() =>
                    onUpdatePreferences({
                      personality: {
                        ...preferences.personality,
                        language: lang.code as LanguageCode,
                      },
                    })
                  }
                  className={`py-2 px-3 rounded-xl text-xs font-semibold transition-all ${
                    preferences.personality.language === lang.code
                      ? "bg-cyan-500 text-black font-bold shadow-md"
                      : "bg-white/[0.05] text-gray-300 hover:bg-white/[0.1]"
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 5. SECURITY & APP LOCK */}
      <div className="rounded-3xl bg-[#111420]/80 border border-white/10 p-5 space-y-4 shadow-lg backdrop-blur-md">
        <div className="flex items-center gap-2 text-sm font-semibold text-cyan-300">
          <Shield className="w-4 h-4" />
          <span>SECURITY & PRIVACY</span>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white">App Lock</p>
              <p className="text-xs text-gray-400">Require PIN or Biometrics on launch</p>
            </div>
            <input
              type="checkbox"
              checked={preferences.appLockEnabled}
              onChange={(e) => onUpdatePreferences({ appLockEnabled: e.target.checked })}
              className="w-4 h-4 accent-cyan-400 cursor-pointer"
            />
          </div>

          <div>
            <label className="block text-xs text-gray-400 mb-1">Set PIN (4-6 digits)</label>
            <div className="flex gap-2">
              <input
                type="password"
                maxLength={6}
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                placeholder="Enter PIN code"
                className="flex-1 px-3.5 py-2.5 rounded-xl bg-white/[0.06] border border-white/10 text-sm text-white focus:outline-none focus:border-cyan-400"
              />
              <button
                onClick={handleSavePin}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-xs font-semibold text-black transition-colors"
              >
                Set PIN
              </button>
            </div>
            {pinMessage && <p className="text-xs text-emerald-400 mt-1">{pinMessage}</p>}
          </div>
        </div>
      </div>

      {/* 6. DATA MANAGEMENT */}
      <div className="rounded-3xl bg-[#111420]/80 border border-white/10 p-5 space-y-4 shadow-lg backdrop-blur-md">
        <div className="flex items-center gap-2 text-sm font-semibold text-cyan-300">
          <Database className="w-4 h-4" />
          <span>DATA & MEMORY</span>
        </div>

        <div className="space-y-2.5">
          <div className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.03] border border-white/5">
            <div>
              <p className="text-sm font-medium text-white">Device Permissions</p>
              <p className="text-xs text-gray-400">Microphone, Camera, Location, Contacts</p>
            </div>
            <button
              onClick={onOpenPermissions}
              className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-cyan-300"
            >
              Review
            </button>
          </div>

          <div className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.03] border border-white/5">
            <div>
              <p className="text-sm font-medium text-white">Clear Assistant Memory</p>
              <p className="text-xs text-gray-400">Resets personalized long-term memory notes</p>
            </div>
            <button
              onClick={onClearMemory}
              className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-rose-500/20 text-xs font-semibold text-rose-300"
            >
              Clear Memory
            </button>
          </div>

          <div className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.03] border border-white/5">
            <div>
              <p className="text-sm font-medium text-white">Reset All App Data</p>
              <p className="text-xs text-gray-400">Deletes conversations, tasks, and credentials</p>
            </div>
            <button
              onClick={onClearAllData}
              className="px-3 py-1.5 rounded-xl bg-rose-600/30 hover:bg-rose-600 text-xs font-semibold text-rose-200"
            >
              Reset All Data
            </button>
          </div>
        </div>
      </div>

      {/* 7. ABOUT & SUPPORT */}
      <div className="rounded-3xl bg-[#111420]/80 border border-white/10 p-5 space-y-3 shadow-lg backdrop-blur-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-semibold text-cyan-300">
            <Info className="w-4 h-4" />
            <span>ABOUT TANI AI</span>
          </div>
          <button
            onClick={onOpenAbout}
            className="text-xs text-cyan-400 hover:text-cyan-300 underline"
          >
            View Details
          </button>
        </div>

        <p className="text-xs text-gray-300 leading-relaxed">
          Tani AI is a premium dark futuristic personal assistant created by Anik.
        </p>
        <div className="text-xs text-gray-400 flex items-center justify-between pt-1">
          <span>Version 1.0.0</span>
          <span>Made by Anik</span>
        </div>
        <p className="text-[11px] text-gray-500">Support: anikmondal8680@gmail.com</p>
      </div>
    </div>
  );
};
