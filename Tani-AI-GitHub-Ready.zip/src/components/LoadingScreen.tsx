import React, { useEffect } from "react";
import { TaniOrb } from "./TaniOrb";

interface LoadingScreenProps {
  onFinish: () => void;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onFinish }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onFinish();
    }, 2400);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div
      id="tani-loading-screen"
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#07090e] text-white px-6 select-none overflow-hidden"
    >
      {/* Background ambient gradient glow */}
      <div className="absolute w-96 h-96 rounded-full bg-purple-600/20 blur-[120px] pointer-events-none" />
      <div className="absolute w-80 h-80 rounded-full bg-cyan-500/15 blur-[100px] pointer-events-none translate-y-24" />

      {/* Center glowing orb */}
      <div className="mb-8 transform scale-95 sm:scale-105 transition-transform duration-1000">
        <TaniOrb state="thinking" size="md" />
      </div>

      {/* Title and subtitle */}
      <div className="text-center space-y-2 z-10">
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-purple-200 via-white to-pink-200 drop-shadow-md">
          TANI AI
        </h1>
        <p className="text-sm sm:text-base text-purple-200/70 font-light tracking-wide">
          Your personal AI companion
        </p>
      </div>

      {/* Subtle loader bar */}
      <div className="mt-8 w-48 h-1 bg-white/10 rounded-full overflow-hidden">
        <div className="w-full h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 animate-[pulse_1.2s_ease-in-out_infinite]" />
      </div>

      <div className="absolute bottom-6 text-xs text-gray-500 font-medium">
        Made by Anik
      </div>
    </div>
  );
};
