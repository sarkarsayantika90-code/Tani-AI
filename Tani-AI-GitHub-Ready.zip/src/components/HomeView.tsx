import React, { useState, useRef, useEffect } from "react";
import { OrbState, ThemeId } from "../types";
import { TaniEnergyRing } from "./TaniEnergyRing";
import {
  Mic,
  MicOff,
  Send,
  Image as ImageIcon,
  Menu,
  Bell,
  User,
  X,
  VolumeX,
  CloudSun,
  Timer as TimerIcon,
  BookOpen,
  Code2,
  Sparkles,
  FileText,
  AlertTriangle,
  RefreshCw,
  Sliders,
  Square,
  Radio,
} from "lucide-react";

interface HomeViewProps {
  orbState: OrbState;
  userName: string;
  profilePhoto?: string;
  theme?: ThemeId;
  unreadAlertsCount?: number;
  continuousVoice?: boolean;
  onToggleContinuousVoice?: () => void;
  audioLevel?: number;
  liveTranscript?: { user?: string; tani?: string };
  onSendMessage: (text: string, image?: { data: string; mimeType: string }) => void;
  onStartVoice: () => void;
  onStopVoice: () => void;
  onStopSpeaking: () => void;
  onOpenMenu: () => void;
  onOpenAlerts: () => void;
  onOpenProfile: () => void;
  onOpenChat: () => void;
  onOpenMemory: () => void;
  onOpenSettings: () => void;
  onStartQuickTimer?: (minutes: number) => void;
  errorMessage?: string | null;
  onClearError?: () => void;
  permissionDenied?: boolean;
  onClosePermissionDialog?: () => void;
  onRetryVoice?: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  orbState,
  userName,
  profilePhoto,
  theme = "midnight",
  unreadAlertsCount = 0,
  continuousVoice = false,
  onToggleContinuousVoice,
  audioLevel = 0,
  liveTranscript,
  onSendMessage,
  onStartVoice,
  onStopVoice,
  onStopSpeaking,
  onOpenMenu,
  onOpenAlerts,
  onOpenProfile,
  onOpenChat,
  onOpenMemory,
  onOpenSettings,
  onStartQuickTimer,
  errorMessage,
  onClearError,
  permissionDenied = false,
  onClosePermissionDialog,
  onRetryVoice,
}) => {
  const [inputText, setInputText] = useState("");
  const [selectedImage, setSelectedImage] = useState<{
    data: string;
    mimeType: string;
    previewUrl: string;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Dynamic time greeting
  const [timeGreeting, setTimeGreeting] = useState("Good day");
  useEffect(() => {
    const updateGreeting = () => {
      const hour = new Date().getHours();
      if (hour >= 5 && hour < 12) setTimeGreeting("Good morning");
      else if (hour >= 12 && hour < 17) setTimeGreeting("Good afternoon");
      else if (hour >= 17 && hour < 22) setTimeGreeting("Good evening");
      else setTimeGreeting("Good night");
    };
    updateGreeting();
    const interval = setInterval(updateGreeting, 60000);
    return () => clearInterval(interval);
  }, []);

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const text = inputText.trim();
    if (!text && !selectedImage) return;

    const img = selectedImage
      ? { data: selectedImage.data, mimeType: selectedImage.mimeType }
      : undefined;

    onSendMessage(text || "Please analyze this image", img);
    setInputText("");
    setSelectedImage(null);
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64Data = result.split(",")[1];
      setSelectedImage({
        data: base64Data,
        mimeType: file.type || "image/jpeg",
        previewUrl: result,
      });
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  // Assistant status label & dot indicator
  const getStatusDetails = () => {
    switch (orbState) {
      case "listening":
        return { label: "Tani Listening", dot: "bg-cyan-400 animate-ping", textColor: "text-cyan-300" };
      case "thinking":
        return { label: "Tani Thinking", dot: "bg-purple-400 animate-pulse", textColor: "text-purple-300" };
      case "speaking":
        return { label: "Tani Speaking", dot: "bg-emerald-400 animate-pulse", textColor: "text-emerald-300" };
      case "working":
        return { label: "Tani Working", dot: "bg-sky-400 animate-spin", textColor: "text-sky-300" };
      case "error":
        return { label: "Tani Needs Attention", dot: "bg-rose-500", textColor: "text-rose-300" };
      case "idle":
      default:
        return { label: "Tani Ready", dot: "bg-emerald-400", textColor: "text-emerald-300" };
    }
  };

  const status = getStatusDetails();

  // Quick Action Buttons
  const quickActions = [
    {
      id: "weather",
      label: "Weather",
      icon: CloudSun,
      color: "text-sky-400 group-hover:text-sky-300",
      bg: "hover:bg-sky-500/10 hover:border-sky-500/30",
      action: () => onSendMessage("What is the current weather condition and forecast today?"),
    },
    {
      id: "timer",
      label: "Timer",
      icon: TimerIcon,
      color: "text-amber-400 group-hover:text-amber-300",
      bg: "hover:bg-amber-500/10 hover:border-amber-500/30",
      action: () => {
        if (onStartQuickTimer) {
          onStartQuickTimer(5);
        } else {
          onSendMessage("Set a timer for 5 minutes.");
        }
      },
    },
    {
      id: "study",
      label: "Study",
      icon: BookOpen,
      color: "text-indigo-400 group-hover:text-indigo-300",
      bg: "hover:bg-indigo-500/10 hover:border-indigo-500/30",
      action: () => onSendMessage("I want to study. Ask me what topic I want to explore and summarize key concepts."),
    },
    {
      id: "coding",
      label: "Coding",
      icon: Code2,
      color: "text-emerald-400 group-hover:text-emerald-300",
      bg: "hover:bg-emerald-500/10 hover:border-emerald-500/30",
      action: () => onSendMessage("I need help with a coding problem in TypeScript/Python. What are you building?"),
    },
    {
      id: "create",
      label: "Create",
      icon: Sparkles,
      color: "text-purple-400 group-hover:text-purple-300",
      bg: "hover:bg-purple-500/10 hover:border-purple-500/30",
      action: () => onSendMessage("Create a modern interactive responsive web page with HTML, Tailwind CSS, and JavaScript."),
    },
    {
      id: "notes",
      label: "Notes",
      icon: FileText,
      color: "text-rose-400 group-hover:text-rose-300",
      bg: "hover:bg-rose-500/10 hover:border-rose-500/30",
      action: () => onOpenMemory(),
    },
  ];

  return (
    <div
      id="tani-home-view"
      className="flex-1 w-full flex flex-col justify-between items-center px-4 sm:px-6 py-3 sm:py-5 select-none relative overflow-hidden"
    >
      {/* Subtle Radial Glow Background */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[30rem] h-[30rem] bg-cyan-600/10 rounded-full blur-[140px] pointer-events-none" />

      {/* TOP BAR: [Menu] Tani AI [Bell] [Profile] */}
      <div className="w-full max-w-2xl flex items-center justify-between z-20 pb-2">
        {/* Menu Button */}
        <button
          id="home-menu-button"
          onClick={onOpenMenu}
          title="Open Menu"
          aria-label="Open Navigation Menu"
          className="p-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-gray-300 hover:text-white transition-all cursor-pointer shadow-sm active:scale-95"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Brand Center: Tani AI */}
        <div className="flex flex-col items-center">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#06b6d4] animate-pulse" />
            <h1 className="text-base sm:text-lg font-semibold tracking-wider text-white">
              Tani AI
            </h1>
          </div>
          <span className="text-[10px] text-gray-400 font-mono tracking-wider">
            PERSONAL ASSISTANT
          </span>
        </div>

        {/* Right Actions: [Bell] [Profile] */}
        <div className="flex items-center gap-2">
          {/* Notifications Bell */}
          <button
            id="home-alerts-button"
            onClick={onOpenAlerts}
            title="Proactive Updates"
            aria-label="Proactive Updates"
            className="relative p-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-gray-300 hover:text-white transition-all cursor-pointer shadow-sm active:scale-95"
          >
            <Bell className="w-4 h-4" />
            {unreadAlertsCount > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_6px_#06b6d4] animate-ping" />
            )}
          </button>

          {/* Profile Button */}
          <button
            id="home-profile-button"
            onClick={onOpenProfile}
            title="Personalization & Profile"
            aria-label="Personalization & Profile"
            className="p-1.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-gray-300 hover:text-white transition-all cursor-pointer shadow-sm active:scale-95"
          >
            {profilePhoto ? (
              <img
                src={profilePhoto}
                alt="Profile"
                className="w-6 h-6 rounded-xl object-cover"
              />
            ) : (
              <div className="w-6 h-6 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white">
                <User className="w-3.5 h-3.5" />
              </div>
            )}
          </button>
        </div>
      </div>

      {/* CENTER ASSISTANT AREA */}
      <div className="flex-1 w-full max-w-xl flex flex-col items-center justify-center my-auto z-10 text-center py-2">
        {/* Dynamic Greeting */}
        <div className="mb-4 sm:mb-5">
          <h2 className="text-2xl sm:text-3xl font-light text-white tracking-tight leading-tight">
            {timeGreeting}, <br className="sm:hidden" />
            <span className="font-semibold text-white">
              {userName || "there"}
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-gray-400 mt-1 font-normal">
            Tani is ready to help you.
          </p>
        </div>

        {/* MAIN TANI VISUALIZER: TANI ENERGY RING */}
        <div className="my-2 relative flex items-center justify-center">
          <TaniEnergyRing
            state={orbState}
            profilePhoto={profilePhoto}
            size={240}
            theme={theme}
            audioLevel={audioLevel}
            onClick={() => {
              if (orbState === "speaking") {
                onStopSpeaking();
              } else if (orbState === "listening") {
                onStopVoice();
              } else {
                onStartVoice();
              }
            }}
          />
        </div>

        {/* Compact Status Card: ● Tani Ready */}
        <div className="mt-3 flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#101420]/80 border border-white/10 backdrop-blur-md shadow-md">
          <span className={`w-2 h-2 rounded-full ${status.dot}`} />
          <span className={`text-xs font-medium tracking-wide ${status.textColor}`}>
            ● {status.label}
          </span>
          {orbState === "speaking" && (
            <button
              onClick={onStopSpeaking}
              title="Interrupt Tani"
              className="ml-1 p-0.5 rounded text-gray-400 hover:text-white transition-colors cursor-pointer"
            >
              <VolumeX className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* LIVE TRANSCRIPT UI (Above Microphone Control) */}
        {(liveTranscript?.user || liveTranscript?.tani) && (
          <div
            id="home-live-transcript"
            className="w-full max-w-sm mt-3 px-4 py-3 rounded-2xl bg-[#0e1322]/90 border border-cyan-500/25 backdrop-blur-xl shadow-lg text-left space-y-1.5 transition-all"
          >
            {liveTranscript.user && (
              <div className="flex items-start gap-2">
                <span className="text-[10px] font-mono font-semibold uppercase tracking-wider text-cyan-400 bg-cyan-500/10 px-1.5 py-0.5 rounded border border-cyan-500/20 shrink-0">
                  You
                </span>
                <p className="text-xs text-gray-200 leading-relaxed font-normal">
                  {liveTranscript.user}
                </p>
              </div>
            )}
            {liveTranscript.tani && (
              <div className="flex items-start gap-2">
                <span className="text-[10px] font-mono font-semibold uppercase tracking-wider text-purple-400 bg-purple-500/10 px-1.5 py-0.5 rounded border border-purple-500/20 shrink-0">
                  Tani
                </span>
                <p className="text-xs text-white leading-relaxed font-medium">
                  {liveTranscript.tani}
                </p>
              </div>
            )}
          </div>
        )}

        {/* PREMIUM CIRCULAR GLASS MICROPHONE CONTROL */}
        <div className="mt-4 flex flex-col items-center">
          <div className="relative flex items-center justify-center">
            {/* Animated Expanding Ripple Rings when Listening or Speaking */}
            {(orbState === "listening" || orbState === "speaking") && (
              <>
                <div className="absolute -inset-3 rounded-full border border-cyan-400/40 animate-ping pointer-events-none opacity-40 duration-1000" />
                <div className="absolute -inset-1 rounded-full border border-cyan-400/60 animate-pulse pointer-events-none" />
              </>
            )}

            {/* Circular Glass Button (68-72px touch target) */}
            <button
              id="home-main-voice-button"
              onClick={() => {
                if (orbState === "speaking") {
                  onStopSpeaking();
                } else if (orbState === "listening") {
                  onStopVoice();
                } else if (orbState === "error") {
                  onRetryVoice ? onRetryVoice() : onStartVoice();
                } else {
                  onStartVoice();
                }
              }}
              title={
                orbState === "listening"
                  ? "Stop listening"
                  : orbState === "speaking"
                  ? "Stop speaking"
                  : orbState === "error"
                  ? "Retry connection"
                  : "Tap to talk"
              }
              aria-label={
                orbState === "listening"
                  ? "Stop listening"
                  : orbState === "speaking"
                  ? "Stop speaking"
                  : "Tap to talk"
              }
              className={`relative w-[70px] h-[70px] rounded-full flex items-center justify-center cursor-pointer transition-all duration-300 active:scale-90 active:brightness-125 select-none shadow-2xl ${
                orbState === "listening"
                  ? "bg-gradient-to-b from-cyan-400/30 to-cyan-500/10 border-2 border-cyan-300 shadow-[0_0_32px_rgba(6,182,212,0.7),inset_0_0_18px_rgba(6,182,212,0.4)] ring-2 ring-cyan-400/50"
                  : orbState === "speaking"
                  ? "bg-gradient-to-b from-rose-500/25 to-purple-500/10 border-2 border-rose-400/80 shadow-[0_0_32px_rgba(244,63,94,0.6),inset_0_0_18px_rgba(244,63,94,0.3)] ring-2 ring-rose-400/40"
                  : orbState === "thinking"
                  ? "bg-gradient-to-b from-purple-500/25 to-indigo-500/10 border-2 border-purple-400/70 shadow-[0_0_28px_rgba(168,85,247,0.5),inset_0_0_16px_rgba(168,85,247,0.3)]"
                  : orbState === "error"
                  ? "bg-gradient-to-b from-rose-500/20 to-rose-900/10 border-2 border-rose-500/60 shadow-[0_0_20px_rgba(244,63,94,0.4)]"
                  : "bg-gradient-to-b from-white/[0.08] to-white/[0.02] hover:from-white/[0.12] hover:to-white/[0.04] border border-cyan-500/35 hover:border-cyan-400/60 shadow-[inset_0_0_16px_rgba(6,182,212,0.2),0_0_20px_rgba(6,182,212,0.2)] hover:shadow-[inset_0_0_20px_rgba(6,182,212,0.3),0_0_28px_rgba(6,182,212,0.4)] backdrop-blur-xl"
              }`}
            >
              {orbState === "listening" ? (
                /* Clear STOP indicator while listening */
                <Square className="w-6 h-6 text-white fill-white transition-transform" />
              ) : orbState === "speaking" ? (
                /* Clear STOP / Interrupt indicator while Tani speaks */
                <Square className="w-6 h-6 fill-rose-300 text-rose-300 transition-transform" />
              ) : orbState === "thinking" ? (
                <Sparkles className="w-6 h-6 text-purple-300 animate-pulse" />
              ) : orbState === "error" ? (
                <RefreshCw className="w-6 h-6 text-rose-300" />
              ) : (
                <Mic className="w-7 h-7 text-cyan-400 drop-shadow-[0_0_8px_rgba(6,182,212,0.6)]" />
              )}
            </button>
          </div>

          {/* DYNAMIC TEXT BELOW MICROPHONE */}
          <span className="text-xs font-medium tracking-wide text-gray-300 mt-2.5">
            {orbState === "listening"
              ? "Listening..."
              : orbState === "speaking"
              ? "Tani is speaking... (Tap to stop)"
              : orbState === "thinking"
              ? "Tani is thinking..."
              : orbState === "error"
              ? "Tap to retry"
              : "Tap to talk"}
          </span>

          {/* CONTINUOUS CONVERSATION MODE TOGGLE */}
          <button
            id="home-continuous-voice-toggle"
            onClick={onToggleContinuousVoice}
            className={`mt-2 flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-medium border transition-all cursor-pointer ${
              continuousVoice
                ? "bg-cyan-500/15 border-cyan-500/40 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.25)]"
                : "bg-white/[0.04] border-white/10 text-gray-400 hover:text-gray-200"
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                continuousVoice ? "bg-cyan-400 animate-pulse" : "bg-gray-500"
              }`}
            />
            <span>Continuous Mode: {continuousVoice ? "ON" : "OFF"}</span>
          </button>
        </div>

        {/* RECONNECT & USER-FRIENDLY ERROR CARD (No raw JSON!) */}
        {errorMessage && (
          <div
            id="home-voice-error-card"
            className="mt-4 p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 max-w-sm flex items-center justify-between gap-3 text-left backdrop-blur-md shadow-lg"
          >
            <div className="flex items-center gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <div>
                <p className="text-xs font-semibold text-rose-200">
                  {errorMessage.includes("quota") || errorMessage.includes("rate limit") || errorMessage.includes("429")
                    ? "AI rate limit reached."
                    : errorMessage.includes("connection") || errorMessage.includes("lost")
                    ? "Tani lost the voice connection."
                    : errorMessage.includes("API key") || errorMessage.includes("403")
                    ? "AI connection needs attention."
                    : "Voice connection error."}
                </p>
                <p className="text-[10px] text-rose-300/80 mt-0.5">
                  {errorMessage.includes("quota") || errorMessage.includes("rate limit")
                    ? "Please wait a few seconds and tap retry."
                    : errorMessage.includes("connection")
                    ? "Tap retry or continue with text chat."
                    : errorMessage}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                id="home-error-retry-button"
                onClick={() => {
                  onClearError?.();
                  if (onRetryVoice) {
                    onRetryVoice();
                  } else {
                    onStartVoice();
                  }
                }}
                className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 text-[10px] font-semibold flex items-center gap-1 transition-colors cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                Retry
              </button>
              <button
                id="home-error-chat-button"
                onClick={onOpenChat}
                className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-gray-200 text-[10px] font-semibold transition-colors cursor-pointer"
              >
                Text Chat
              </button>
            </div>
          </div>
        )}

        {/* BEAUTIFUL MICROPHONE PERMISSION MODAL */}
        {permissionDenied && (
          <div
            id="mic-permission-modal"
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200"
          >
            <div className="w-full max-w-sm rounded-3xl bg-[#0f131f] border border-cyan-500/30 p-6 shadow-2xl text-center space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center mx-auto text-cyan-400 shadow-inner">
                <Mic className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-base font-semibold text-white">Microphone Access Needed</h3>
                <p className="text-xs text-gray-300 mt-1.5 leading-relaxed">
                  Tani needs microphone access to listen and speak with you in real-time. Please tap
                  the lock or site settings icon in your browser address bar and enable Microphone
                  permissions.
                </p>
              </div>
              <div className="flex items-center gap-2 pt-2">
                <button
                  id="mic-permission-retry-button"
                  onClick={() => {
                    onClosePermissionDialog?.();
                    onStartVoice();
                  }}
                  className="flex-1 py-2.5 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs transition-all shadow-lg cursor-pointer active:scale-95"
                >
                  Try Again
                </button>
                <button
                  id="mic-permission-dismiss-button"
                  onClick={onClosePermissionDialog}
                  className="px-4 py-2.5 rounded-2xl bg-white/[0.07] hover:bg-white/10 text-gray-300 text-xs transition-all cursor-pointer active:scale-95"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* QUICK ACTIONS ROW: Horizontal scrolling row */}
      <div className="w-full max-w-xl z-10 py-2">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none no-scrollbar">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.id}
                onClick={action.action}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/[0.04] border border-white/5 whitespace-nowrap transition-all group cursor-pointer active:scale-95 ${action.bg}`}
              >
                <Icon className={`w-4 h-4 transition-colors ${action.color}`} />
                <span className="text-xs font-medium text-gray-300 group-hover:text-white">
                  {action.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* CHAT COMPOSER: TEXT & VOICE SUPPORT */}
      <div className="w-full max-w-xl z-10 pb-1">
        {/* Attachment preview if selected */}
        {selectedImage && (
          <div className="mb-2 relative inline-block rounded-2xl overflow-hidden border border-cyan-500/40 shadow-lg">
            <img
              src={selectedImage.previewUrl}
              alt="Attachment"
              className="w-16 h-16 object-cover"
              referrerPolicy="no-referrer"
            />
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-1 right-1 p-1 rounded-full bg-black/80 hover:bg-black text-white"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        )}

        <form
          onSubmit={handleSend}
          className="relative flex items-center gap-2 p-1.5 sm:p-2 rounded-2xl bg-[#0f131f]/90 border border-white/15 backdrop-blur-xl shadow-2xl transition-all focus-within:border-cyan-500/50"
        >
          {/* File picker */}
          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            onChange={handleImageSelect}
            className="hidden"
          />

          {/* Attachment button */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            title="Attach Image / Camera"
            aria-label="Attach file"
            className="p-2.5 rounded-xl text-gray-400 hover:text-cyan-300 hover:bg-white/[0.06] transition-colors cursor-pointer shrink-0"
          >
            <ImageIcon className="w-4 h-4" />
          </button>

          {/* Input field */}
          <input
            id="home-chat-input"
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Ask Tani anything..."
            className="flex-1 bg-transparent border-none text-white text-xs sm:text-sm placeholder-gray-500 focus:outline-none px-2 select-text"
          />

          {/* Mic Button in Composer */}
          <button
            type="button"
            onClick={() => {
              if (orbState === "listening") {
                onStopVoice();
              } else {
                onStartVoice();
              }
            }}
            title={orbState === "listening" ? "Stop listening" : "Voice input"}
            aria-label="Voice input"
            className={`p-2.5 rounded-xl transition-all cursor-pointer shrink-0 ${
              orbState === "listening"
                ? "bg-cyan-500 text-black shadow-lg shadow-cyan-500/40"
                : "text-gray-400 hover:text-cyan-300 hover:bg-white/[0.06]"
            }`}
          >
            {orbState === "listening" ? (
              <MicOff className="w-4 h-4" />
            ) : (
              <Mic className="w-4 h-4" />
            )}
          </button>

          {/* Send Button */}
          <button
            id="home-chat-send-button"
            type="submit"
            disabled={!inputText.trim() && !selectedImage}
            title="Send Message"
            aria-label="Send message"
            className={`p-2.5 rounded-xl flex items-center justify-center transition-all cursor-pointer shrink-0 ${
              inputText.trim() || selectedImage
                ? "bg-cyan-500 text-[#07090e] shadow-lg shadow-cyan-500/30 active:scale-95 hover:bg-cyan-400"
                : "bg-white/[0.04] text-gray-600 cursor-not-allowed"
            }`}
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
