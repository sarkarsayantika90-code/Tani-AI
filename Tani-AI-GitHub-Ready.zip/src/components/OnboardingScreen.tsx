import React, { useState } from "react";
import confetti from "canvas-confetti";
import { TaniOrb } from "./TaniOrb";
import { ArrowRight, Sparkles } from "lucide-react";

interface OnboardingScreenProps {
  onComplete: (name: string) => void;
}

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onComplete }) => {
  const [name, setName] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    if (!cleanName) {
      setError("Please tell Tani your name to continue");
      return;
    }

    try {
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.7 },
      });
    } catch (e) {
      // ignore
    }

    onComplete(cleanName);
  };

  const buttonText = name.trim() ? `Continue with ${name.trim()}` : "Continue with...";

  return (
    <div
      id="tani-onboarding-screen"
      className="min-h-screen flex flex-col items-center justify-between bg-[#07090e] text-white px-6 py-8 relative overflow-hidden"
    >
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-600/15 rounded-full blur-[110px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-blue-600/10 rounded-full blur-[90px] pointer-events-none" />

      {/* Top Header */}
      <div className="w-full flex justify-center items-center pt-4">
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-purple-300">
          <Sparkles className="w-3.5 h-3.5 text-purple-400" />
          <span>New Experience</span>
        </div>
      </div>

      {/* Main Form Container */}
      <div className="w-full max-w-md flex flex-col items-center text-center z-10">
        <div className="mb-6 transform scale-90 sm:scale-100">
          <TaniOrb state="idle" size="md" />
        </div>

        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white mb-2">
          WELCOME TO TANI AI
        </h1>
        <p className="text-base sm:text-lg text-purple-200/70 font-normal mb-8">
          Your personal AI companion
        </p>

        <form onSubmit={handleSubmit} className="w-full space-y-6">
          <div className="text-left space-y-2">
            <label
              htmlFor="user-name-input"
              className="block text-sm font-medium text-gray-300 ml-1"
            >
              What should Tani call you?
            </label>
            <input
              id="user-name-input"
              type="text"
              autoFocus
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError("");
              }}
              placeholder="Your name"
              className="w-full px-4 py-3.5 rounded-2xl bg-white/[0.07] border border-white/15 focus:border-purple-400 focus:bg-white/[0.1] focus:outline-none text-white placeholder-gray-500 transition-all text-base shadow-inner"
            />
            {error && <p className="text-rose-400 text-xs mt-1 ml-1">{error}</p>}
          </div>

          <button
            id="onboarding-continue-button"
            type="submit"
            disabled={!name.trim()}
            className={`w-full py-4 px-6 rounded-2xl font-semibold flex items-center justify-center gap-2 text-base transition-all shadow-lg ${
              name.trim()
                ? "bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white shadow-purple-900/40 hover:shadow-purple-700/50 cursor-pointer active:scale-[0.98]"
                : "bg-white/10 text-gray-400 cursor-not-allowed border border-white/5"
            }`}
          >
            <span>{buttonText}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>

      {/* Footer */}
      <div className="text-center text-xs text-gray-500 pt-6">
        <p>Tani AI • Made by Anik</p>
      </div>
    </div>
  );
};
