import React from "react";
import { ProactiveAlert } from "../types";
import { Bell, CheckCircle2, Clock, Activity, X, Trash2 } from "lucide-react";

interface AlertsModalProps {
  isOpen: boolean;
  onClose: () => void;
  alerts: ProactiveAlert[];
  onClearAll: () => void;
  onOpenTasks: () => void;
}

export const AlertsModal: React.FC<AlertsModalProps> = ({
  isOpen,
  onClose,
  alerts,
  onClearAll,
  onOpenTasks,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md bg-[#0e121b] border border-white/10 rounded-2xl p-5 shadow-2xl flex flex-col max-h-[80vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">Proactive Updates</h3>
              <p className="text-[10px] text-gray-400">Automatic notifications from Tani</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Alerts List */}
        <div className="flex-1 overflow-y-auto py-3 space-y-2.5">
          {alerts.length === 0 ? (
            <div className="text-center py-8">
              <Bell className="w-8 h-8 text-gray-600 mx-auto mb-2 opacity-50" />
              <p className="text-xs text-gray-400">No new proactive notifications</p>
              <p className="text-[10px] text-gray-500 mt-1">
                Tani will notify you when tasks complete or timers finish.
              </p>
            </div>
          ) : (
            alerts.map((alert) => (
              <div
                key={alert.id}
                className="p-3 rounded-xl bg-white/[0.04] border border-white/5 flex items-start gap-3 hover:bg-white/[0.06] transition-colors"
              >
                <div className="mt-0.5">
                  {alert.type === "task" ? (
                    <Activity className="w-4 h-4 text-cyan-400" />
                  ) : alert.type === "timer" ? (
                    <Clock className="w-4 h-4 text-amber-400" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-semibold text-gray-200">{alert.title}</h4>
                    <span className="text-[9px] text-gray-500">
                      {new Date(alert.timestamp).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </div>
                  <p className="text-[11px] text-gray-400 mt-0.5">{alert.message}</p>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10 flex items-center justify-between">
          {alerts.length > 0 ? (
            <button
              onClick={onClearAll}
              className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-rose-400 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear all</span>
            </button>
          ) : (
            <div />
          )}
          <button
            onClick={() => {
              onClose();
              onOpenTasks();
            }}
            className="px-3.5 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-semibold border border-cyan-500/30 transition-colors cursor-pointer"
          >
            View Active Tasks
          </button>
        </div>
      </div>
    </div>
  );
};
