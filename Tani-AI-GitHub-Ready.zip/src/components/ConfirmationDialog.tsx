import React from "react";
import { AlertCircle, Check, X } from "lucide-react";

interface ConfirmationDialogProps {
  isOpen: boolean;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  isDestructive?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmationDialog: React.FC<ConfirmationDialogProps> = ({
  isOpen,
  title,
  description,
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
  isDestructive = false,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="tani-confirmation-dialog-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm px-4 select-none"
    >
      <div
        id="tani-confirmation-dialog-modal"
        className="w-full max-w-sm rounded-3xl bg-[#12151f] border border-white/15 p-6 shadow-2xl space-y-4 text-white animate-in fade-in zoom-in-95 duration-150"
      >
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${
              isDestructive
                ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                : "bg-purple-500/20 text-purple-300 border border-purple-500/30"
            }`}
          >
            <AlertCircle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-white tracking-wide">{title}</h3>
            <p className="text-xs text-gray-400 mt-0.5 leading-relaxed">{description}</p>
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 pt-3">
          <button
            id="confirmation-cancel-button"
            onClick={onCancel}
            className="px-4 py-2.5 rounded-xl bg-white/[0.07] hover:bg-white/[0.12] text-sm font-medium text-gray-300 transition-colors cursor-pointer"
          >
            {cancelLabel}
          </button>
          <button
            id="confirmation-confirm-button"
            onClick={onConfirm}
            className={`px-5 py-2.5 rounded-xl text-sm font-semibold transition-all cursor-pointer shadow-md flex items-center gap-1.5 ${
              isDestructive
                ? "bg-rose-600 hover:bg-rose-500 text-white shadow-rose-900/40"
                : "bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-purple-900/40"
            }`}
          >
            <Check className="w-4 h-4" />
            <span>{confirmLabel}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
