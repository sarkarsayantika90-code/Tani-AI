import React, { useState } from "react";
import { ANDROID_PROJECT_FILES } from "../data/androidProjectFiles";
import {
  X,
  Copy,
  Check,
  Download,
  FileCode,
  Folder,
  Smartphone,
  Layers,
} from "lucide-react";

interface AndroidCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidCodeModal: React.FC<AndroidCodeModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentFile = ANDROID_PROJECT_FILES[selectedIndex] || ANDROID_PROJECT_FILES[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const filename = currentFile.path.split("/").pop() || "code.txt";
    const blob = new Blob([currentFile.content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div
      id="tani-android-code-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-6 select-none"
    >
      <div
        id="tani-android-code-modal-card"
        className="w-full max-w-5xl h-[88vh] rounded-3xl bg-[#0d1017] border border-white/15 flex flex-col overflow-hidden shadow-2xl text-white"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-white/[0.04] border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-600/20 border border-purple-500/30 text-purple-300">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide flex items-center gap-2">
                <span>Tani AI Android Native Architecture</span>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 font-mono">
                  Kotlin • Jetpack Compose
                </span>
              </h2>
              <p className="text-xs text-gray-400">Package: com.anik.tani • Creator: Made by Anik</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body with Sidebar File List and Code Viewer */}
        <div className="flex-1 flex flex-col sm:flex-row overflow-hidden">
          {/* File Explorer Sidebar */}
          <div className="w-full sm:w-72 bg-white/[0.02] border-b sm:border-b-0 sm:border-r border-white/10 overflow-y-auto p-3 space-y-1">
            <div className="flex items-center gap-1.5 px-2 py-1 text-xs font-semibold text-gray-400 uppercase tracking-wider">
              <Folder className="w-3.5 h-3.5 text-purple-400" />
              <span>Project Files</span>
            </div>

            {ANDROID_PROJECT_FILES.map((file, idx) => {
              const isSelected = selectedIndex === idx;
              const fileName = file.path.split("/").pop();

              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedIndex(idx)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono flex items-center gap-2 transition-colors cursor-pointer ${
                    isSelected
                      ? "bg-purple-600/30 text-purple-200 border border-purple-500/40 font-semibold"
                      : "text-gray-400 hover:bg-white/[0.04] hover:text-gray-200"
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5 shrink-0 text-purple-400" />
                  <span className="truncate">{fileName}</span>
                </button>
              );
            })}
          </div>

          {/* Main Code Viewer */}
          <div className="flex-1 flex flex-col overflow-hidden bg-[#0a0d13]">
            {/* File info bar */}
            <div className="flex items-center justify-between px-4 py-2.5 bg-white/[0.03] border-b border-white/5 text-xs text-gray-300">
              <div className="truncate font-mono text-[11px] text-purple-300 flex items-center gap-2">
                <span>{currentFile.path}</span>
                <span className="text-gray-500 hidden sm:inline">• {currentFile.description}</span>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={handleDownload}
                  title="Download File"
                  className="p-1.5 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition-colors cursor-pointer shadow-sm"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-white" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Code</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Code Body */}
            <div className="flex-1 p-4 overflow-auto font-mono text-xs text-gray-200 leading-relaxed select-text">
              <pre className="whitespace-pre">{currentFile.content}</pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
