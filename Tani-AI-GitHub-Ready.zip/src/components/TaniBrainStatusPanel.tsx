import React, { useState, useEffect } from "react";
import { Activity, Radio, Cpu, Sparkles, ChevronDown, ChevronUp } from "lucide-react";
import { languageEngine } from "../services/languageEngine";
import { unifiedContextManager } from "../services/unifiedContextManager";
import { liveSessionManager } from "../services/liveSessionManager";
import { voiceManager } from "../services/voiceService";
import { ConversationalTurnState } from "../types";

export const TaniBrainStatusPanel: React.FC = () => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [turnState, setTurnState] = useState<ConversationalTurnState>("IDLE");
  const [lockedLang, setLockedLang] = useState<string>("bn");
  const [activeApp, setActiveApp] = useState<string | null>(null);
  const [turnCount, setTurnCount] = useState<number>(0);
  const [isVoiceConnected, setIsVoiceConnected] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);

  useEffect(() => {
    const updateStats = () => {
      setTurnState(liveSessionManager.getTurnState());
      setLockedLang(languageEngine.getLockedLanguage());
      setActiveApp(unifiedContextManager.getActiveApp());
      setTurnCount(unifiedContextManager.getState().recentTurns.length);
      setIsVoiceConnected(liveSessionManager.isConnected() || voiceManager.isLiveActive());
      setIsListening(liveSessionManager.isListening() || voiceManager.getIsListening());
    };

    updateStats();
    const interval = setInterval(updateStats, 400);
    return () => clearInterval(interval);
  }, []);

  const getLanguageLabel = (lang: string) => {
    switch (lang) {
      case "bn":
        return "Bengali (বাংলা)";
      case "bn-en":
        return "Bengali + English (Banglish)";
      case "hi":
        return "Hindi (हिंदी)";
      case "hi-en":
        return "Hindi + English (Hinglish)";
      case "en":
        return "English";
      default:
        return "Auto / Multilingual";
    }
  };

  const getTurnStateColor = (state: ConversationalTurnState) => {
    switch (state) {
      case "USER_SPEAKING":
        return "text-emerald-400 bg-emerald-950/60 border-emerald-500/30";
      case "USER_PAUSED":
      case "WAITING_FOR_COMPLETION":
        return "text-amber-400 bg-amber-950/60 border-amber-500/30";
      case "TANI_THINKING":
        return "text-cyan-400 bg-cyan-950/60 border-cyan-500/30";
      case "TANI_SPEAKING":
        return "text-indigo-400 bg-indigo-950/60 border-indigo-500/30";
      default:
        return "text-slate-400 bg-slate-900/60 border-slate-700/30";
    }
  };

  return (
    <div className="fixed bottom-3 right-3 z-50 font-mono text-[11px]">
      {!isOpen ? (
        <button
          id="brain-status-toggle-btn"
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-slate-900/90 text-slate-300 hover:text-white border border-slate-700/60 shadow-lg backdrop-blur-md transition-all hover:border-cyan-500/40"
          title="Tani AI Brain V2 Status"
        >
          <span className="relative flex h-2 w-2">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${isVoiceConnected ? "bg-emerald-400" : "bg-cyan-400"} opacity-75`}></span>
            <span className={`relative inline-flex rounded-full h-2 w-2 ${isVoiceConnected ? "bg-emerald-500" : "bg-cyan-500"}`}></span>
          </span>
          <span className="font-sans font-medium text-xs">Tani V2 Brain</span>
          <span className="text-[10px] text-slate-400 uppercase">[{lockedLang}]</span>
          <ChevronUp className="w-3.5 h-3.5 ml-0.5 text-slate-400" />
        </button>
      ) : (
        <div className="w-64 rounded-xl bg-slate-950/95 border border-slate-800 shadow-2xl p-3 text-slate-300 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800/80">
            <div className="flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-sans font-semibold text-white text-xs">Tani AI Brain V2</span>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-slate-400 hover:text-white p-0.5 rounded hover:bg-slate-800"
            >
              <ChevronDown className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between items-center py-0.5">
              <span className="text-slate-400">Language:</span>
              <span className="text-cyan-300 font-semibold">{getLanguageLabel(lockedLang)}</span>
            </div>

            <div className="flex justify-between items-center py-0.5">
              <span className="text-slate-400">Voice Session:</span>
              <span className={`flex items-center gap-1 font-semibold ${isVoiceConnected ? "text-emerald-400" : "text-slate-400"}`}>
                <Radio className="w-3 h-3" />
                {isVoiceConnected ? "Connected" : "Idle"}
              </span>
            </div>

            <div className="flex justify-between items-center py-0.5">
              <span className="text-slate-400">Listening:</span>
              <span className={isListening ? "text-emerald-400 font-semibold" : "text-slate-400"}>
                {isListening ? "YES (Active)" : "NO"}
              </span>
            </div>

            <div className="flex justify-between items-center py-0.5">
              <span className="text-slate-400">Turn State:</span>
              <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold border ${getTurnStateColor(turnState)}`}>
                {turnState}
              </span>
            </div>

            <div className="flex justify-between items-center py-0.5">
              <span className="text-slate-400">Model Engine:</span>
              <span className="text-indigo-300 font-semibold">Gemini 3.8 Live / Flash</span>
            </div>

            <div className="flex justify-between items-center py-0.5">
              <span className="text-slate-400">Context Turns:</span>
              <span className="text-slate-200">{turnCount} recorded</span>
            </div>

            <div className="flex justify-between items-center py-0.5">
              <span className="text-slate-400">Active App / Tool:</span>
              <span className="text-amber-300 font-semibold">{activeApp || "None (Default)"}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
