import React, { useState } from "react";
import {
  X,
  Mail,
  Share2,
  ShieldCheck,
  CheckCircle,
  RefreshCw,
  ExternalLink,
  Sparkles,
} from "lucide-react";
import { TaniEnergyRing } from "./TaniEnergyRing";

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenPermissions: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({
  isOpen,
  onClose,
  onOpenPermissions,
}) => {
  const [checkingUpdate, setCheckingUpdate] = useState(false);
  const [updateMessage, setUpdateMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleReportProblem = () => {
    const email = "anikmondal8680@gmail.com";
    const subject = encodeURIComponent("Tani AI Issue Report");
    const body = encodeURIComponent(
      `App: Tani AI\nVersion: 1.0.0\nCreator: Made by Anik\nPlatform: Web & Android Client\nUser Agent: ${navigator.userAgent}\n\n[Please describe the issue or feedback below]:\n`
    );
    window.open(`mailto:${email}?subject=${subject}&body=${body}`, "_blank");
  };

  const handleShareApp = async () => {
    const shareData = {
      title: "Tani AI",
      text: "Experience Tani AI - Your personal AI companion. Created by Anik.",
      url: window.location.href,
    };
    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (e) {
        // user cancelled or unsupported
      }
    } else {
      navigator.clipboard.writeText(
        `Tani AI - Your personal AI companion. Made by Anik: ${window.location.href}`
      );
      alert("Tani AI link copied to clipboard!");
    }
  };

  const handleCheckUpdate = () => {
    setCheckingUpdate(true);
    setUpdateMessage(null);
    setTimeout(() => {
      setCheckingUpdate(false);
      setUpdateMessage("Tani AI v1.0.0 is up to date! Latest release installed.");
    }, 1200);
  };

  return (
    <div
      id="tani-about-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 select-none"
    >
      <div
        id="tani-about-modal-card"
        className="w-full max-w-md rounded-3xl bg-[#111420] border border-white/15 p-6 shadow-2xl text-white relative flex flex-col items-center text-center space-y-4 max-h-[90vh] overflow-y-auto"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Center Energy Ring */}
        <div className="pt-2">
          <TaniEnergyRing state="idle" size={100} interactive={false} />
        </div>

        {/* App Title & Info */}
        <div className="space-y-1">
          <h2 className="text-2xl font-black tracking-wider text-white">TANI AI</h2>
          <p className="text-xs text-purple-300 font-light">Your personal AI companion</p>
          <div className="pt-1 text-xs font-medium text-gray-300">
            Made by Anik
          </div>
          <div className="text-[11px] text-gray-400">
            Support:{" "}
            <a
              href="mailto:anikmondal8680@gmail.com"
              className="text-purple-400 hover:underline"
            >
              anikmondal8680@gmail.com
            </a>
          </div>
          <div className="text-[11px] text-gray-500">Version 1.0.0 (Build 2026.1)</div>
        </div>

        {/* Action Buttons */}
        <div className="w-full space-y-2 pt-2 text-left">
          {/* Report problem */}
          <button
            onClick={handleReportProblem}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 transition-colors text-xs font-semibold text-gray-200 cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <Mail className="w-4 h-4 text-purple-400" />
              <span>Report a Problem</span>
            </div>
            <ExternalLink className="w-3.5 h-3.5 text-gray-500" />
          </button>

          {/* Share Tani AI */}
          <button
            onClick={handleShareApp}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 transition-colors text-xs font-semibold text-gray-200 cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <Share2 className="w-4 h-4 text-pink-400" />
              <span>Share Tani AI</span>
            </div>
            <ExternalLink className="w-3.5 h-3.5 text-gray-500" />
          </button>

          {/* Permissions summary */}
          <button
            onClick={() => {
              onClose();
              onOpenPermissions();
            }}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 transition-colors text-xs font-semibold text-gray-200 cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span>Permissions & Privacy Summary</span>
            </div>
            <ExternalLink className="w-3.5 h-3.5 text-gray-500" />
          </button>

          {/* Check for updates */}
          <button
            onClick={handleCheckUpdate}
            disabled={checkingUpdate}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 transition-colors text-xs font-semibold text-gray-200 cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <RefreshCw className={`w-4 h-4 text-emerald-400 ${checkingUpdate ? "animate-spin" : ""}`} />
              <span>Check for Updates</span>
            </div>
            <span className="text-[10px] text-gray-500 font-mono">v1.0.0</span>
          </button>

          {updateMessage && (
            <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40 text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>{updateMessage}</span>
            </div>
          )}
        </div>

        {/* Security & Disclaimer statement */}
        <div className="pt-2 text-[11px] text-gray-500 leading-relaxed border-t border-white/5 w-full">
          Designed with zero-telemetry client principles. All custom API keys are strictly secured
          via server proxies and local encryption. Made by Anik.
        </div>
      </div>
    </div>
  );
};
