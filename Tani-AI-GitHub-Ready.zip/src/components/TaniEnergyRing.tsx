import React, { useMemo } from "react";
import { OrbState, ThemeId } from "../types";

interface TaniEnergyRingProps {
  state: OrbState;
  onClick?: () => void;
  profilePhoto?: string;
  size?: number; // default 260
  interactive?: boolean;
  theme?: ThemeId;
  audioLevel?: number; // 0 to 1 audio amplitude
}

export const TaniEnergyRing: React.FC<TaniEnergyRingProps> = ({
  state,
  onClick,
  profilePhoto,
  size = 260,
  interactive = true,
  theme = "midnight",
  audioLevel = 0,
}) => {
  // Theme color accents for energy arcs
  const themeColors = useMemo(() => {
    switch (theme) {
      case "aurora":
        return {
          primary: "#10b981", // emerald
          secondary: "#06b6d4", // cyan
          accent: "#3b82f6", // blue
          glow: "rgba(16, 185, 129, 0.35)",
        };
      case "ocean":
        return {
          primary: "#0ea5e9", // sky
          secondary: "#2563eb", // blue
          accent: "#06b6d4", // cyan
          glow: "rgba(14, 165, 233, 0.35)",
        };
      case "violet":
        return {
          primary: "#8b5cf6", // violet
          secondary: "#d946ef", // fuchsia
          accent: "#6366f1", // indigo
          glow: "rgba(139, 92, 246, 0.35)",
        };
      case "crimson":
        return {
          primary: "#f43f5e", // rose
          secondary: "#f97316", // orange
          accent: "#ec4899", // pink
          glow: "rgba(244, 63, 94, 0.35)",
        };
      case "emerald":
        return {
          primary: "#059669", // emerald
          secondary: "#10b981", // teal
          accent: "#84cc16", // lime
          glow: "rgba(5, 150, 105, 0.35)",
        };
      case "midnight":
      default:
        return {
          primary: "#06b6d4", // cyan
          secondary: "#3b82f6", // blue
          accent: "#8b5cf6", // violet
          pink: "#ec4899", // subtle pink
          glow: "rgba(6, 182, 212, 0.35)",
        };
    }
  }, [theme]);

  // State-specific dynamic styles & speeds
  const stateConfig = useMemo(() => {
    switch (state) {
      case "listening":
        return {
          speed: "animate-[spin_2.8s_linear_infinite]",
          innerSpeed: "animate-[spin_1.8s_linear_infinite_reverse]",
          glowColor: "#06b6d4",
          ringGradient: "from-cyan-400 via-sky-400 to-emerald-400",
          statusText: "Listening",
          statusDot: "bg-cyan-400 animate-ping",
          audioWaveActive: true,
          photoGlow: "shadow-[0_0_35px_rgba(6,182,212,0.65)] ring-2 ring-cyan-400/80",
        };
      case "thinking":
        return {
          speed: "animate-[spin_2s_linear_infinite]",
          innerSpeed: "animate-[spin_1.2s_linear_infinite_reverse]",
          glowColor: "#8b5cf6",
          ringGradient: "from-blue-500 via-indigo-500 to-purple-500",
          statusText: "Thinking",
          statusDot: "bg-purple-400 animate-pulse",
          audioWaveActive: false,
          photoGlow: "shadow-[0_0_35px_rgba(139,92,246,0.65)] ring-2 ring-purple-400/80",
        };
      case "speaking":
        return {
          speed: "animate-[spin_3.5s_linear_infinite]",
          innerSpeed: "animate-[spin_2.2s_linear_infinite_reverse]",
          glowColor: "#06b6d4",
          ringGradient: "from-cyan-400 via-blue-500 to-pink-500",
          statusText: "Speaking",
          statusDot: "bg-emerald-400 animate-pulse",
          audioWaveActive: true,
          photoGlow: "shadow-[0_0_40px_rgba(59,130,246,0.7)] ring-2 ring-blue-400/80 animate-pulse",
        };
      case "working":
        return {
          speed: "animate-[spin_1.4s_linear_infinite]",
          innerSpeed: "animate-[spin_1s_linear_infinite_reverse]",
          glowColor: "#0ea5e9",
          ringGradient: "from-cyan-400 via-sky-500 to-indigo-500",
          statusText: "Working",
          statusDot: "bg-cyan-400 animate-spin",
          audioWaveActive: false,
          photoGlow: "shadow-[0_0_35px_rgba(14,165,233,0.65)] ring-2 ring-sky-400/80",
        };
      case "error":
        return {
          speed: "animate-[spin_6s_linear_infinite]",
          innerSpeed: "animate-[spin_4s_linear_infinite_reverse]",
          glowColor: "#f43f5e",
          ringGradient: "from-rose-500 via-red-500 to-pink-600",
          statusText: "Attention",
          statusDot: "bg-rose-500 animate-ping",
          audioWaveActive: false,
          photoGlow: "shadow-[0_0_35px_rgba(244,63,94,0.65)] ring-2 ring-rose-500/80",
        };
      case "idle":
      default:
        return {
          speed: "animate-[spin_9s_linear_infinite]",
          innerSpeed: "animate-[spin_7s_linear_infinite_reverse]",
          glowColor: themeColors.primary,
          ringGradient: "from-cyan-400 via-blue-500 to-violet-500",
          statusText: "Ready",
          statusDot: "bg-emerald-400",
          audioWaveActive: false,
          photoGlow: "shadow-[0_0_25px_rgba(6,182,212,0.35)] ring-1 ring-cyan-500/40",
        };
    }
  }, [state, themeColors]);

  const innerDiameter = Math.round(size * 0.72);

  return (
    <div
      id="tani-energy-ring"
      onClick={interactive ? onClick : undefined}
      className={`relative flex items-center justify-center select-none transition-transform duration-200 ${
        interactive ? "cursor-pointer active:scale-95" : ""
      }`}
      style={{
        width: size,
        height: size,
        transform: audioLevel > 0.02 ? `scale(${1 + Math.min(audioLevel, 1) * 0.06})` : undefined,
      }}
      role="button"
      tabIndex={interactive ? 0 : -1}
      aria-label={`Tani Energy Ring - ${state}`}
    >
      {/* Dynamic Ambient Background Glow Field */}
      <div
        className="absolute inset-0 rounded-full blur-2xl transition-all duration-300"
        style={{
          background: `radial-gradient(circle, ${stateConfig.glowColor}40 0%, rgba(0,0,0,0) 70%)`,
          opacity: 0.6 + Math.min(audioLevel, 1) * 0.4,
        }}
      />

      {/* SVG Thin Energy Arcs (Multi-Layered) */}
      <svg
        className={`absolute inset-0 w-full h-full ${stateConfig.speed} pointer-events-none`}
        viewBox="0 0 100 100"
      >
        <defs>
          <linearGradient id="energyGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.95" />
            <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.8" />
            <stop offset="85%" stopColor="#8b5cf6" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#ec4899" stopOpacity="0.6" />
          </linearGradient>
          <linearGradient id="energyGrad2" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.8" />
            <stop offset="50%" stopColor="#06b6d4" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.4" />
          </linearGradient>
          <filter id="energyGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="1.5" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Outer subtle baseline orbit ring */}
        <circle
          cx="50"
          cy="50"
          r="46"
          fill="none"
          stroke="rgba(255,255,255,0.06)"
          strokeWidth="0.75"
        />

        {/* Primary flowing energy arc */}
        <circle
          cx="50"
          cy="50"
          r="46"
          fill="none"
          stroke="url(#energyGrad1)"
          strokeWidth="1.8"
          strokeDasharray="95 190"
          strokeLinecap="round"
          filter="url(#energyGlow)"
        />

        {/* Secondary counter-flowing energy filament */}
        <circle
          cx="50"
          cy="50"
          r="46"
          fill="none"
          stroke="url(#energyGrad2)"
          strokeWidth="1.2"
          strokeDasharray="45 240"
          strokeDashoffset="120"
          strokeLinecap="round"
        />

        {/* Luminous energy bead head */}
        <circle
          cx="50"
          cy="4"
          r="1.6"
          fill="#ffffff"
          className="filter drop-shadow-[0_0_6px_#06b6d4]"
        />
      </svg>

      {/* Inner Reverse Energy Arc */}
      <svg
        className={`absolute inset-0 w-full h-full ${stateConfig.innerSpeed} pointer-events-none scale-90`}
        viewBox="0 0 100 100"
      >
        <circle
          cx="50"
          cy="50"
          r="44"
          fill="none"
          stroke="url(#energyGrad1)"
          strokeWidth="1"
          strokeDasharray="60 220"
          strokeDashoffset="45"
          strokeLinecap="round"
          opacity="0.8"
        />
        <circle
          cx="50"
          cy="50"
          r="44"
          fill="none"
          stroke="#06b6d4"
          strokeWidth="0.8"
          strokeDasharray="25 260"
          strokeDashoffset="180"
          strokeLinecap="round"
          opacity="0.6"
        />
      </svg>

      {/* Audio Reactive Waveform Ring (Active during listening & speaking) */}
      {stateConfig.audioWaveActive && (
        <div className="absolute inset-0 rounded-full border border-cyan-400/40 animate-ping pointer-events-none opacity-40 duration-1000" />
      )}

      {/* Dark Intelligent Center or Personal Photo */}
      <div
        className={`relative rounded-full overflow-hidden flex items-center justify-center transition-all duration-500 backdrop-blur-md ${
          stateConfig.photoGlow
        }`}
        style={{
          width: innerDiameter,
          height: innerDiameter,
          background: profilePhoto
            ? "#05070c"
            : "radial-gradient(circle at 35% 35%, #161c28 0%, #0a0d14 65%, #05070a 100%)",
        }}
      >
        {profilePhoto ? (
          <img
            src={profilePhoto}
            alt="Profile Avatar"
            className="w-full h-full object-cover rounded-full select-none pointer-events-none"
          />
        ) : (
          /* Intelligent Neural Core (When no photo uploaded) */
          <div className="relative w-full h-full flex items-center justify-center">
            {/* Subtle rotating sacred/neural pattern */}
            <div className="absolute inset-4 rounded-full border border-white/[0.06] flex items-center justify-center animate-[spin_24s_linear_infinite]">
              <div className="w-16 h-16 rounded-full border border-cyan-500/15" />
            </div>

            {/* Micro Audio Spectrum Bars (during Speaking) */}
            {state === "speaking" ? (
              <div className="flex items-center gap-1.5 h-10 z-10">
                {[0.6, 1.0, 0.75, 1.2, 0.8, 0.5].map((scale, i) => {
                  const barHeight =
                    audioLevel > 0.01
                      ? Math.max(6, Math.min(34, Math.round(36 * (audioLevel * 1.3 * scale))))
                      : Math.round(22 * scale);
                  return (
                    <span
                      key={i}
                      className="w-1 rounded-full bg-gradient-to-t from-cyan-400 to-blue-400 transition-all duration-75"
                      style={{
                        height: `${barHeight}px`,
                      }}
                    />
                  );
                })}
              </div>
            ) : state === "listening" ? (
              /* Reactive Mic Wave Indicator (during Listening) */
              <div className="flex items-center justify-center z-10">
                <div
                  className="w-12 h-12 rounded-full bg-cyan-500/10 border border-cyan-400/40 flex items-center justify-center transition-transform duration-100"
                  style={{
                    transform:
                      audioLevel > 0.02
                        ? `scale(${1 + Math.min(audioLevel, 1) * 0.45})`
                        : undefined,
                  }}
                >
                  <div
                    className="w-4 h-4 rounded-full bg-cyan-400 shadow-[0_0_12px_#06b6d4] transition-transform duration-100"
                    style={{
                      transform:
                        audioLevel > 0.02
                          ? `scale(${1 + Math.min(audioLevel, 1) * 0.7})`
                          : undefined,
                    }}
                  />
                </div>
              </div>
            ) : state === "thinking" ? (
              /* Quantum Spiral (during Thinking) */
              <div className="w-8 h-8 rounded-full border-2 border-t-purple-400 border-r-indigo-400 border-b-transparent border-l-transparent animate-spin z-10" />
            ) : (
              /* Idle Holographic Core */
              <div className="relative flex flex-col items-center justify-center z-10">
                <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-cyan-500/20 via-blue-500/15 to-violet-500/20 border border-white/10 flex items-center justify-center shadow-inner">
                  <div className="w-2.5 h-2.5 rounded-full bg-cyan-400/90 shadow-[0_0_10px_#06b6d4] animate-pulse" />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Thin Glass Rim Highlight */}
        <div className="absolute inset-0 rounded-full border border-white/15 pointer-events-none" />
      </div>
    </div>
  );
};
