import React, { useState } from "react";
import { OrbState, ThemeId } from "../types";
import { Mic, X } from "lucide-react";

interface FloatingAssistantProps {
  enabled: boolean;
  state: OrbState;
  onClick: () => void;
  theme?: ThemeId;
}

export const FloatingAssistant: React.FC<FloatingAssistantProps> = ({
  enabled,
  state,
  onClick,
}) => {
  if (!enabled) return null;

  return (
    <div className="fixed bottom-24 right-4 z-40 animate-in fade-in zoom-in duration-300">
      <button
        onClick={onClick}
        aria-label="Tani Floating Assistant"
        className="relative w-14 h-14 rounded-full p-0 flex items-center justify-center cursor-pointer group focus:outline-none"
      >
        {/* Luminous Pulsing Glow */}
        <div
          className={`absolute inset-0 rounded-full blur-md transition-all duration-500 ${
            state === "listening"
              ? "bg-cyan-400/70 scale-125 animate-ping"
              : state === "speaking"
              ? "bg-purple-500/60 scale-110 animate-pulse"
              : "bg-cyan-500/30 group-hover:scale-110"
          }`}
        />

        {/* Outer Rotating Energy Ring */}
        <div
          className={`absolute inset-0 rounded-full border-2 border-transparent border-t-cyan-400 border-r-blue-500 ${
            state === "thinking"
              ? "animate-spin duration-700"
              : state === "listening"
              ? "animate-spin duration-1000"
              : "animate-[spin_4s_linear_infinite]"
          }`}
        />

        {/* Inner Glass Center with Mic Icon */}
        <div className="relative w-11 h-11 rounded-full bg-[#0d121c]/90 border border-white/20 flex items-center justify-center backdrop-blur-xl shadow-xl">
          <Mic
            className={`w-5 h-5 transition-colors ${
              state === "listening"
                ? "text-cyan-400 animate-pulse"
                : state === "speaking"
                ? "text-purple-400"
                : "text-gray-200 group-hover:text-cyan-300"
            }`}
          />
        </div>
      </button>
    </div>
  );
};
