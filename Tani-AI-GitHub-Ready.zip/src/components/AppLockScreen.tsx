import React, { useState } from "react";
import { Lock, Fingerprint, KeyRound, AlertTriangle } from "lucide-react";
import { TaniOrb } from "./TaniOrb";

interface AppLockScreenProps {
  storedPin: string;
  biometricEnabled: boolean;
  onUnlock: () => void;
  onResetData: () => void;
}

export const AppLockScreen: React.FC<AppLockScreenProps> = ({
  storedPin,
  biometricEnabled,
  onUnlock,
  onResetData,
}) => {
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const handleKeyPress = (num: string) => {
    if (pin.length < 6) {
      const newPin = pin + num;
      setPin(newPin);
      setError("");

      if (newPin === storedPin) {
        setTimeout(onUnlock, 150);
      } else if (newPin.length === storedPin.length && newPin !== storedPin) {
        setError("Incorrect PIN. Please try again.");
        setTimeout(() => setPin(""), 400);
      }
    }
  };

  const handleDelete = () => {
    setPin(pin.slice(0, -1));
    setError("");
  };

  const handleBiometricAuth = async () => {
    if (window.PublicKeyCredential) {
      try {
        // Simulate or invoke WebAuthn / Biometric prompt
        onUnlock();
      } catch (e) {
        setError("Biometric authentication was cancelled.");
      }
    } else {
      onUnlock();
    }
  };

  return (
    <div
      id="tani-app-lock-screen"
      className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-[#07090e] text-white px-6 py-10 select-none"
    >
      <div className="w-full flex justify-center pt-2">
        <div className="flex items-center gap-1.5 text-xs text-purple-300/80 bg-purple-900/30 px-3 py-1 rounded-full border border-purple-500/20">
          <Lock className="w-3.5 h-3.5 text-purple-400" />
          <span>Tani AI Security Lock</span>
        </div>
      </div>

      <div className="flex flex-col items-center text-center max-w-sm w-full">
        <div className="mb-4 transform scale-75">
          <TaniOrb state="idle" size="sm" />
        </div>

        <h2 className="text-xl font-bold tracking-wide mb-1">Enter Security PIN</h2>
        <p className="text-xs text-gray-400 mb-6">Enter your PIN to access Tani AI</p>

        {/* PIN Dots */}
        <div className="flex gap-4 mb-4">
          {Array.from({ length: Math.max(storedPin.length, 4) }).map((_, i) => (
            <div
              key={i}
              className={`w-3.5 h-3.5 rounded-full border border-purple-400/50 transition-all ${
                i < pin.length
                  ? "bg-gradient-to-r from-purple-400 to-pink-400 scale-110 shadow-[0_0_10px_#a855f7]"
                  : "bg-transparent"
              }`}
            />
          ))}
        </div>

        {error && <p className="text-rose-400 text-xs mb-4 animate-shake">{error}</p>}

        {/* Keypad */}
        <div className="grid grid-cols-3 gap-3 w-64 max-w-full">
          {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((num) => (
            <button
              key={num}
              onClick={() => handleKeyPress(num)}
              className="w-16 h-16 rounded-full bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 active:scale-95 text-xl font-semibold flex items-center justify-center transition-all cursor-pointer shadow-sm"
            >
              {num}
            </button>
          ))}
          {biometricEnabled ? (
            <button
              onClick={handleBiometricAuth}
              title="Biometric Unlock"
              className="w-16 h-16 rounded-full bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/30 flex items-center justify-center transition-all cursor-pointer active:scale-95"
            >
              <Fingerprint className="w-6 h-6 text-purple-400" />
            </button>
          ) : (
            <div />
          )}
          <button
            onClick={() => handleKeyPress("0")}
            className="w-16 h-16 rounded-full bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 active:scale-95 text-xl font-semibold flex items-center justify-center transition-all cursor-pointer shadow-sm"
          >
            0
          </button>
          <button
            onClick={handleDelete}
            className="w-16 h-16 rounded-full bg-white/[0.04] hover:bg-white/[0.09] text-xs font-medium text-gray-400 flex items-center justify-center transition-all cursor-pointer active:scale-95"
          >
            Delete
          </button>
        </div>
      </div>

      {/* Safe Reset / Forgot PIN */}
      <div className="w-full text-center">
        {!showResetConfirm ? (
          <button
            onClick={() => setShowResetConfirm(true)}
            className="text-xs text-gray-500 hover:text-gray-300 transition-colors underline cursor-pointer"
          >
            Forgot PIN? Safe reset options
          </button>
        ) : (
          <div className="bg-rose-950/40 border border-rose-800/50 p-4 rounded-2xl max-w-sm mx-auto text-left text-xs text-rose-200 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-rose-400">
              <AlertTriangle className="w-4 h-4" />
              <span>Safe Data Reset</span>
            </div>
            <p className="text-gray-300 leading-relaxed">
              If you forgot your PIN, you can safely reset local security. This will clear stored
              credentials and return to the setup state.
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-3 py-1.5 rounded-lg bg-white/10 text-gray-300 hover:bg-white/20 text-xs"
              >
                Cancel
              </button>
              <button
                onClick={onResetData}
                className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-medium text-xs shadow-sm"
              >
                Reset & Unlock
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
