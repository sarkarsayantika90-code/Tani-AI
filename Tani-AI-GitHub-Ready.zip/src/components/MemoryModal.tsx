import React, { useState } from "react";
import { Brain, Plus, Trash2, X, Sparkles } from "lucide-react";

interface MemoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  memories: string[];
  onAddMemory: (note: string) => void;
  onDeleteMemory: (index: number) => void;
  onClearMemories: () => void;
}

export const MemoryModal: React.FC<MemoryModalProps> = ({
  isOpen,
  onClose,
  memories,
  onAddMemory,
  onDeleteMemory,
  onClearMemories,
}) => {
  const [newNote, setNewNote] = useState("");

  if (!isOpen) return null;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (newNote.trim()) {
      onAddMemory(newNote.trim());
      setNewNote("");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fade-in select-none">
      <div className="relative w-full max-w-lg bg-[#0d1019] border border-white/10 rounded-2xl p-6 shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-500/15 flex items-center justify-center text-purple-400">
              <Brain className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">Tani Memory Engine</h3>
              <p className="text-xs text-gray-400">Context & long-term personalization</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Input */}
        <form onSubmit={handleAdd} className="py-4 border-b border-white/10 flex gap-2">
          <input
            type="text"
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
            placeholder="Teach Tani a fact or preference..."
            className="flex-1 px-4 py-2.5 rounded-xl bg-white/[0.05] border border-white/10 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-purple-400/60"
          />
          <button
            type="submit"
            disabled={!newNote.trim()}
            className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-xs font-semibold text-white flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add</span>
          </button>
        </form>

        {/* List of Memories */}
        <div className="flex-1 overflow-y-auto py-4 space-y-2.5">
          {memories.length === 0 ? (
            <div className="text-center py-8">
              <Brain className="w-8 h-8 text-gray-600 mx-auto mb-2 opacity-40" />
              <p className="text-xs text-gray-400">Memory is empty</p>
              <p className="text-[10px] text-gray-500 mt-1">
                Tani will remember details you share during conversations.
              </p>
            </div>
          ) : (
            memories.map((note, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl bg-white/[0.03] border border-white/5 flex items-center justify-between group hover:bg-white/[0.05] transition-colors"
              >
                <div className="flex items-start gap-2.5">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400 mt-0.5 shrink-0" />
                  <p className="text-xs text-gray-300 select-text">{note}</p>
                </div>
                <button
                  onClick={() => onDeleteMemory(idx)}
                  className="p-1.5 rounded-lg opacity-0 group-hover:opacity-100 hover:bg-rose-500/20 text-gray-500 hover:text-rose-400 transition-all cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-white/10 flex items-center justify-between">
          <button
            onClick={onClearMemories}
            className="text-xs text-gray-500 hover:text-rose-400 transition-colors cursor-pointer"
          >
            Clear all memory
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
