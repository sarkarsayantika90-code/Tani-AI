import React, { useState, useEffect } from "react";
import { PermissionItem, PermissionStatus } from "../types";
import {
  Mic,
  Camera,
  MapPin,
  Users,
  Bell,
  Bluetooth,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowLeft,
} from "lucide-react";

interface PermissionsViewProps {
  onBack: () => void;
}

export const PermissionsView: React.FC<PermissionsViewProps> = ({ onBack }) => {
  const [permissions, setPermissions] = useState<PermissionItem[]>([
    {
      id: "mic",
      name: "Microphone",
      description: "Required for voice conversation, wake word listening, and instant interrupt.",
      status: "PENDING",
      required: true,
    },
    {
      id: "camera",
      name: "Camera",
      description: "Required for capturing photos and visual reasoning with Gemini.",
      status: "PENDING",
    },
    {
      id: "location",
      name: "Location",
      description: "Used to fetch live weather and local time for your vicinity.",
      status: "PENDING",
    },
    {
      id: "notifications",
      name: "Notifications",
      description: "Alerts for completed background tasks, reminders, and timers.",
      status: "PENDING",
    },
    {
      id: "contacts",
      name: "Contacts",
      description: "Used to place calls and send WhatsApp messages when explicitly asked.",
      status: "PENDING",
    },
    {
      id: "bluetooth",
      name: "Bluetooth / Audio",
      description: "Connect external microphones or wireless headsets.",
      status: "PENDING",
    },
  ]);

  // Probe actual browser permission states where available
  useEffect(() => {
    const probePermissions = async () => {
      if (typeof navigator === "undefined" || !navigator.permissions) return;

      const updated = [...permissions];
      try {
        const micStatus = await navigator.permissions.query({ name: "microphone" as any });
        const micIdx = updated.findIndex((p) => p.id === "mic");
        if (micIdx !== -1) {
          updated[micIdx].status =
            micStatus.state === "granted"
              ? "ALLOWED"
              : micStatus.state === "denied"
              ? "DENIED"
              : "PENDING";
        }
      } catch (e) {
        // ignore
      }

      try {
        const camStatus = await navigator.permissions.query({ name: "camera" as any });
        const camIdx = updated.findIndex((p) => p.id === "camera");
        if (camIdx !== -1) {
          updated[camIdx].status =
            camStatus.state === "granted"
              ? "ALLOWED"
              : camStatus.state === "denied"
              ? "DENIED"
              : "PENDING";
        }
      } catch (e) {
        // ignore
      }

      try {
        const geoStatus = await navigator.permissions.query({ name: "geolocation" as any });
        const geoIdx = updated.findIndex((p) => p.id === "location");
        if (geoIdx !== -1) {
          updated[geoIdx].status =
            geoStatus.state === "granted"
              ? "ALLOWED"
              : geoStatus.state === "denied"
              ? "DENIED"
              : "PENDING";
        }
      } catch (e) {
        // ignore
      }

      setPermissions(updated);
    };

    probePermissions();
  }, []);

  const handleRequestPermission = async (id: string) => {
    if (id === "mic") {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((track) => track.stop());
        updateStatus(id, "ALLOWED");
      } catch (e) {
        updateStatus(id, "DENIED");
      }
    } else if (id === "camera") {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        stream.getTracks().forEach((track) => track.stop());
        updateStatus(id, "ALLOWED");
      } catch (e) {
        updateStatus(id, "DENIED");
      }
    } else if (id === "location") {
      navigator.geolocation.getCurrentPosition(
        () => updateStatus(id, "ALLOWED"),
        () => updateStatus(id, "DENIED")
      );
    } else if (id === "notifications") {
      if (typeof Notification !== "undefined") {
        const res = await Notification.requestPermission();
        updateStatus(id, res === "granted" ? "ALLOWED" : "DENIED");
      } else {
        updateStatus(id, "ALLOWED");
      }
    } else {
      // Mock grant for contacts / bluetooth in web sandbox
      updateStatus(id, "ALLOWED");
    }
  };

  const updateStatus = (id: string, status: PermissionStatus) => {
    setPermissions((prev) =>
      prev.map((p) => (p.id === id ? { ...p, status } : p))
    );
  };

  const getIcon = (id: string) => {
    switch (id) {
      case "mic":
        return <Mic className="w-5 h-5 text-purple-400" />;
      case "camera":
        return <Camera className="w-5 h-5 text-pink-400" />;
      case "location":
        return <MapPin className="w-5 h-5 text-emerald-400" />;
      case "contacts":
        return <Users className="w-5 h-5 text-cyan-400" />;
      case "notifications":
        return <Bell className="w-5 h-5 text-amber-400" />;
      case "bluetooth":
        return <Bluetooth className="w-5 h-5 text-blue-400" />;
      default:
        return <Mic className="w-5 h-5 text-purple-400" />;
    }
  };

  return (
    <div id="tani-permissions-view" className="flex-1 w-full overflow-y-auto px-4 py-4 space-y-4">
      <div className="flex items-center gap-3 pb-2 border-b border-white/10">
        <button
          onClick={onBack}
          className="p-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-gray-300 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h2 className="text-lg font-bold text-white tracking-wide">Device Permissions</h2>
          <p className="text-xs text-gray-400">Manage Android runtime permissions</p>
        </div>
      </div>

      <div className="space-y-3">
        {permissions.map((perm) => {
          const isAllowed = perm.status === "ALLOWED";
          const isDenied = perm.status === "DENIED";

          return (
            <div
              key={perm.id}
              className="p-4 rounded-2xl bg-[#111420]/80 border border-white/10 shadow-lg backdrop-blur-md flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div className="flex items-start gap-3">
                <div className="p-2.5 rounded-xl bg-white/[0.05] border border-white/5 shrink-0">
                  {getIcon(perm.id)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-semibold text-white">{perm.name}</h3>
                    {perm.required && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                        Essential
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-gray-400 mt-0.5 leading-relaxed">
                    {perm.description}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between sm:justify-end gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-white/5">
                <div className="flex items-center gap-1.5 text-xs font-semibold">
                  {isAllowed ? (
                    <span className="flex items-center gap-1 text-emerald-400 bg-emerald-950/40 px-2.5 py-1 rounded-full border border-emerald-800/40 text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      ALLOWED
                    </span>
                  ) : isDenied ? (
                    <span className="flex items-center gap-1 text-rose-400 bg-rose-950/40 px-2.5 py-1 rounded-full border border-rose-800/40 text-[11px]">
                      <XCircle className="w-3.5 h-3.5" />
                      DENIED
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-amber-400 bg-amber-950/40 px-2.5 py-1 rounded-full border border-amber-800/40 text-[11px]">
                      <Clock className="w-3.5 h-3.5" />
                      PENDING
                    </span>
                  )}
                </div>

                {!isAllowed && (
                  <button
                    onClick={() => handleRequestPermission(perm.id)}
                    className="px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Grant Access
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
