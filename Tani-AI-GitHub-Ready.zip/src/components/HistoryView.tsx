import React, { useState } from "react";
import { Conversation } from "../types";
import {
  MessageSquare,
  Search,
  Trash2,
  Edit2,
  Check,
  X,
  Clock,
  ArrowRight,
} from "lucide-react";

interface HistoryViewProps {
  conversations: Conversation[];
  activeId: string | null;
  onSelectConversation: (id: string) => void;
  onRenameConversation: (id: string, newTitle: string) => void;
  onDeleteConversation: (id: string) => void;
  onClearAll: () => void;
  onNewChat: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  conversations,
  activeId,
  onSelectConversation,
  onRenameConversation,
  onDeleteConversation,
  onClearAll,
  onNewChat,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");

  const filtered = conversations.filter(
    (c) =>
      c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const startRename = (conv: Conversation) => {
    setEditingId(conv.id);
    setEditTitle(conv.title);
  };

  const saveRename = (id: string) => {
    if (editTitle.trim()) {
      onRenameConversation(id, editTitle.trim());
    }
    setEditingId(null);
  };

  return (
    <div id="tani-history-view" className="flex-1 w-full overflow-y-auto px-4 py-4 space-y-4">
      {/* Search & Actions Header */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white tracking-wide">Chat History</h2>
            <p className="text-xs text-gray-400">Contextual sessions & memory</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onNewChat}
              className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white shadow transition-colors cursor-pointer"
            >
              New Chat
            </button>
            {conversations.length > 0 && (
              <button
                onClick={onClearAll}
                title="Clear all history"
                className="p-1.5 rounded-xl bg-white/[0.05] hover:bg-rose-500/20 text-gray-400 hover:text-rose-300 transition-colors cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Search input */}
        <div className="relative">
          <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search conversations..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white/[0.06] border border-white/10 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-purple-400/60"
          />
        </div>
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-64 text-center text-gray-400 space-y-2">
          <MessageSquare className="w-8 h-8 text-purple-400/40" />
          <p className="text-sm font-medium text-gray-300">No conversations found</p>
          <p className="text-xs text-gray-500 max-w-xs">
            Your conversations with Tani are securely saved in local storage.
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filtered.map((conv) => {
            const isEditing = editingId === conv.id;
            const isActive = activeId === conv.id;

            return (
              <div
                key={conv.id}
                className={`p-3.5 rounded-2xl border transition-all ${
                  isActive
                    ? "bg-purple-900/30 border-purple-500/50 shadow-md"
                    : "bg-[#111420]/80 border-white/10 hover:border-white/20"
                }`}
              >
                {isEditing ? (
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      className="flex-1 px-3 py-1.5 rounded-xl bg-white/10 border border-purple-400 text-sm text-white focus:outline-none"
                      autoFocus
                    />
                    <button
                      onClick={() => saveRename(conv.id)}
                      className="p-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white"
                    >
                      <Check className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setEditingId(null)}
                      className="p-1.5 rounded-lg bg-white/10 text-gray-300"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-start justify-between gap-2">
                    <div
                      onClick={() => onSelectConversation(conv.id)}
                      className="flex-1 cursor-pointer"
                    >
                      <h4 className="text-sm font-semibold text-white tracking-wide hover:text-purple-300 transition-colors">
                        {conv.title}
                      </h4>
                      <p className="text-xs text-gray-400 line-clamp-1 mt-0.5">
                        {conv.lastMessage || "No messages yet"}
                      </p>
                      <div className="flex items-center gap-1.5 text-[10px] text-gray-500 mt-2">
                        <Clock className="w-3 h-3" />
                        <span>
                          {new Date(conv.timestamp).toLocaleDateString([], {
                            month: "short",
                            day: "numeric",
                          })}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0 pt-0.5">
                      <button
                        onClick={() => startRename(conv)}
                        title="Rename conversation"
                        className="p-1.5 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white transition-colors cursor-pointer"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteConversation(conv.id)}
                        title="Delete conversation"
                        className="p-1.5 rounded-lg hover:bg-rose-500/20 text-gray-400 hover:text-rose-300 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onSelectConversation(conv.id)}
                        title="Open chat"
                        className="p-1.5 rounded-lg bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 transition-colors cursor-pointer ml-1"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
