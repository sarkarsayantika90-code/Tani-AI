import React, { useState, useRef, useEffect } from "react";
import { Message } from "../types";
import {
  Copy,
  Check,
  Download,
  Eye,
  Code2,
  RefreshCw,
  Share2,
  AlertCircle,
  Sparkles,
  ExternalLink,
  Volume2,
} from "lucide-react";

interface ChatViewProps {
  messages: Message[];
  isLoading: boolean;
  onRetry?: (messageId: string) => void;
  onRegenerate?: () => void;
  onSpeak?: (text: string) => void;
  onActionConfirm?: (messageId: string, confirmed: boolean) => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  messages,
  isLoading,
  onRetry,
  onRegenerate,
  onSpeak,
  onActionConfirm,
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [previewWebsiteHtml, setPreviewWebsiteHtml] = useState<string | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownload = (filename: string, content: string) => {
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleShare = async (text: string) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Tani AI Response",
          text,
        });
      } catch (e) {
        // Fallback to copy
        navigator.clipboard.writeText(text);
      }
    } else {
      navigator.clipboard.writeText(text);
    }
  };

  const renderContentWithCode = (content: string, msgId: string) => {
    const parts: React.ReactNode[] = [];
    const codeBlockRegex = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g;
    let lastIndex = 0;
    let match;
    let blockIndex = 0;

    while ((match = codeBlockRegex.exec(content)) !== null) {
      // Text before code
      if (match.index > lastIndex) {
        parts.push(
          <div key={`text-${lastIndex}`} className="whitespace-pre-wrap leading-relaxed">
            {content.substring(lastIndex, match.index)}
          </div>
        );
      }

      const lang = match[1] || "code";
      const code = match[2].trim();
      const isHtml =
        lang === "html" ||
        code.includes("<!DOCTYPE html>") ||
        (code.includes("<html") && code.includes("</html>"));
      const currentBlockId = `${msgId}-code-${blockIndex}`;

      parts.push(
        <div
          key={`code-${match.index}`}
          className="my-3 rounded-2xl overflow-hidden border border-white/10 bg-[#0d111a] shadow-lg"
        >
          {/* Code Header */}
          <div className="flex items-center justify-between px-3 py-2 bg-white/[0.04] border-b border-white/5 text-xs text-gray-400">
            <div className="flex items-center gap-1.5 font-mono">
              <Code2 className="w-3.5 h-3.5 text-purple-400" />
              <span className="uppercase text-[11px] font-semibold tracking-wider text-purple-300">
                {lang}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              {isHtml && (
                <button
                  onClick={() => setPreviewWebsiteHtml(code)}
                  title="Live Preview Website"
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 text-xs transition-colors cursor-pointer"
                >
                  <Eye className="w-3 h-3" />
                  <span>Live Preview</span>
                </button>
              )}
              <button
                onClick={() =>
                  handleDownload(
                    `tani_generated_${blockIndex}.${lang === "kotlin" ? "kt" : lang === "html" ? "html" : "txt"}`,
                    code
                  )
                }
                title="Download file"
                className="p-1 rounded-md hover:bg-white/10 text-gray-400 hover:text-white transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => handleCopy(code, currentBlockId)}
                title="Copy code"
                className="flex items-center gap-1 p-1 px-2 rounded-md hover:bg-white/10 text-gray-300 hover:text-white transition-colors cursor-pointer text-xs"
              >
                {copiedId === currentBlockId ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400 text-[10px]">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span className="text-[10px]">Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Code Viewer Body */}
          <div className="p-3.5 overflow-x-auto max-h-80 font-mono text-xs leading-relaxed text-gray-200">
            <pre className="select-text">{code}</pre>
          </div>
        </div>
      );

      lastIndex = match.index + match[0].length;
      blockIndex++;
    }

    // Remaining text
    if (lastIndex < content.length) {
      parts.push(
        <div key={`text-${lastIndex}`} className="whitespace-pre-wrap leading-relaxed">
          {content.substring(lastIndex)}
        </div>
      );
    }

    return parts;
  };

  return (
    <div id="tani-chat-view" className="flex-1 w-full overflow-y-auto px-4 py-4 space-y-4">
      {messages.length === 0 && (
        <div className="flex flex-col items-center justify-center h-64 text-center text-gray-400 space-y-2">
          <Sparkles className="w-8 h-8 text-purple-400/60 animate-pulse" />
          <p className="text-sm font-medium text-gray-300">Start a conversation with Tani</p>
          <p className="text-xs text-gray-500 max-w-xs">
            Ask questions, code, translate, generate websites, or speak in Bengali, Hindi, and English.
          </p>
        </div>
      )}

      {messages.map((msg) => {
        const isUser = msg.role === "user";

        return (
          <div
            key={msg.id}
            id={`message-${msg.id}`}
            className={`flex flex-col ${isUser ? "items-end" : "items-start"} w-full select-text`}
          >
            {/* Attachment preview if user provided image */}
            {msg.image && (
              <div className="mb-2 max-w-[75%] sm:max-w-xs rounded-2xl overflow-hidden border border-white/10 shadow-md">
                <img
                  src={msg.image}
                  alt="Attachment"
                  className="w-full h-auto object-cover max-h-48"
                  referrerPolicy="no-referrer"
                />
              </div>
            )}

            {/* Message Bubble */}
            <div
              className={`relative max-w-[88%] sm:max-w-[80%] rounded-3xl p-4 text-sm leading-relaxed backdrop-blur-md shadow-lg transition-all ${
                isUser
                  ? "bg-gradient-to-r from-purple-600/90 to-indigo-600/90 text-white rounded-tr-sm border border-purple-400/30"
                  : msg.isError
                  ? "bg-rose-950/40 text-rose-200 border border-rose-800/50 rounded-tl-sm"
                  : "bg-[#111420]/85 text-gray-100 border border-white/10 rounded-tl-sm"
              }`}
            >
              {/* Header for Tani */}
              {!isUser && (
                <div className="flex items-center justify-between gap-2 mb-2 pb-1 border-b border-white/5 text-[11px] text-purple-300/80">
                  <div className="flex items-center gap-1.5 font-semibold">
                    <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
                    <span>Tani</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {onSpeak && (
                      <button
                        onClick={() => onSpeak(msg.content)}
                        title="Read aloud"
                        className="p-1 hover:bg-white/10 rounded text-gray-400 hover:text-purple-300 transition-colors"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      onClick={() => handleCopy(msg.content, msg.id)}
                      title="Copy response"
                      className="p-1 hover:bg-white/10 rounded text-gray-400 hover:text-white transition-colors"
                    >
                      {copiedId === msg.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <button
                      onClick={() => handleShare(msg.content)}
                      title="Share response"
                      className="p-1 hover:bg-white/10 rounded text-gray-400 hover:text-white transition-colors"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Body Content */}
              <div className="select-text">
                {renderContentWithCode(msg.content, msg.id)}
              </div>

              {/* Interactive Confirmation Card (Communication / High Risk Actions) */}
              {msg.confirmationAction && (
                <div className="mt-3 p-3.5 rounded-2xl bg-white/[0.06] border border-amber-500/30 text-xs shadow-inner">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-amber-300 text-[11px] uppercase tracking-wide flex items-center gap-1.5">
                      <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                      Confirmation Required ({msg.confirmationAction.type})
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        msg.confirmationAction.status === "confirmed"
                          ? "bg-emerald-500/20 text-emerald-300"
                          : msg.confirmationAction.status === "cancelled"
                          ? "bg-rose-500/20 text-rose-300"
                          : "bg-amber-500/20 text-amber-300 animate-pulse"
                      }`}
                    >
                      {msg.confirmationAction.status === "confirmed"
                        ? "Confirmed & Sent"
                        : msg.confirmationAction.status === "cancelled"
                        ? "Cancelled"
                        : "Awaiting Confirmation"}
                    </span>
                  </div>

                  {msg.confirmationAction.status === "pending" && onActionConfirm && (
                    <div className="flex items-center gap-2.5 mt-3 pt-2 border-t border-white/10">
                      <button
                        onClick={() => onActionConfirm(msg.id, true)}
                        className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold text-xs shadow-md transition-all active:scale-[0.98] cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>{msg.confirmationAction.confirmLabel || "SEND"}</span>
                      </button>
                      <button
                        onClick={() => onActionConfirm(msg.id, false)}
                        className="py-2 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-gray-300 hover:text-white font-medium text-xs transition-colors active:scale-[0.98] cursor-pointer"
                      >
                        <span>{msg.confirmationAction.cancelLabel || "CANCEL"}</span>
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Tool Execution Notification Pill */}
              {msg.toolCall && (
                <div className="mt-3 p-2.5 rounded-xl bg-white/[0.05] border border-purple-500/20 text-xs flex items-center justify-between text-purple-200">
                  <span className="font-mono text-[11px]">Tool: {msg.toolCall.name}()</span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                      msg.toolCall.status === "executed"
                        ? "bg-emerald-500/20 text-emerald-300"
                        : msg.toolCall.status === "cancelled"
                        ? "bg-gray-500/20 text-gray-300"
                        : "bg-amber-500/20 text-amber-300"
                    }`}
                  >
                    {msg.toolCall.status}
                  </span>
                </div>
              )}

              {/* Retry button for error states */}
              {msg.isError && onRetry && (
                <div className="mt-3 flex items-center gap-2">
                  <button
                    onClick={() => onRetry(msg.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold shadow transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Retry failed request</span>
                  </button>
                </div>
              )}
            </div>

            {/* Timestamp */}
            <span className="text-[10px] text-gray-500 mt-1 px-2">
              {new Date(msg.timestamp).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </span>
          </div>
        );
      })}

      {/* Loading Thinking Bubble */}
      {isLoading && (
        <div className="flex items-start w-full">
          <div className="rounded-3xl rounded-tl-sm p-4 bg-[#111420]/80 border border-white/10 text-xs text-purple-300 flex items-center gap-3 backdrop-blur-md">
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" />
              <span
                className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce"
                style={{ animationDelay: "150ms" }}
              />
              <span
                className="w-2 h-2 rounded-full bg-pink-400 animate-bounce"
                style={{ animationDelay: "300ms" }}
              />
            </div>
            <span className="font-medium tracking-wide">Tani is thinking...</span>
          </div>
        </div>
      )}

      <div ref={messagesEndRef} />

      {/* Website Preview Iframe Modal */}
      {previewWebsiteHtml && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-3xl h-[85vh] rounded-3xl bg-[#111420] border border-white/15 flex flex-col overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between px-4 py-3 bg-white/[0.04] border-b border-white/10">
              <div className="flex items-center gap-2 text-sm font-semibold text-white">
                <ExternalLink className="w-4 h-4 text-purple-400" />
                <span>Live Website Preview (Generated by Tani)</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleDownload("tani_website.html", previewWebsiteHtml)}
                  className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white transition-colors"
                >
                  Save HTML
                </button>
                <button
                  onClick={() => setPreviewWebsiteHtml(null)}
                  className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-gray-300 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
            <div className="flex-1 w-full h-full bg-white">
              <iframe
                title="Tani Website Preview"
                srcDoc={previewWebsiteHtml}
                className="w-full h-full border-0"
                sandbox="allow-scripts allow-modals allow-forms"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
