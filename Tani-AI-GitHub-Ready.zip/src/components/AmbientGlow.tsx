import React from "react";
import { OrbState, ThemeId } from "../types";

interface AmbientGlowProps {
  enabled: boolean;
  intensity: "low" | "medium" | "high";
  state: OrbState;
  theme?: ThemeId;
}

export const AmbientGlow: React.FC<AmbientGlowProps> = ({
  enabled,
  intensity,
  state,
}) => {
  if (!enabled) return null;

  const opacityClass =
    intensity === "low"
      ? "opacity-25"
      : intensity === "high"
      ? "opacity-65"
      : "opacity-45";

  let glowStyle = "from-cyan-500/20 via-blue-600/15 to-purple-600/20";

  if (state === "listening") {
    glowStyle = "from-cyan-400/35 via-teal-500/25 to-blue-500/30";
  } else if (state === "thinking") {
    glowStyle = "from-blue-600/30 via-indigo-600/35 to-purple-600/35";
  } else if (state === "speaking") {
    glowStyle = "from-cyan-400/35 via-blue-500/30 to-pink-500/35";
  } else if (state === "working") {
    glowStyle = "from-sky-400/30 via-cyan-500/25 to-blue-600/30";
  } else if (state === "error") {
    glowStyle = "from-rose-500/30 via-red-500/25 to-pink-600/25";
  }

  return (
    <div
      className={`fixed inset-0 pointer-events-none z-0 transition-opacity duration-700 ${opacityClass}`}
    >
      {/* Top Edge Ambient Beam */}
      <div
        className={`absolute top-0 inset-x-0 h-40 bg-gradient-to-b ${glowStyle} blur-3xl`}
      />
      {/* Bottom Edge Ambient Beam */}
      <div
        className={`absolute bottom-0 inset-x-0 h-32 bg-gradient-to-t ${glowStyle} blur-3xl`}
      />
      {/* Left/Right Vignette */}
      <div
        className={`absolute inset-y-0 left-0 w-24 bg-gradient-to-r ${glowStyle} blur-3xl`}
      />
      <div
        className={`absolute inset-y-0 right-0 w-24 bg-gradient-to-l ${glowStyle} blur-3xl`}
      />
    </div>
  );
};
