import React from "react";
import { OrbState } from "../types";

interface TaniOrbProps {
  state: OrbState;
  onClick?: () => void;
  size?: "sm" | "md" | "lg";
  glowEffect?: boolean;
}

export const TaniOrb: React.FC<TaniOrbProps> = ({
  state,
  onClick,
  size = "lg",
  glowEffect = true,
}) => {
  const sizeClasses = {
    sm: "w-24 h-24",
    md: "w-44 h-44",
    lg: "w-64 h-64 sm:w-72 sm:h-72",
  }[size];

  // Dynamic theme colors per state
  const colors = {
    idle: {
      core: "from-indigo-500 via-purple-600 to-pink-500",
      glow: "rgba(147, 51, 234, 0.45)",
      ring: "border-purple-400/40",
      pulseSpeed: "duration-[3500ms]",
      statusText: "Ready",
    },
    listening: {
      core: "from-cyan-400 via-teal-500 to-blue-600",
      glow: "rgba(6, 182, 212, 0.65)",
      ring: "border-cyan-300/70",
      pulseSpeed: "duration-[1200ms]",
      statusText: "Listening...",
    },
    thinking: {
      core: "from-violet-500 via-fuchsia-600 to-indigo-500",
      glow: "rgba(168, 85, 247, 0.7)",
      ring: "border-violet-300/80",
      pulseSpeed: "duration-[900ms]",
      statusText: "Thinking...",
    },
    speaking: {
      core: "from-pink-500 via-rose-500 to-amber-400",
      glow: "rgba(244, 63, 94, 0.65)",
      ring: "border-pink-300/80",
      pulseSpeed: "duration-[800ms]",
      statusText: "Speaking...",
    },
    working: {
      core: "from-amber-400 via-cyan-500 to-emerald-500",
      glow: "rgba(16, 185, 129, 0.65)",
      ring: "border-emerald-300/80",
      pulseSpeed: "duration-[1000ms]",
      statusText: "Working...",
    },
    error: {
      core: "from-rose-600 via-red-500 to-amber-600",
      glow: "rgba(239, 68, 68, 0.6)",
      ring: "border-red-400/60",
      pulseSpeed: "duration-[1400ms]",
      statusText: "Attention Needed",
    },
  }[state] || {
    core: "from-indigo-500 via-purple-600 to-pink-500",
    glow: "rgba(147, 51, 234, 0.45)",
    ring: "border-purple-400/40",
    pulseSpeed: "duration-[3500ms]",
    statusText: "Ready",
  };

  return (
    <div
      id="tani-orb-container"
      onClick={onClick}
      className={`relative flex items-center justify-center cursor-pointer select-none transition-all group ${sizeClasses}`}
    >
      {/* Outer ambient glow halo */}
      {glowEffect && (
        <div
          className={`absolute inset-0 rounded-full blur-3xl opacity-80 animate-pulse ${colors.pulseSpeed}`}
          style={{ background: colors.glow }}
        />
      )}

      {/* Rotating outer orbital ring */}
      <div
        className={`absolute -inset-4 sm:-inset-6 rounded-full border border-dashed ${colors.ring} animate-[spin_12s_linear_infinite] opacity-60`}
      />

      {/* Counter-rotating inner orbit ring */}
      <div
        className={`absolute -inset-2 sm:-inset-3 rounded-full border border-dotted ${colors.ring} animate-[spin_8s_linear_infinite_reverse] opacity-50`}
      />

      {/* Dynamic waveform ripples for listening and speaking */}
      {(state === "listening" || state === "speaking") && (
        <>
          <div
            className={`absolute -inset-8 rounded-full border border-cyan-400/30 animate-ping opacity-40 duration-1000`}
          />
          <div
            className={`absolute -inset-12 rounded-full border border-pink-400/20 animate-ping opacity-30 duration-1500`}
          />
        </>
      )}

      {/* Thinking orbital particles */}
      {state === "thinking" && (
        <div className="absolute inset-0 flex items-center justify-center animate-[spin_2s_linear_infinite]">
          <div className="w-3 h-3 bg-violet-300 rounded-full shadow-[0_0_12px_#c084fc] translate-x-20 sm:translate-x-28" />
          <div className="w-2 h-2 bg-fuchsia-300 rounded-full shadow-[0_0_10px_#e879f9] -translate-x-20 sm:-translate-x-28" />
        </div>
      )}

      {/* Core glowing orb sphere */}
      <div
        className={`relative w-full h-full rounded-full bg-gradient-to-tr ${colors.core} shadow-[inset_0_0_30px_rgba(255,255,255,0.6),0_0_40px_${colors.glow}] flex items-center justify-center overflow-hidden transition-all duration-500`}
      >
        {/* Specular sheen layer */}
        <div className="absolute top-2 left-4 w-1/2 h-1/3 bg-white/40 rounded-full blur-[2px] transform -rotate-25 pointer-events-none" />

        {/* Dynamic center waveform / audio visualization */}
        {state === "speaking" && (
          <div className="flex items-center gap-1.5 z-10">
            {[35, 75, 95, 60, 85, 45, 80].map((height, i) => (
              <span
                key={i}
                className="w-1.5 bg-white/90 rounded-full animate-bounce shadow-sm"
                style={{
                  height: `${height}%`,
                  maxHeight: "3rem",
                  animationDelay: `${i * 100}ms`,
                  animationDuration: "600ms",
                }}
              />
            ))}
          </div>
        )}

        {state === "listening" && (
          <div className="flex items-center justify-center z-10">
            <div className="w-14 h-14 rounded-full border-2 border-white/80 animate-ping opacity-75" />
            <div className="absolute w-6 h-6 rounded-full bg-white shadow-[0_0_16px_#ffffff]" />
          </div>
        )}

        {state === "thinking" && (
          <div className="flex items-center justify-center z-10">
            <div className="w-12 h-12 rounded-full border-3 border-white/40 border-t-white animate-spin" />
          </div>
        )}

        {state === "idle" && (
          <div className="z-10 text-center pointer-events-none">
            <span className="text-xl sm:text-2xl font-semibold tracking-wider text-white/95 drop-shadow-[0_2px_8px_rgba(0,0,0,0.5)]">
              Tani
            </span>
          </div>
        )}

        {state === "error" && (
          <div className="z-10 flex flex-col items-center justify-center">
            <span className="text-white text-3xl font-bold">!</span>
          </div>
        )}
      </div>
    </div>
  );
};
