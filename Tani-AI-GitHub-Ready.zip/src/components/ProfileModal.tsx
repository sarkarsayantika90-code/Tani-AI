import React, { useRef } from "react";
import { UserPreferences, ThemeId, EmotionTone } from "../types";
import { X, Camera, Upload, Trash2, Check, Sparkles, User, Palette } from "lucide-react";

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  preferences: UserPreferences;
  onUpdatePreferences: (prefs: Partial<UserPreferences>) => void;
}

const THEMES: { id: ThemeId; name: string; gradient: string; previewColor: string }[] = [
  { id: "midnight", name: "Midnight", gradient: "from-cyan-500 to-blue-600", previewColor: "#06b6d4" },
  { id: "aurora", name: "Aurora", gradient: "from-emerald-400 to-cyan-500", previewColor: "#10b981" },
  { id: "ocean", name: "Ocean", gradient: "from-sky-400 to-blue-700", previewColor: "#0ea5e9" },
  { id: "violet", name: "Violet", gradient: "from-purple-500 to-pink-500", previewColor: "#a855f7" },
  { id: "crimson", name: "Crimson", gradient: "from-rose-500 to-orange-500", previewColor: "#f43f5e" },
  { id: "emerald", name: "Emerald", gradient: "from-emerald-500 to-teal-700", previewColor: "#059669" },
];

const EMOTIONS: EmotionTone[] = [
  "Neutral",
  "Calm",
  "Happy",
  "Excited",
  "Playful",
  "Thinking",
  "Concerned",
  "Celebrating",
];

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  preferences,
  onUpdatePreferences,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === "string") {
          onUpdatePreferences({ profilePhoto: reader.result });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    onUpdatePreferences({ profilePhoto: "" });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fade-in select-none">
      <div className="relative w-full max-w-lg bg-[#0d1019] border border-white/10 rounded-2xl p-6 shadow-2xl flex flex-col max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-purple-600 flex items-center justify-center text-white shadow-lg">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">Personalization</h3>
              <p className="text-xs text-gray-400">Profile photo, themes & assistant tone</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Profile Photo Section */}
        <div className="py-4 border-b border-white/10 flex flex-col sm:flex-row items-center gap-5">
          {/* Avatar with Energy Ring Frame */}
          <div className="relative w-24 h-24 rounded-full flex items-center justify-center">
            {/* Outer mini ring effect */}
            <div className="absolute inset-0 rounded-full border border-cyan-400/50 animate-pulse" />
            <div className="absolute inset-1 rounded-full border border-purple-500/40 animate-[spin_8s_linear_infinite]" />
            <div className="relative w-20 h-20 rounded-full overflow-hidden bg-[#131824] flex items-center justify-center border border-white/15 shadow-inner">
              {preferences.profilePhoto ? (
                <img
                  src={preferences.profilePhoto}
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              ) : (
                <User className="w-8 h-8 text-gray-500" />
              )}
            </div>
          </div>

          <div className="flex-1 text-center sm:text-left">
            <h4 className="text-sm font-semibold text-white">Energy Ring Photo</h4>
            <p className="text-xs text-gray-400 mt-0.5">
              Your photo appears inside the center of Tani's Energy Ring with an interactive glow.
            </p>

            <div className="mt-3 flex items-center justify-center sm:justify-start gap-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-medium border border-cyan-500/30 transition-colors cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{preferences.profilePhoto ? "Change Photo" : "Add Photo"}</span>
              </button>
              {preferences.profilePhoto && (
                <button
                  onClick={handleRemovePhoto}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.05] hover:bg-rose-500/20 text-gray-400 hover:text-rose-300 text-xs font-medium transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Remove</span>
                </button>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoSelect}
                className="hidden"
              />
            </div>
          </div>
        </div>

        {/* User Name Input */}
        <div className="py-4 border-b border-white/10">
          <label className="block text-xs font-medium text-gray-300 mb-1.5">
            Your Name (Used for greeting & conversation)
          </label>
          <input
            type="text"
            value={preferences.userName}
            onChange={(e) => onUpdatePreferences({ userName: e.target.value })}
            placeholder="Enter your name"
            className="w-full px-4 py-2.5 rounded-xl bg-white/[0.05] border border-white/10 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400/60"
          />
        </div>

        {/* Theme System */}
        <div className="py-4 border-b border-white/10">
          <div className="flex items-center gap-2 mb-2.5">
            <Palette className="w-4 h-4 text-cyan-400" />
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider">
              Theme System
            </h4>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {THEMES.map((th) => {
              const isSelected = (preferences.theme || "midnight") === th.id;
              return (
                <button
                  key={th.id}
                  onClick={() => onUpdatePreferences({ theme: th.id })}
                  className={`flex items-center justify-between p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    isSelected
                      ? "bg-white/[0.09] border-cyan-400/70 shadow-[0_0_15px_rgba(6,182,212,0.2)]"
                      : "bg-white/[0.03] border-white/5 hover:bg-white/[0.06]"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: th.previewColor }}
                    />
                    <span className="text-xs font-semibold text-gray-200">{th.name}</span>
                  </div>
                  {isSelected && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Conversational Tone / Emotion */}
        <div className="py-4 border-b border-white/10">
          <label className="block text-xs font-medium text-gray-300 mb-2">
            Conversational Tone & Emotion
          </label>
          <div className="flex flex-wrap gap-2">
            {EMOTIONS.map((emo) => {
              const isSelected = (preferences.emotionTone || "Neutral") === emo;
              return (
                <button
                  key={emo}
                  onClick={() => onUpdatePreferences({ emotionTone: emo })}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                    isSelected
                      ? "bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-sm"
                      : "bg-white/[0.04] text-gray-400 hover:bg-white/[0.08] hover:text-gray-200 border border-transparent"
                  }`}
                >
                  {emo}
                </button>
              );
            })}
          </div>
        </div>

        {/* Ambient RGB Edge Lighting Settings */}
        <div className="py-4 border-b border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-xs font-semibold text-white">Ambient RGB Edge Lighting</h4>
              <p className="text-[11px] text-gray-400">
                Responsive screen edge glow during voice and thinking
              </p>
            </div>
            <button
              onClick={() =>
                onUpdatePreferences({ ambientGlowEnabled: !preferences.ambientGlowEnabled })
              }
              className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                preferences.ambientGlowEnabled ? "bg-cyan-500" : "bg-white/10"
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                  preferences.ambientGlowEnabled ? "left-6" : "left-1"
                }`}
              />
            </button>
          </div>

          {preferences.ambientGlowEnabled && (
            <div className="flex items-center gap-2 pt-1">
              <span className="text-xs text-gray-400">Intensity:</span>
              {(["low", "medium", "high"] as const).map((level) => (
                <button
                  key={level}
                  onClick={() => onUpdatePreferences({ ambientGlowIntensity: level })}
                  className={`px-2.5 py-1 rounded-lg text-xs capitalize transition-colors cursor-pointer ${
                    preferences.ambientGlowIntensity === level
                      ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                      : "bg-white/5 text-gray-400 hover:bg-white/10"
                  }`}
                >
                  {level}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Continuous Conversation Voice Mode */}
        <div className="py-4 flex items-center justify-between">
          <div>
            <h4 className="text-xs font-semibold text-white">Continuous Conversation</h4>
            <p className="text-[11px] text-gray-400">
              Tani listens automatically after speaking without re-tapping mic
            </p>
          </div>
          <button
            onClick={() =>
              onUpdatePreferences({ continuousVoice: !preferences.continuousVoice })
            }
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
              preferences.continuousVoice ? "bg-cyan-500" : "bg-white/10"
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                preferences.continuousVoice ? "left-6" : "left-1"
              }`}
            />
          </button>
        </div>

        {/* Done Button */}
        <div className="pt-4 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-xs font-semibold text-white shadow-lg shadow-cyan-500/25 transition-all cursor-pointer"
          >
            Save & Close
          </button>
        </div>
      </div>
    </div>
  );
};
