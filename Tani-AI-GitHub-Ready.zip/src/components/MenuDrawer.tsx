import React from "react";
import {
  Home,
  MessageSquarePlus,
  Mic,
  Activity,
  History,
  Brain,
  Settings,
  Info,
  X,
  Sparkles,
} from "lucide-react";

interface MenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: "home" | "chat" | "tasks" | "history" | "settings" | "memory") => void;
  onNewChat: () => void;
  onVoiceMode: () => void;
  onOpenAbout: () => void;
}

export const MenuDrawer: React.FC<MenuDrawerProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onNewChat,
  onVoiceMode,
  onOpenAbout,
}) => {
  if (!isOpen) return null;

  const items = [
    {
      id: "home",
      label: "Home",
      icon: Home,
      description: "Assistant Dashboard & Energy Ring",
      action: () => {
        onNavigate("home");
        onClose();
      },
    },
    {
      id: "new_chat",
      label: "New Chat",
      icon: MessageSquarePlus,
      description: "Start fresh conversation",
      action: () => {
        onNewChat();
        onClose();
      },
    },
    {
      id: "voice",
      label: "Voice Mode",
      icon: Mic,
      description: "Continuous speech interaction",
      action: () => {
        onVoiceMode();
        onClose();
      },
    },
    {
      id: "tasks",
      label: "Tasks",
      icon: Activity,
      description: "Background jobs & websites",
      action: () => {
        onNavigate("tasks");
        onClose();
      },
    },
    {
      id: "history",
      label: "History",
      icon: History,
      description: "Previous chats & archives",
      action: () => {
        onNavigate("history");
        onClose();
      },
    },
    {
      id: "memory",
      label: "Memory",
      icon: Brain,
      description: "Long-term facts & personalization",
      action: () => {
        onNavigate("memory");
        onClose();
      },
    },
    {
      id: "settings",
      label: "Settings",
      icon: Settings,
      description: "Preferences, Theme & Keystore",
      action: () => {
        onNavigate("settings");
        onClose();
      },
    },
    {
      id: "about",
      label: "About",
      icon: Info,
      description: "Version, Creator & Support",
      action: () => {
        onOpenAbout();
        onClose();
      },
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/70 backdrop-blur-sm animate-fade-in"
      />

      {/* Drawer Panel */}
      <div className="relative w-80 max-w-[85vw] h-full bg-[#0c0f17]/95 border-r border-white/10 p-5 flex flex-col justify-between z-10 backdrop-blur-2xl shadow-2xl animate-in slide-in-from-left duration-300">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div>
                <h3 className="text-base font-semibold tracking-wide text-white">Tani AI</h3>
                <p className="text-[10px] text-gray-400 font-mono">Personal Assistant</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation Items */}
          <div className="mt-4 space-y-1">
            {items.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={item.action}
                  className="w-full flex items-center gap-3.5 px-3.5 py-2.5 rounded-xl text-left hover:bg-white/[0.07] active:bg-white/10 transition-all group cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-lg bg-white/[0.04] group-hover:bg-cyan-500/10 flex items-center justify-center text-gray-300 group-hover:text-cyan-400 transition-colors">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-semibold text-gray-200 group-hover:text-white transition-colors">
                      {item.label}
                    </div>
                    <div className="text-[10px] text-gray-500 truncate">
                      {item.description}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-white/10 text-center">
          <p className="text-[11px] font-medium text-gray-400">Tani AI</p>
          <p className="text-[10px] text-gray-500 mt-0.5">Made by Anik</p>
          <p className="text-[9px] text-gray-600 mt-1">anikmondal8680@gmail.com</p>
        </div>
      </div>
    </div>
  );
};
