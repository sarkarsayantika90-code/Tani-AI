import { DetectedLanguage } from "../types";

export interface PlannedResponse {
  voiceSpokenText: string;
  textDisplayText: string;
  suggestedEmotion: "Happy" | "Calm" | "Neutral" | "Excited" | "Thinking";
}

export class ResponsePlanner {
  private static instance: ResponsePlanner | null = null;

  private constructor() {}

  public static getInstance(): ResponsePlanner {
    if (!ResponsePlanner.instance) {
      ResponsePlanner.instance = new ResponsePlanner();
    }
    return ResponsePlanner.instance;
  }

  /**
   * Crafts a concise, natural spoken utterance alongside a rich text display
   */
  public plan(params: {
    rawModelText: string;
    actionResult?: string;
    lang: DetectedLanguage;
    isToolExecution?: boolean;
    hasCodeBlocks?: boolean;
    isWebsiteCreation?: boolean;
  }): PlannedResponse {
    const { rawModelText, actionResult, lang, hasCodeBlocks, isWebsiteCreation } = params;

    // 1. Tool / Action execution response
    if (actionResult) {
      return {
        voiceSpokenText: actionResult,
        textDisplayText: actionResult,
        suggestedEmotion: "Happy",
      };
    }

    // 2. Website creation
    if (isWebsiteCreation) {
      const voiceText =
        lang === "bn" || lang === "bn-en"
          ? "আপনার জন্য ওয়েবসাইট তৈরি করে দিয়েছি। লাইভ প্রিভিউ দেখুন।"
          : "I have built the website for you. Check out the live preview.";
      return {
        voiceSpokenText: voiceText,
        textDisplayText: rawModelText,
        suggestedEmotion: "Excited",
      };
    }

    // 3. Coding answer (Do NOT speak an entire page of code!)
    if (hasCodeBlocks) {
      const voiceText =
        lang === "bn" || lang === "bn-en"
          ? "কোড তৈরি করেছি। নিচে বিস্তারিত দেখে নিন।"
          : "I have written the code. You can find it right below.";
      return {
        voiceSpokenText: voiceText,
        textDisplayText: rawModelText,
        suggestedEmotion: "Calm",
      };
    }

    // 4. Clean spoken text for natural voice: strip markdown links, backticks, stars, bolding
    let cleanVoice = rawModelText
      .replace(/```[\s\S]*?```/g, "")
      .replace(/`([^`]+)`/g, "$1")
      .replace(/\*\*([^*]+)\*\*/g, "$1")
      .replace(/\*([^*]+)\*/g, "$1")
      .replace(/#+\s+/g, "")
      .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
      .trim();

    // Keep voice concise if it's overly lengthy
    if (cleanVoice.length > 250) {
      const firstSentence = cleanVoice.split(/[.?!।\n]/)[0];
      if (firstSentence && firstSentence.length > 20) {
        cleanVoice = firstSentence + "।";
      }
    }

    return {
      voiceSpokenText: cleanVoice || rawModelText,
      textDisplayText: rawModelText,
      suggestedEmotion: "Neutral",
    };
  }
}

export const responsePlanner = ResponsePlanner.getInstance();
