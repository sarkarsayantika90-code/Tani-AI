import { DetectedLanguage, LanguageCode } from "../types";

export interface LanguageDetectionResult {
  detected: DetectedLanguage;
  locked: DetectedLanguage;
  confidence: number;
  isExplicitSwitch: boolean;
  directivePrompt: string;
}

const BANGLISH_WORDS = new Set([
  "kholo", "koro", "dao", "ekta", "amar", "chilo", "baniye", "bolche", "achhe", "ache",
  "bhalo", "ki", "kemon", "aajke", "ajke", "shono", "dekho", "korbo", "hobe", "eta",
  "ota", "seta", "upore", "niche", "bondo", "chalu", "amake", "tomar", "karon", "kothay",
  "kobe", "keno", "korbe", "korte", "parbe", "please", "ta", "ti", "gulo", "khulbe",
  "bolo", "bolte", "bujhte", "shuncho", "kaj", "kajer", "mone", "rekho", "kor", "abar", "aro"
]);

const HINGLISH_WORDS = new Set([
  "kholo", "karo", "batao", "kaise", "kya", "mujhe", "mera", "hoga", "chahiye", "karoge",
  "kar", "bhejo", "dekh", "sun", "aaj", "kal", "kyu", "kaha", "kab", "karna", "baat", "bolo"
]);

export class LanguageEngine {
  private static instance: LanguageEngine | null = null;
  private lockedLanguage: DetectedLanguage = "bn"; // Default to warm Bengali assistant
  private turnHistory: { text: string; lang: DetectedLanguage; timestamp: number }[] = [];

  private constructor() {}

  public static getInstance(): LanguageEngine {
    if (!LanguageEngine.instance) {
      LanguageEngine.instance = new LanguageEngine();
    }
    return LanguageEngine.instance;
  }

  public getLockedLanguage(): DetectedLanguage {
    return this.lockedLanguage;
  }

  public setLockedLanguage(lang: DetectedLanguage): void {
    this.lockedLanguage = lang;
  }

  /**
   * Evaluates input text, historical turns, and explicit language switch requests
   */
  public analyzeLanguage(rawText: string, preferredDefault?: LanguageCode): LanguageDetectionResult {
    const text = rawText.trim();
    const lower = text.toLowerCase();

    // 1. Check for explicit language switches
    const explicitSwitch = this.checkExplicitLanguageSwitch(lower);
    if (explicitSwitch) {
      this.lockedLanguage = explicitSwitch;
      this.recordTurn(text, explicitSwitch);
      return {
        detected: explicitSwitch,
        locked: explicitSwitch,
        confidence: 0.99,
        isExplicitSwitch: true,
        directivePrompt: this.getDirectivePrompt(explicitSwitch),
      };
    }

    // 2. Check for short affirmative / negative / acknowledgement tokens
    // For very short phrases like "হ্যাঁ", "না", "ঠিক আছে", "yes", "okay", "haan",
    // inherit the previous conversational language unless context says otherwise!
    if (this.isShortAcknowledgement(lower)) {
      this.recordTurn(text, this.lockedLanguage);
      return {
        detected: this.lockedLanguage,
        locked: this.lockedLanguage,
        confidence: 0.9,
        isExplicitSwitch: false,
        directivePrompt: this.getDirectivePrompt(this.lockedLanguage),
      };
    }

    // 3. Script & Lexicon Analysis
    const hasBengaliScript = /[\u0980-\u09FF]/.test(text);
    const hasDevanagariScript = /[\u0900-\u097F]/.test(text);
    const hasLatin = /[a-zA-Z]/.test(text);

    // Count English vs Banglish vs Hinglish tokens in Latin script
    const words = lower.replace(/[^\w\s\u0980-\u09FF\u0900-\u097F]/g, " ").split(/\s+/).filter(Boolean);
    let banglishHits = 0;
    let hinglishHits = 0;
    let englishHits = 0;

    for (const w of words) {
      if (BANGLISH_WORDS.has(w)) banglishHits++;
      if (HINGLISH_WORDS.has(w)) hinglishHits++;
      // Common English words
      if (["the", "is", "a", "an", "open", "create", "can", "you", "my", "website", "weather", "today", "search", "scroll"].includes(w)) {
        englishHits++;
      }
    }

    let turnLang: DetectedLanguage = this.lockedLanguage;

    if (hasBengaliScript) {
      if (hasLatin && englishHits > 0) {
        turnLang = "bn-en";
      } else {
        turnLang = "bn";
      }
    } else if (hasDevanagariScript) {
      if (hasLatin && englishHits > 0) {
        turnLang = "hi-en";
      } else {
        turnLang = "hi";
      }
    } else if (banglishHits > 0 && banglishHits >= hinglishHits) {
      turnLang = englishHits > 0 ? "bn-en" : "bn";
    } else if (hinglishHits > 0) {
      turnLang = englishHits > 0 ? "hi-en" : "hi";
    } else if (hasLatin) {
      // Latin only with no Banglish/Hinglish triggers -> English
      turnLang = "en";
    }

    // 4. Update Language Lock
    // If the user clearly speaks Bengali (script or Banglish), lock to Bengali.
    // If the user switches cleanly to English ("Open YouTube", "Can you open Chrome?"), lock to English.
    if (turnLang === "bn" || turnLang === "bn-en") {
      this.lockedLanguage = "bn";
    } else if (turnLang === "hi" || turnLang === "hi-en") {
      this.lockedLanguage = "hi";
    } else if (turnLang === "en") {
      this.lockedLanguage = "en";
    }

    this.recordTurn(text, turnLang);

    return {
      detected: turnLang,
      locked: this.lockedLanguage,
      confidence: 0.92,
      isExplicitSwitch: false,
      directivePrompt: this.getDirectivePrompt(this.lockedLanguage),
    };
  }

  private checkExplicitLanguageSwitch(lower: string): DetectedLanguage | null {
    if (
      lower.includes("বাংলায় কথা বলো") ||
      lower.includes("বাংলায় কথা বলো") ||
      lower.includes("বাংলায় বলো") ||
      lower.includes("বাংলায় বলো") ||
      lower.includes("বাংলা বলো") ||
      lower.includes("banglay bolo") ||
      lower.includes("banglay kotha bolo") ||
      lower.includes("speak in bengali") ||
      lower.includes("talk in bengali")
    ) {
      return "bn";
    }

    if (
      lower.includes("english e bolo") ||
      lower.includes("englishe bolo") ||
      lower.includes("ইংলিশে বলো") ||
      lower.includes("ইংরেজিতে বলো") ||
      lower.includes("speak in english") ||
      lower.includes("talk in english") ||
      lower.includes("speak english")
    ) {
      return "en";
    }

    if (
      lower.includes("হিন্দিতে বলো") ||
      lower.includes("hindi me bolo") ||
      lower.includes("speak in hindi")
    ) {
      return "hi";
    }

    return null;
  }

  private isShortAcknowledgement(lower: string): boolean {
    const compact = lower.replace(/[^a-zA-Z\u0980-\u09FF\u0900-\u097F]/g, "").trim();
    const acknowledgements = [
      "হ্যাঁ", "হাঁ", "না", "ঠিকআছে", "ঠিক", "আচ্ছা",
      "yes", "yeah", "yep", "no", "nope", "okay", "ok", "sure", "fine", "hmm",
      "haan", "nahi", "accha", "theek", "thikache"
    ];
    return acknowledgements.includes(compact);
  }

  private recordTurn(text: string, lang: DetectedLanguage) {
    this.turnHistory.push({ text, lang, timestamp: Date.now() });
    if (this.turnHistory.length > 20) {
      this.turnHistory.shift();
    }
  }

  public getDirectivePrompt(lang: DetectedLanguage): string {
    switch (lang) {
      case "bn":
      case "bn-en":
        return `IMPORTANT LANGUAGE DIRECTIVE: The user is conversing in Bengali (or Bengali-English / Banglish). Respond warmly and naturally in Bengali script. If technical terms, app names, or coding are involved, keep the technical keywords in English while maintaining natural Bengali conversational phrasing. Do NOT randomly switch to English.`;
      case "hi":
      case "hi-en":
        return `IMPORTANT LANGUAGE DIRECTIVE: The user is conversing in Hindi (or Hinglish). Respond warmly and naturally in Hindi (or natural Hinglish). Do NOT randomly switch to pure English.`;
      case "en":
      default:
        return `IMPORTANT LANGUAGE DIRECTIVE: The user is conversing in English. Respond naturally, clearly, and concisely in English. Do NOT switch to Bengali unless requested.`;
    }
  }
}

export const languageEngine = LanguageEngine.getInstance();
