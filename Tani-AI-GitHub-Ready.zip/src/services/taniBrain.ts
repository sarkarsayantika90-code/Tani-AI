import {
  Message,
  PersonalityConfig,
  EmotionTone,
  LanguageCode,
  BackgroundTask,
  DetectedLanguage,
  StructuredAndroidAction,
  ActionVerification,
} from "../types";
import { actionPlanner, ActionPlanner } from "./actionPlanner";
import { AiService, ChatResponse } from "./aiService";
import { androidBridge, AndroidBridgeService } from "./androidBridge";
import { androidControlEngine, AndroidControlEngine } from "./androidControlEngine";
import {
  communicationEngine,
  CommunicationEngine,
  PendingCommunicationAction,
} from "./communicationEngine";
import { confirmationManager, ConfirmationManager } from "./confirmationManager";
import { entityResolver, EntityResolver } from "./entityResolver";
import { languageEngine, LanguageEngine } from "./languageEngine";
import { liveSessionManager, LiveSessionManager } from "./liveSessionManager";
import { reasoningEngine, ReasoningEngine } from "./reasoningEngine";
import { responsePlanner, ResponsePlanner } from "./responsePlanner";
import { SpeechNormalizer, NormalizedActionIntent } from "./speechNormalizer";
import { StorageService } from "./storageService";
import { taskManager, TaskManager } from "./taskManager";
import { toolRouter, ToolRouterV2 } from "./toolRouter";
import { unifiedContextManager, UnifiedContextManager } from "./unifiedContextManager";
import { voiceManager } from "./voiceService";

export type IntentType =
  | "conversation"
  | "question"
  | "command"
  | "follow_up"
  | "coding"
  | "website_creation"
  | "weather"
  | "timer"
  | "reminder"
  | "app_open"
  | "app_close"
  | "call"
  | "email"
  | "message"
  | "notes"
  | "image_analysis"
  | "scroll"
  | "navigation"
  | "repeat"
  | "stop";

export interface IntentResult {
  type: IntentType;
  confidence: number;
  parameters: Record<string, any>;
  isSensitive: boolean;
  language: "bn-IN" | "hi-IN" | "en-US" | "auto";
  detectedLanguage: DetectedLanguage;
  normalizedAction?: NormalizedActionIntent;
  structuredAction?: StructuredAndroidAction;
}

// 1. LanguageEngine export
export { LanguageEngine, languageEngine };

// 2. EntityResolver export
export { EntityResolver, entityResolver };

// 3. AndroidBridge export
export { AndroidBridgeService, androidBridge };

// 4. AndroidControlEngine export
export { AndroidControlEngine, androidControlEngine };

// 5. CommunicationEngine export
export { CommunicationEngine, communicationEngine };

// 6. ActionPlanner export
export { ActionPlanner, actionPlanner };

// 7. ConfirmationManager export
export { ConfirmationManager, confirmationManager };

// 8. ReasoningEngine export
export { ReasoningEngine, reasoningEngine };

// 9. ResponsePlanner export
export { ResponsePlanner, responsePlanner };

// 10. ToolRouter export
export { ToolRouterV2, toolRouter };

// 11. TaskManager export
export { TaskManager, taskManager };

// 12. EmotionEngine
export class EmotionEngine {
  public static evaluateTone(text: string, currentEmotion: EmotionTone): EmotionTone {
    const lower = text.toLowerCase();
    if (
      lower.includes("thank") ||
      lower.includes("awesome") ||
      lower.includes("great") ||
      lower.includes("ধন্যবাদ") ||
      lower.includes("দারুণ") ||
      lower.includes("ভালো") ||
      lower.includes("khub bhalo")
    ) {
      return "Happy";
    }
    if (
      lower.includes("congrat") ||
      lower.includes("celebrat") ||
      lower.includes("we did it") ||
      lower.includes("উৎসব")
    ) {
      return "Celebrating";
    }
    if (
      lower.includes("problem") ||
      lower.includes("error") ||
      lower.includes("urgent") ||
      lower.includes("danger") ||
      lower.includes("বিপদ") ||
      lower.includes("stuck")
    ) {
      return "Concerned";
    }
    if (
      lower.includes("joke") ||
      lower.includes("funny") ||
      lower.includes("haha") ||
      lower.includes("মজা")
    ) {
      return "Playful";
    }
    return currentEmotion || "Neutral";
  }
}

// 13. MemoryManager
export class MemoryManager {
  public static getContextNotes(): string[] {
    return StorageService.getMemoryNotes();
  }

  public static addFact(fact: string): void {
    const existing = StorageService.getMemoryNotes();
    if (!existing.includes(fact)) {
      StorageService.saveMemoryNotes([...existing, fact]);
    }
  }

  public static buildSystemPromptContext(userName: string): string {
    const notes = this.getContextNotes();
    return `User Name: ${userName || "User"}\nSaved Long-Term Memories:\n${notes
      .map((n) => `- ${n}`)
      .join("\n")}`;
  }
}

// 14. ContextEngine (ContextManager unifying memory and active turn context)
export class ContextEngine {
  private unified = unifiedContextManager;

  public updateHistory(messages: Message[]): void {
    for (const msg of messages.slice(-5)) {
      this.unified.recordTurn({
        modality: "text",
        role: msg.role === "tani" ? "tani" : "user",
        content: msg.content,
        language: languageEngine.getLockedLanguage(),
      });
    }
  }

  public getRecentContext(): Message[] {
    return this.unified.getState().recentTurns.map((t) => ({
      id: t.id,
      role: t.role,
      content: t.content,
      timestamp: t.timestamp,
    }));
  }

  public getUnifiedState() {
    return this.unified.getState();
  }

  public getActiveApp(): string | null {
    return this.unified.getActiveApp();
  }
}

export const contextEngine = new ContextEngine();
export { ContextEngine as ContextManager };

// 15. IntentEngine
export class IntentEngine {
  public static analyze(text: string, hasImage?: boolean): IntentResult {
    const raw = text.trim();
    const langAnalysis = languageEngine.analyzeLanguage(raw);
    const normalized = SpeechNormalizer.normalize(raw);
    const plannedAction = actionPlanner.plan(raw, langAnalysis.detected as "bn" | "en" | "hi");

    let mappedLang: "bn-IN" | "hi-IN" | "en-US" | "auto" = "en-US";
    if (langAnalysis.detected === "bn" || langAnalysis.detected === "bn-en") {
      mappedLang = "bn-IN";
    } else if (langAnalysis.detected === "hi" || langAnalysis.detected === "hi-en") {
      mappedLang = "hi-IN";
    }

    if (hasImage) {
      return {
        type: "image_analysis",
        confidence: 0.95,
        parameters: { prompt: text },
        isSensitive: false,
        language: mappedLang,
        detectedLanguage: langAnalysis.detected,
        normalizedAction: "UNKNOWN",
      };
    }

    // Check if structured action was planned
    if (plannedAction) {
      let type: IntentType = "command";
      if (plannedAction.action === "OPEN_APP") type = "app_open";
      else if (plannedAction.action === "CLOSE_APP") type = "app_close";
      else if (plannedAction.action === "SCROLL") type = "scroll";
      else if (
        plannedAction.action === "NAVIGATE_HOME" ||
        plannedAction.action === "NAVIGATE_BACK" ||
        plannedAction.action === "RECENT_APPS"
      ) {
        type = "navigation";
      }

      return {
        type,
        confidence: 0.98,
        parameters: plannedAction.params || { target: plannedAction.target },
        isSensitive: plannedAction.riskLevel === "HIGH",
        language: mappedLang,
        detectedLanguage: langAnalysis.detected,
        structuredAction: plannedAction,
      };
    }

    // Website Creation
    if (normalized.normalizedAction === "CREATE_BUILD") {
      return {
        type: "website_creation",
        confidence: 0.95,
        parameters: { topic: text },
        isSensitive: false,
        language: mappedLang,
        detectedLanguage: langAnalysis.detected,
        normalizedAction: "CREATE_BUILD",
      };
    }

    // Coding
    const lower = raw.toLowerCase();
    if (
      lower.includes("code") ||
      lower.includes("function") ||
      lower.includes("algorithm") ||
      lower.includes("typescript") ||
      lower.includes("javascript") ||
      lower.includes("python") ||
      lower.includes("কোড")
    ) {
      return {
        type: "coding",
        confidence: 0.9,
        parameters: { task: text },
        isSensitive: false,
        language: mappedLang,
        detectedLanguage: langAnalysis.detected,
      };
    }

    // Weather
    if (
      lower.includes("weather") ||
      lower.includes("temperature") ||
      lower.includes("আবহাওয়া") ||
      lower.includes("मौसम")
    ) {
      return {
        type: "weather",
        confidence: 0.95,
        parameters: { location: "Current Location" },
        isSensitive: false,
        language: mappedLang,
        detectedLanguage: langAnalysis.detected,
      };
    }

    // Timer
    if (lower.includes("timer") || lower.includes("টাইমার")) {
      const minMatch = raw.match(/(\d+)\s*(?:minutes?|min|মিনিট)/i);
      const secMatch = raw.match(/(\d+)\s*(?:seconds?|sec|সেকেন্ড)/i);
      let seconds = 60;
      if (minMatch) seconds = parseInt(minMatch[1], 10) * 60;
      else if (secMatch) seconds = parseInt(secMatch[1], 10);
      return {
        type: "timer",
        confidence: 0.95,
        parameters: { durationSeconds: seconds },
        isSensitive: false,
        language: mappedLang,
        detectedLanguage: langAnalysis.detected,
      };
    }

    // Reminder
    if (lower.includes("remind") || lower.includes("মনে করিয়ে দিও") || lower.includes("রিমাইন্ডার")) {
      return {
        type: "reminder",
        confidence: 0.9,
        parameters: { text },
        isSensitive: false,
        language: mappedLang,
        detectedLanguage: langAnalysis.detected,
      };
    }

    return {
      type: raw.endsWith("?") ? "question" : "conversation",
      confidence: 0.85,
      parameters: { prompt: text },
      isSensitive: false,
      language: mappedLang,
      detectedLanguage: langAnalysis.detected,
    };
  }
}

// 16. ConversationManager
export class ConversationManager {
  private activeConversationId: string | null = null;

  public setActiveId(id: string): void {
    this.activeConversationId = id;
  }

  public getActiveId(): string | null {
    return this.activeConversationId;
  }
}

// 17. WakeWordEngine
export class WakeWordEngine {
  private isListeningForWakeWord: boolean = false;

  public start(onDetected: () => void): void {
    this.isListeningForWakeWord = true;
  }

  public stop(): void {
    this.isListeningForWakeWord = false;
  }

  public checkTranscript(transcript: string): boolean {
    const lower = transcript.toLowerCase();
    return lower.includes("tani") || lower.includes("hey tani") || lower.includes("তানি");
  }
}

// 18. InterruptionManager
export class InterruptionManager {
  public static interrupt(): void {
    voiceManager.interrupt();
    liveSessionManager.interrupt();
  }
}

// 19. VoiceController
export class VoiceController {
  public static setContinuous(enabled: boolean): void {
    voiceManager.setContinuousMode(enabled);
    liveSessionManager.setConfig({ continuousMode: enabled });
  }

  public static isListening(): boolean {
    return voiceManager.getIsListening() || liveSessionManager.isListening();
  }

  public static isSpeaking(): boolean {
    return voiceManager.getIsSpeaking() || liveSessionManager.isSpeaking();
  }
}

// Unified System: TaniBrain Master Orchestrator
export class TaniBrainService {
  public intentEngine = IntentEngine;
  public contextEngine = contextEngine;
  public contextManager = contextEngine;
  public actionPlanner = actionPlanner;
  public toolRouter = toolRouter;
  public toolExecutionEngine = toolRouter;
  public androidControlEngine = androidControlEngine;
  public communicationEngine = communicationEngine;
  public emotionEngine = EmotionEngine;
  public memoryManager = MemoryManager;
  public taskManager = TaskManager;
  public conversationManager = new ConversationManager();
  public wakeWordEngine = new WakeWordEngine();
  public voiceEngine = liveSessionManager;
  public languageEngine = languageEngine;
  public entityResolver = entityResolver;
  public reasoningEngine = reasoningEngine;
  public responsePlanner = responsePlanner;
  public confirmationManager = confirmationManager;
  public interruptionManager = InterruptionManager;
  public voiceController = VoiceController;

  public async processUserInput(params: {
    prompt: string;
    userName: string;
    personality: PersonalityConfig;
    image?: { data: string; mimeType: string };
    apiKey?: string;
  }): Promise<
    ChatResponse & {
      intent: IntentResult;
      spokenText?: string;
      verified?: boolean;
      structuredAction?: StructuredAndroidAction;
      confirmationAction?: {
        type: "MESSAGE" | "CALL" | "DELETE" | "ACTION";
        payload?: any;
        question: string;
        confirmLabel: string;
        cancelLabel: string;
        status: "pending" | "confirmed" | "cancelled";
      };
    }
  > {
    const rawPrompt = params.prompt.trim();

    // 1. Language Detection & Lock
    const langAnalysis = languageEngine.analyzeLanguage(rawPrompt, params.personality.language);
    const lockedLang = langAnalysis.locked;

    // 2. Pronoun & Entity Resolution
    const resolvedTurn = entityResolver.resolve(rawPrompt);
    const resolvedPrompt = resolvedTurn.resolvedText;

    // 3. Check for Pending Communication Confirmation Response (e.g. user answered "SEND", "হ্যাঁ", "পাঠাও", "CANCEL", "না")
    const pendingComm = communicationEngine.getPendingAction();
    if (pendingComm) {
      const lower = rawPrompt.toLowerCase();
      const isAffirmative =
        lower.includes("send") ||
        lower.includes("হ্যাঁ") ||
        lower.includes("পাঠাও") ||
        lower.includes("করো") ||
        lower.includes("yes") ||
        lower.includes("haan") ||
        lower.includes("ha") ||
        lower.includes("delete koro") ||
        lower.includes("call koro") ||
        lower === "ok";

      const isNegative =
        lower.includes("cancel") ||
        lower.includes("না") ||
        lower.includes("করো না") ||
        lower.includes("পাঠাবে না") ||
        lower.includes("no") ||
        lower.includes("stop");

      if (isAffirmative) {
        const execResult = await communicationEngine.executePending();
        const successMsg =
          lockedLang === "bn"
            ? pendingComm.type === "MESSAGE"
              ? `${pendingComm.contactName}-কে বার্তা পাঠানো হয়েছে।`
              : pendingComm.type === "CALL"
              ? `${pendingComm.contactName}-কে কল করা হচ্ছে...`
              : `মুছে ফেলা সম্পন্ন হয়েছে।`
            : execResult.message;

        return {
          text: successMsg,
          spokenText: successMsg,
          codeBlocks: [],
          intent: {
            type: pendingComm.type === "MESSAGE" ? "message" : pendingComm.type === "CALL" ? "call" : "command",
            confidence: 1.0,
            parameters: { contact: pendingComm.contactName },
            isSensitive: true,
            language: lockedLang === "bn" ? "bn-IN" : "en-US",
            detectedLanguage: lockedLang,
          },
          verified: execResult.verified,
        };
      } else if (isNegative) {
        communicationEngine.clearPending();
        const cancelMsg = lockedLang === "bn" ? "কার্যক্রম বাতিল করা হলো।" : "Action cancelled.";
        return {
          text: cancelMsg,
          spokenText: cancelMsg,
          codeBlocks: [],
          intent: {
            type: "command",
            confidence: 1.0,
            parameters: {},
            isSensitive: false,
            language: lockedLang === "bn" ? "bn-IN" : "en-US",
            detectedLanguage: lockedLang,
          },
          verified: true,
        };
      }
    }

    // 4. MESSAGE BRAIN, CALL BRAIN, DELETE BRAIN via CommunicationEngine
    const commAnalysis = communicationEngine.analyzeCommunicationIntent(
      resolvedPrompt,
      lockedLang as "bn" | "en" | "hi"
    );

    if (commAnalysis.matched) {
      if (commAnalysis.clarificationPrompt) {
        return {
          text: commAnalysis.clarificationPrompt,
          spokenText: commAnalysis.clarificationPrompt,
          codeBlocks: [],
          intent: {
            type: "message",
            confidence: 0.95,
            parameters: commAnalysis.actionPayload || {},
            isSensitive: true,
            language: lockedLang === "bn" ? "bn-IN" : "en-US",
            detectedLanguage: lockedLang,
          },
          verified: false,
        };
      }

      if (commAnalysis.needsConfirmation && commAnalysis.confirmationQuestion) {
        const confirmLabel =
          commAnalysis.type === "MESSAGE"
            ? "SEND"
            : commAnalysis.type === "CALL"
            ? "CALL"
            : "DELETE";

        return {
          text: commAnalysis.confirmationQuestion,
          spokenText: commAnalysis.confirmationQuestion,
          codeBlocks: [],
          intent: {
            type: commAnalysis.type === "MESSAGE" ? "message" : commAnalysis.type === "CALL" ? "call" : "command",
            confidence: 0.98,
            parameters: commAnalysis.actionPayload || {},
            isSensitive: true,
            language: lockedLang === "bn" ? "bn-IN" : "en-US",
            detectedLanguage: lockedLang,
          },
          confirmationAction: {
            type: commAnalysis.type!,
            payload: commAnalysis.actionPayload,
            question: commAnalysis.confirmationQuestion,
            confirmLabel,
            cancelLabel: "CANCEL",
            status: "pending",
          },
          verified: false,
        };
      }
    }

    // 5. APP CONTROL & STRUCTURED ACTION via ActionPlanner & AndroidControlEngine
    const plannedAction = actionPlanner.plan(resolvedPrompt, lockedLang as "bn" | "en" | "hi");
    if (plannedAction) {
      // Execute structured action through AndroidControlEngine with verification
      const actionResult = await androidControlEngine.executeStructuredAction(
        plannedAction,
        lockedLang as "bn" | "en" | "hi"
      );

      const plannedResponse = responsePlanner.plan({
        rawModelText: actionResult.message,
        actionResult: actionResult.message,
        lang: lockedLang,
        isToolExecution: true,
      });

      unifiedContextManager.recordTurn({
        modality: "text",
        role: "user",
        content: rawPrompt,
        language: lockedLang,
        intent: plannedAction.action,
      });

      unifiedContextManager.recordTurn({
        modality: "text",
        role: "tani",
        content: plannedResponse.textDisplayText,
        language: lockedLang,
        intent: plannedAction.action,
      });

      return {
        text: plannedResponse.textDisplayText,
        spokenText: plannedResponse.voiceSpokenText,
        codeBlocks: [],
        detectedTool: {
          name: plannedAction.action,
          arguments: (plannedAction as any).params || { target: plannedAction.target },
        },
        intent: {
          type: plannedAction.action === "OPEN_APP" ? "app_open" : "command",
          confidence: 0.98,
          parameters: { target: plannedAction.target },
          isSensitive: plannedAction.riskLevel === "HIGH",
          language: lockedLang === "bn" ? "bn-IN" : "en-US",
          detectedLanguage: lockedLang,
          structuredAction: plannedAction,
        },
        structuredAction: plannedAction,
        verified: actionResult.verified,
      };
    }

    // 6. Multi-Step Chained Tasks (e.g. "Tani Chrome খুলে Google search করো" or "Open YouTube and search for Bengali songs")
    const chainedPlan = taskManager.planChainedTask(resolvedPrompt);
    if (chainedPlan) {
      const taskResult = await taskManager.executePlan(
        chainedPlan,
        lockedLang as "bn" | "en" | "hi"
      );
      const planned = responsePlanner.plan({
        rawModelText: taskResult.finalMessage,
        actionResult: taskResult.finalMessage,
        lang: lockedLang,
        isToolExecution: true,
      });

      return {
        text: planned.textDisplayText,
        spokenText: planned.voiceSpokenText,
        codeBlocks: [],
        intent: {
          type: "command",
          confidence: 0.95,
          parameters: { steps: chainedPlan.length },
          isSensitive: false,
          language: lockedLang === "bn" ? "bn-IN" : "en-US",
          detectedLanguage: lockedLang,
        },
        verified: taskResult.allSucceeded,
      };
    }

    // 7. Standard Intent Detection
    const intent = this.intentEngine.analyze(resolvedPrompt, !!params.image);

    // Save memory if notes intent
    if (intent.type === "notes") {
      this.memoryManager.addFact(rawPrompt);
    }

    // 8. General AI Conversation with Language Directive & Context
    const followUp = unifiedContextManager.resolveFollowUpWithContext(resolvedPrompt);
    const contextSummary = unifiedContextManager.buildContextSummary();
    const directivePrompt = languageEngine.getDirectivePrompt(lockedLang);

    const augmentedPrompt = `${directivePrompt}\n\n${
      contextSummary ? `[CONTEXT]:\n${contextSummary}\n\n` : ""
    }${followUp.augmentedPrompt}`;

    const response = await AiService.sendMessage({
      prompt: augmentedPrompt,
      history: this.contextEngine.getRecentContext(),
      personality: params.personality.mode,
      language: params.personality.language,
      image: params.image,
      apiKey: params.apiKey,
      userName: params.userName,
    });

    const planned = responsePlanner.plan({
      rawModelText: response.text,
      lang: lockedLang,
      hasCodeBlocks: response.codeBlocks && response.codeBlocks.length > 0,
      isWebsiteCreation: response.isWebsiteGeneration,
    });

    if (response.isWebsiteGeneration && response.websiteHtml) {
      this.taskManager.createBackgroundTask("Website Generation", {
        language: "html",
        code: response.websiteHtml,
        htmlPreview: response.websiteHtml,
      });
      unifiedContextManager.setLastAction("Created Website", { previewReady: true });
    }

    unifiedContextManager.recordTurn({
      modality: "text",
      role: "user",
      content: rawPrompt,
      language: lockedLang,
    });

    unifiedContextManager.recordTurn({
      modality: "text",
      role: "tani",
      content: planned.textDisplayText,
      language: lockedLang,
    });

    return {
      ...response,
      text: planned.textDisplayText,
      spokenText: planned.voiceSpokenText,
      intent,
      verified: true,
    };
  }
}

export const TaniBrain = new TaniBrainService();
