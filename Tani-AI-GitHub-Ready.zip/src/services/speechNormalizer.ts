export type NormalizedActionIntent =
  | "OPEN"
  | "CLOSE"
  | "SCROLL_DOWN"
  | "SCROLL_UP"
  | "REPEAT_MORE"
  | "REPEAT_ACTION"
  | "SEARCH"
  | "CALL"
  | "MESSAGE"
  | "CREATE_BUILD"
  | "STOP"
  | "NAVIGATE_HOME"
  | "NAVIGATE_BACK"
  | "UNKNOWN";

export interface NormalizedSpeechResult {
  originalText: string;
  normalizedAction: NormalizedActionIntent;
  targetEntity?: string;
  cleanedText: string;
}

export class SpeechNormalizer {
  /**
   * Normalizes Hinglish, Banglish, Bengali script, and informal variations
   * into semantic action intents while preserving names, queries, and target entities.
   */
  public static normalize(text: string): NormalizedSpeechResult {
    const raw = text.trim();
    const lower = raw.toLowerCase();

    // 1. SCROLL DOWN variations: "scroll kor", "scroll koro", "নিচে scroll করো", "niche jao", "আরও নিচে যাও"
    if (
      /(?:scroll\s+(?:down|kor|koro|karo|niche)|(?:niche|neche)\s+(?:jao|scroll\s+koro|scroll\s+kor)|নিচে\s+(?:যাও|নামো|স্ক্রোল\s+করো|scroll\s+করো)|আর\s+একটু\s+নিচে\s+যাও)/i.test(
        lower
      )
    ) {
      return {
        originalText: raw,
        normalizedAction: "SCROLL_DOWN",
        cleanedText: "Scroll down",
      };
    }

    // 2. SCROLL UP variations: "upore jao", "upore scroll koro", "উপরে যাও", "উপরে scroll করো"
    if (
      /(?:scroll\s+(?:up|upore)|(?:upore|upar)\s+(?:jao|scroll\s+koro|scroll\s+kor)|উপরে\s+(?:যাও|ওঠো|স্ক্রোল\s+করো|scroll\s+করো))/i.test(
        lower
      )
    ) {
      return {
        originalText: raw,
        normalizedAction: "SCROLL_UP",
        cleanedText: "Scroll up",
      };
    }

    // 3. REPEAT / MORE variations: "aro", "aaro", "আরও", "aur"
    if (/^(?:aro|aaro|aaroo|আরও|aur)\s*$/i.test(lower)) {
      return {
        originalText: raw,
        normalizedAction: "REPEAT_MORE",
        cleanedText: "Continue action / Scroll more",
      };
    }

    // 4. REPEAT ACTION variations: "abar koro", "আবার করো", "repeat koro", "do it again", "ওটা আবার করো"
    if (
      /(?:abar\s+koro|আবার\s+করো|repeat\s+koro|do\s+it\s+again|phir\s+se\s+karo|ওটা\s+আবার\s+করো|ota\s+abar\s+koro)/i.test(
        lower
      )
    ) {
      return {
        originalText: raw,
        normalizedAction: "REPEAT_ACTION",
        cleanedText: "Repeat previous action",
      };
    }

    // 5. STOP variations: "stop", "thamo", "থামো", "ruk ja", "ruk jao", "cancel"
    if (/^(?:stop|thamo|থামো|ruk\s*ja|ruk\s*jao|বন্ধ\s+হও|দাঁড়াও|wait)\b/i.test(lower)) {
      return {
        originalText: raw,
        normalizedAction: "STOP",
        cleanedText: "Stop immediately",
      };
    }

    // 6. OPEN variations: "kholo", "open koro", "open kore dao", "খুলে দাও", "চালু করো", "open"
    // Examples: "Tani YouTube kholo", "আজকে YouTube খুলে দাও", "Can you open settings ta?"
    const openMatch = raw.match(
      /(?:open\s+koro|open\s+kore\s+dao|খুলে\s+দাও|খোলো|খুলো|kholo|chalu\s+koro|চালু\s+করো|open|launch)\s+([A-Za-z0-9\u0980-\u09FF\s]+)/i
    ) || raw.match(/([A-Za-z0-9\u0980-\u09FF]+)\s+(?:ta\s+)?(?:kholo|open\s+koro|open\s+kore\s+dao|খুলে\s+দাও|খোলো|খুলো|chalu\s+koro|চালু\s+করো)/i);

    if (openMatch && !lower.includes("search") && !lower.includes("website") && !lower.includes("বানাও")) {
      const target = openMatch[1]
        .replace(/^(?:tani|please|today|ajke|aajke|can\s+you)\s+/i, "")
        .replace(/\s+(?:ta|ti|please|dao|koro)$/i, "")
        .trim();

      return {
        originalText: raw,
        normalizedAction: "OPEN",
        targetEntity: target,
        cleanedText: `Open ${target}`,
      };
    }

    // 7. CREATE / BUILD variations: "ekta website baniye dao", "website banate hobe", "website বানিয়ে দাও"
    if (
      /(?:baniye\s+dao|banate\s+hobe|banaw|বানিয়ে\s+দাও|বানিয়ে\s+দাও|বানাও|make|build|create)\s+.*(?:website|site|ওয়েবসাইট|webpage)/i.test(
        lower
      ) ||
      /(?:website|site|ওয়েবসাইট|webpage)\s+.*(?:baniye\s+dao|banate\s+hobe|banaw|বানিয়ে\s+দাও|বানিয়ে\s+দাও|বানাও)/i.test(
        lower
      )
    ) {
      return {
        originalText: raw,
        normalizedAction: "CREATE_BUILD",
        targetEntity: "website",
        cleanedText: "Create a website",
      };
    }

    // 8. SEARCH variations: "search koro", "khoj koro", "সার্চ করো", "খুঁজে দাও"
    // Examples: "একটা search করো", "search for Bengali songs"
    if (/(?:search\s+koro|সার্চ\s+করো|search\s+for|search|খুঁজে\s+দাও|khojo)/i.test(lower)) {
      const queryMatch = raw.match(/(?:search\s+(?:for|koro|kor)?|সার্চ\s+করো|খুঁজে\s+দাও)\s+(.+)/i);
      const query = queryMatch ? queryMatch[1].trim() : undefined;
      return {
        originalText: raw,
        normalizedAction: "SEARCH",
        targetEntity: query,
        cleanedText: query ? `Search for ${query}` : "Perform search",
      };
    }

    // 9. CALL variations: "call koro", "phone koro", "ফোন করো", "কল করো"
    // Examples: "Rahul ke call koro", "ওকে call করো"
    if (/(?:call\s+koro|ফোন\s+করো|কল\s+করো|call|phone)\s+([A-Za-z0-9\u0980-\u09FF]+)/i.test(raw)) {
      const match = raw.match(/(?:call\s+koro|ফোন\s+করো|কল\s+করো|call|phone)\s+([A-Za-z0-9\u0980-\u09FF]+)/i);
      return {
        originalText: raw,
        normalizedAction: "CALL",
        targetEntity: match ? match[1] : undefined,
        cleanedText: `Call ${match ? match[1] : "contact"}`,
      };
    }

    return {
      originalText: raw,
      normalizedAction: "UNKNOWN",
      cleanedText: raw,
    };
  }
}
