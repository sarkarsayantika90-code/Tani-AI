import { LanguageCode } from "../types";
import { voiceEngine, VoiceState, VoiceEngineCallbacks } from "./voiceEngine";

export interface VoiceServiceCallbacks {
  onListeningStart?: () => void;
  onListeningEnd?: () => void;
  onSpeechResult?: (transcript: string) => void;
  onModelTranscript?: (transcript: string) => void;
  onError?: (error: string) => void;
  onSpeakingStart?: () => void;
  onSpeakingEnd?: () => void;
  onAudioLevel?: (level: number) => void;
  onPermissionDenied?: () => void;
}

export class VoiceService {
  private currentLanguage: LanguageCode = "auto";
  private callbacks: VoiceServiceCallbacks = {};

  constructor() {
    this.setupEngine();
  }

  private setupEngine() {
    voiceEngine.setCallbacks({
      onStateChange: (state: VoiceState) => {
        if (state === "LISTENING") {
          this.callbacks.onListeningStart?.();
        } else if (state === "SPEAKING") {
          this.callbacks.onSpeakingStart?.();
        } else if (state === "IDLE") {
          this.callbacks.onListeningEnd?.();
          this.callbacks.onSpeakingEnd?.();
        } else if (state === "ERROR") {
          this.callbacks.onListeningEnd?.();
          this.callbacks.onSpeakingEnd?.();
        }
      },
      onUserTranscript: (text: string) => {
        this.callbacks.onSpeechResult?.(text);
      },
      onModelTranscript: (text: string) => {
        this.callbacks.onModelTranscript?.(text);
      },
      onAudioLevel: (level: number) => {
        this.callbacks.onAudioLevel?.(level);
      },
      onError: (err: string) => {
        this.callbacks.onError?.(err);
      },
      onPermissionDenied: () => {
        this.callbacks.onPermissionDenied?.();
      },
      onTurnComplete: () => {
        this.callbacks.onSpeakingEnd?.();
      },
    });
  }

  public setCallbacks(callbacks: VoiceServiceCallbacks) {
    this.callbacks = callbacks;
    this.setupEngine();
  }

  public setLanguage(lang: LanguageCode) {
    this.currentLanguage = lang;
    voiceEngine.setConfig({ language: lang });
  }

  public async startListening(
    langOverride?: LanguageCode,
    customKey?: string,
    userName?: string,
    continuousMode?: boolean
  ) {
    const lang = langOverride || this.currentLanguage;
    await voiceEngine.startVoiceSession({
      language: lang,
      apiKey: customKey,
      userName: userName || "User",
      continuousMode: continuousMode ?? false,
    });
  }

  public stopListening() {
    voiceEngine.stopVoiceSession();
  }

  public stopSpeaking() {
    voiceEngine.interrupt();
  }

  public interrupt() {
    voiceEngine.interrupt();
  }

  public getIsListening(): boolean {
    return voiceEngine.getState() === "LISTENING";
  }

  public getIsSpeaking(): boolean {
    return voiceEngine.getState() === "SPEAKING";
  }

  public getState(): VoiceState {
    return voiceEngine.getState();
  }

  public isLiveActive(): boolean {
    return voiceEngine.getState() !== "IDLE" && voiceEngine.getState() !== "ERROR";
  }

  public setContinuousMode(enabled: boolean) {
    voiceEngine.setConfig({ continuousMode: enabled });
  }

  public reconnect() {
    return voiceEngine.reconnect();
  }

  public speak(text: string, _rate: number = 1.0, onComplete?: () => void) {
    // For quick offline audio cues (e.g. "Timer finished")
    if (typeof window !== "undefined" && window.speechSynthesis) {
      try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = _rate;
        utterance.onend = () => onComplete?.();
        utterance.onerror = () => onComplete?.();
        window.speechSynthesis.speak(utterance);
      } catch {
        onComplete?.();
      }
    } else {
      onComplete?.();
    }
  }
}

export const voiceManager = new VoiceService();
