import {
  CommunicationMessagePayload,
  CallPayload,
  DeletePayload,
  ActionVerification,
  ActionRiskLevel,
} from "../types";
import { androidBridge } from "./androidBridge";
import { entityResolver } from "./entityResolver";
import { unifiedContextManager } from "./unifiedContextManager";

export interface PendingCommunicationAction {
  id: string;
  type: "MESSAGE" | "CALL" | "DELETE";
  riskLevel: ActionRiskLevel;
  contactName?: string;
  platform?: "WhatsApp" | "SMS" | "Telegram" | "Default";
  messageText?: string;
  targetItem?: string;
  question: string;
  createdAt: number;
}

export class CommunicationEngine {
  private static instance: CommunicationEngine | null = null;
  private pendingAction: PendingCommunicationAction | null = null;

  // Stored active draft contact/platform for multi-turn flow (e.g. Turn 1: "Rahul ke message koro", Turn 2: "Bolo ami kal asbo")
  private activeDraft: {
    contactName?: string;
    platform?: "WhatsApp" | "SMS" | "Telegram" | "Default";
    timestamp: number;
  } | null = null;

  private constructor() {}

  public static getInstance(): CommunicationEngine {
    if (!CommunicationEngine.instance) {
      CommunicationEngine.instance = new CommunicationEngine();
    }
    return CommunicationEngine.instance;
  }

  public getPendingAction(): PendingCommunicationAction | null {
    return this.pendingAction;
  }

  public clearPending(): void {
    this.pendingAction = null;
  }

  /**
   * Analyzes a user query for communication intent:
   * (Message, Call, or Delete)
   */
  public analyzeCommunicationIntent(userText: string, lang: "bn" | "en" | "hi" = "bn"): {
    matched: boolean;
    type?: "MESSAGE" | "CALL" | "DELETE";
    needsConfirmation?: boolean;
    confirmationQuestion?: string;
    actionPayload?: any;
    clarificationPrompt?: string;
  } {
    const raw = userText.trim();
    const lower = raw.toLowerCase();

    // 1. DELETE BRAIN ("Tani ei photo delete koro", "Delete this photo", "ছবিটা মুছে দাও")
    if (
      lower.includes("delete") ||
      lower.includes("মুছে দাও") ||
      lower.includes("ডিলিট") ||
      lower.includes("remove photo")
    ) {
      let target = "this photo";
      if (lower.includes("photo") || lower.includes("ছবি") || lower.includes("ছবিটা")) {
        target = "photo";
      } else if (lower.includes("message") || lower.includes("মেসেজ")) {
        target = "message";
      } else if (lower.includes("file") || lower.includes("ফাইল")) {
        target = "file";
      }

      const question =
        lang === "bn"
          ? `এই ${target} delete করব? এটি আর পুনরুদ্ধার করা যাবে না।`
          : `Delete this ${target}? This cannot be undone.`;

      this.pendingAction = {
        id: `act_${Date.now()}`,
        type: "DELETE",
        riskLevel: "HIGH",
        targetItem: target,
        question,
        createdAt: Date.now(),
      };

      return {
        matched: true,
        type: "DELETE",
        needsConfirmation: true,
        confirmationQuestion: question,
        actionPayload: { targetItem: target },
      };
    }

    // 2. CALL BRAIN ("Tani Rahul-ke call koro", "Call Rahul", "রাহুলকে কল করো", "ওকে call করো")
    const isCall =
      lower.includes("call ") ||
      lower.includes("phone ") ||
      lower.includes("কল করো") ||
      lower.includes("ফোন করো") ||
      lower.includes("call koro");

    if (isCall) {
      let contact = this.extractContactName(raw);

      // Pronoun resolution: "ওকে call করো" -> check recent entity memory
      if (!contact || contact.toLowerCase() === "oke" || contact === "ওকে" || contact === "him" || contact === "her") {
        contact = entityResolver.resolvePronoun("ওকে") || "Contact";
      }

      const question =
        lang === "bn"
          ? `${contact}-কে call করব?`
          : `Call ${contact}?`;

      this.pendingAction = {
        id: `act_${Date.now()}`,
        type: "CALL",
        riskLevel: "HIGH",
        contactName: contact,
        question,
        createdAt: Date.now(),
      };

      return {
        matched: true,
        type: "CALL",
        needsConfirmation: true,
        confirmationQuestion: question,
        actionPayload: { contactName: contact },
      };
    }

    // 3. MESSAGE BRAIN ("Rahul ke message pathao", "Rahul-ke bolo ami 10 minute pore aschi", "WhatsApp e Rahul-ke message koro", "ওকে WhatsApp করো", "ওকে বলো আমি পরে আসছি")
    const isMessage =
      lower.includes("message") ||
      lower.includes("whatsapp") ||
      lower.includes("মেসেজ") ||
      lower.includes("sms") ||
      lower.includes("bolo") ||
      lower.includes("বলো");

    if (isMessage) {
      // Platform detection
      let platform: "WhatsApp" | "SMS" | "Telegram" | "Default" = "Default";
      if (lower.includes("whatsapp") || lower.includes("হোয়াটসঅ্যাপ")) {
        platform = "WhatsApp";
      } else if (lower.includes("sms")) {
        platform = "SMS";
      } else if (lower.includes("telegram")) {
        platform = "Telegram";
      }

      // Contact identification
      let contact = this.extractContactName(raw);
      if (!contact || contact.toLowerCase() === "oke" || contact === "ওকে" || contact === "him" || contact === "her") {
        contact = entityResolver.resolvePronoun("ওকে") || this.activeDraft?.contactName || "Contact";
      }

      // Message text extraction
      let messageText = this.extractMessageBody(raw);

      // Check for multi-turn combination:
      // Turn 1: "Rahul ke message koro" -> user didn't give message text yet
      if (!messageText) {
        // If user just said "Rahul ke message koro" or "ওকে WhatsApp করো":
        this.activeDraft = {
          contactName: contact,
          platform: platform !== "Default" ? platform : "WhatsApp",
          timestamp: Date.now(),
        };

        const clarify =
          lang === "bn"
            ? `${contact}-কে কী message পাঠাব?`
            : `What message would you like to send to ${contact}?`;

        return {
          matched: true,
          type: "MESSAGE",
          needsConfirmation: false,
          clarificationPrompt: clarify,
          actionPayload: { contactName: contact, platform },
        };
      }

      // If user had an active draft and now supplied the text (e.g. "বল আমি কাল আসব")
      if ((!contact || contact === "Contact") && this.activeDraft && Date.now() - this.activeDraft.timestamp < 120000) {
        contact = this.activeDraft.contactName || "Contact";
        if (platform === "Default") platform = this.activeDraft.platform || "WhatsApp";
      }

      const question =
        lang === "bn"
          ? `${contact}-কে ${platform === "Default" ? "" : platform + " এ "}এই message পাঠাব:\n"${messageText}"\nপাঠাব?`
          : `Send this message to ${contact} via ${platform === "Default" ? "messaging" : platform}:\n"${messageText}"\nSend now?`;

      this.pendingAction = {
        id: `act_${Date.now()}`,
        type: "MESSAGE",
        riskLevel: "HIGH",
        contactName: contact,
        platform,
        messageText,
        question,
        createdAt: Date.now(),
      };

      return {
        matched: true,
        type: "MESSAGE",
        needsConfirmation: true,
        confirmationQuestion: question,
        actionPayload: { contactName: contact, platform, messageText },
      };
    }

    // 4. Handle follow-up message when draft is waiting (e.g. "বল আমি কাল আসব" or "আমি ১০ মিনিট পরে আসছি")
    if (this.activeDraft && Date.now() - this.activeDraft.timestamp < 120000) {
      if (
        lower.startsWith("bolo ") ||
        lower.startsWith("বলো ") ||
        lower.startsWith("বল ") ||
        lower.startsWith("tell him ") ||
        lower.length > 3
      ) {
        const messageText = raw
          .replace(/^(?:bolo|বলো|বল|tell him|tell her|say that|বলুন)\s+/i, "")
          .trim();

        const contact = this.activeDraft.contactName || "Contact";
        const platform = this.activeDraft.platform || "WhatsApp";

        const question =
          lang === "bn"
            ? `${contact}-কে ${platform} এ এই message পাঠাব:\n"${messageText}"\nপাঠাব?`
            : `Send this message to ${contact} via ${platform}:\n"${messageText}"\nSend now?`;

        this.pendingAction = {
          id: `act_${Date.now()}`,
          type: "MESSAGE",
          riskLevel: "HIGH",
          contactName: contact,
          platform,
          messageText,
          question,
          createdAt: Date.now(),
        };

        this.activeDraft = null; // fulfilled

        return {
          matched: true,
          type: "MESSAGE",
          needsConfirmation: true,
          confirmationQuestion: question,
          actionPayload: { contactName: contact, platform, messageText },
        };
      }
    }

    return { matched: false };
  }

  /**
   * Executes confirmed communication action after user taps SEND / CONFIRM
   */
  public async executePending(): Promise<ActionVerification> {
    if (!this.pendingAction) {
      return { verified: false, message: "No pending communication action." };
    }

    const action = this.pendingAction;
    this.pendingAction = null;
    this.activeDraft = null;

    if (action.type === "MESSAGE") {
      const payload: CommunicationMessagePayload = {
        contactName: action.contactName || "Contact",
        platform: action.platform || "WhatsApp",
        messageText: action.messageText || "",
        confirmed: true,
      };

      const result = await androidBridge.dispatchAction({
        action: "SEND_MESSAGE",
        target: payload.contactName,
        text: payload.messageText,
        riskLevel: "HIGH",
        confirmation: true,
        params: { platform: payload.platform },
      });

      unifiedContextManager.setLastAction(`Message sent to ${payload.contactName}`, payload);
      return result;
    }

    if (action.type === "CALL") {
      const payload: CallPayload = {
        contactName: action.contactName || "Contact",
        confirmed: true,
      };

      const result = await androidBridge.dispatchAction({
        action: "MAKE_CALL",
        target: payload.contactName,
        riskLevel: "HIGH",
        confirmation: true,
      });

      unifiedContextManager.setLastAction(`Call to ${payload.contactName}`, payload);
      return result;
    }

    if (action.type === "DELETE") {
      const payload: DeletePayload = {
        targetItem: action.targetItem || "item",
        itemType: "photo",
        confirmed: true,
      };

      const result = await androidBridge.dispatchAction({
        action: "DELETE_ITEM",
        target: payload.targetItem,
        riskLevel: "HIGH",
        confirmation: true,
      });

      unifiedContextManager.setLastAction(`Deleted ${payload.targetItem}`, payload);
      return result;
    }

    return { verified: false, message: "Unsupported action." };
  }

  private extractContactName(text: string): string | null {
    // Matches "Rahul ke", "Rahul-ke", "Rahul ke bolo", "রাহুলকে", "রাহুল কে"
    const m1 = text.match(/([A-Z][a-z0-9]+)(?:-?ke|-?কে|\s+ke|\s+কে)/i);
    if (m1 && !["tani", "whatsapp", "sms", "message"].includes(m1[1].toLowerCase())) {
      return m1[1];
    }

    const m2 = text.match(/(?:call|message|text|কল করো|মেসেজ পাঠাও)\s+([A-Za-z\u0980-\u09FF]+)/i);
    if (m2 && !["him", "her", "tani", "whatsapp", "sms"].includes(m2[1].toLowerCase())) {
      return m2[1];
    }

    return null;
  }

  private extractMessageBody(text: string): string | null {
    // Matches "bolo ...", "বলো ...", "message: ...", "বল ..."
    const match = text.match(/(?:bolo|বলো|বল|tell him|tell her|say that|message)\s+(?:that|যে)?\s*(.+)/i);
    if (match) {
      return match[1].replace(/[।!?.]+$/, "").trim();
    }
    return null;
  }
}

export const communicationEngine = CommunicationEngine.getInstance();
