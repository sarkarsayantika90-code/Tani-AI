import { DetectedLanguage } from "../types";
import { confirmationManager } from "./confirmationManager";
import { entityResolver } from "./entityResolver";
import { SpeechNormalizer, NormalizedActionIntent } from "./speechNormalizer";
import { unifiedContextManager } from "./unifiedContextManager";

export interface ReasoningResult {
  understoodGoal: string;
  targetApp?: string;
  targetEntity?: string;
  normalizedAction: NormalizedActionIntent;
  requiresTool: boolean;
  toolName?: string;
  toolArgs?: Record<string, any>;
  requiresConfirmation: boolean;
  confirmationQuestion?: string;
  needsClarification: boolean;
  clarificationQuestion?: string;
}

export class ReasoningEngine {
  private static instance: ReasoningEngine | null = null;

  private constructor() {}

  public static getInstance(): ReasoningEngine {
    if (!ReasoningEngine.instance) {
      ReasoningEngine.instance = new ReasoningEngine();
    }
    return ReasoningEngine.instance;
  }

  /**
   * Applies structured pre-execution reasoning to determine intent, context,
   * necessary tools, verification requirements, and confirmation states.
   */
  public reason(
    rawInput: string,
    userLang: DetectedLanguage = "bn"
  ): ReasoningResult {
    // 1. Entity resolution & pronoun replacement
    const resolvedEntities = entityResolver.resolve(rawInput);
    const resolvedText = resolvedEntities.resolvedText;

    // 2. Speech semantic normalization
    const normalized = SpeechNormalizer.normalize(resolvedText);
    const activeApp = unifiedContextManager.getActiveApp();

    // 3. Follow-up context check
    const followUp = unifiedContextManager.resolveFollowUpWithContext(resolvedText);

    // Scenario A: SENSITIVE ACTION -> Call Contact
    if (normalized.normalizedAction === "CALL") {
      const contactTarget =
        normalized.targetEntity ||
        resolvedEntities.referencedEntity?.name ||
        entityResolver.findRecentEntityByType("contact")?.name;

      if (!contactTarget) {
        return {
          understoodGoal: "Call contact, but target is missing",
          normalizedAction: "CALL",
          requiresTool: false,
          requiresConfirmation: false,
          needsClarification: true,
          clarificationQuestion:
            userLang === "bn" ? "কাকে call করব?" : "Who would you like me to call?",
        };
      }

      const confirmQ = confirmationManager.generateConfirmationQuestion("call", contactTarget, userLang);
      return {
        understoodGoal: `Call ${contactTarget}`,
        targetEntity: contactTarget,
        normalizedAction: "CALL",
        requiresTool: true,
        toolName: "callContact",
        toolArgs: { name: contactTarget },
        requiresConfirmation: true,
        confirmationQuestion: confirmQ,
        needsClarification: false,
      };
    }

    // Scenario B: SCROLL ACTION
    if (normalized.normalizedAction === "SCROLL_DOWN") {
      return {
        understoodGoal: `Scroll down in ${activeApp || "current view"}`,
        targetApp: activeApp || undefined,
        normalizedAction: "SCROLL_DOWN",
        requiresTool: true,
        toolName: "scroll",
        toolArgs: { direction: "down" },
        requiresConfirmation: false,
        needsClarification: false,
      };
    }

    if (normalized.normalizedAction === "SCROLL_UP") {
      return {
        understoodGoal: `Scroll up in ${activeApp || "current view"}`,
        targetApp: activeApp || undefined,
        normalizedAction: "SCROLL_UP",
        requiresTool: true,
        toolName: "scroll",
        toolArgs: { direction: "up" },
        requiresConfirmation: false,
        needsClarification: false,
      };
    }

    // Scenario C: REPEAT MORE / AGAIN
    if (normalized.normalizedAction === "REPEAT_MORE" || normalized.normalizedAction === "REPEAT_ACTION") {
      const lastAction = unifiedContextManager.getLastAction();
      return {
        understoodGoal: `Repeat previous action: ${lastAction || "scroll"}`,
        targetApp: activeApp || undefined,
        normalizedAction: normalized.normalizedAction,
        requiresTool: true,
        toolName: "scroll",
        toolArgs: { direction: "down" },
        requiresConfirmation: false,
        needsClarification: false,
      };
    }

    // Scenario D: OPEN APP
    if (normalized.normalizedAction === "OPEN" && normalized.targetEntity) {
      return {
        understoodGoal: `Open ${normalized.targetEntity}`,
        targetApp: normalized.targetEntity,
        normalizedAction: "OPEN",
        requiresTool: true,
        toolName: "openApp",
        toolArgs: { appName: normalized.targetEntity },
        requiresConfirmation: false,
        needsClarification: false,
      };
    }

    // Scenario E: STOP
    if (normalized.normalizedAction === "STOP") {
      return {
        understoodGoal: "Stop immediate speech and actions",
        normalizedAction: "STOP",
        requiresTool: false,
        requiresConfirmation: false,
        needsClarification: false,
      };
    }

    // Default conversational reasoning
    return {
      understoodGoal: "Conversational query or generative task",
      targetApp: activeApp || undefined,
      normalizedAction: "UNKNOWN",
      requiresTool: false,
      requiresConfirmation: false,
      needsClarification: false,
    };
  }
}

export const reasoningEngine = ReasoningEngine.getInstance();
