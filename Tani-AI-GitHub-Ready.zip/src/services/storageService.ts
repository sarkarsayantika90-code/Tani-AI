import {
  UserPreferences,
  Conversation,
  BackgroundTask,
  ReminderItem,
  ContactItem,
  ProactiveAlert,
} from "../types";

const PREFS_KEY = "tani_user_preferences";
const CONVERSATIONS_KEY = "tani_conversations";
const TASKS_KEY = "tani_background_tasks";
const REMINDERS_KEY = "tani_reminders";
const MEMORY_KEY = "tani_long_term_memory";
const CONTACTS_KEY = "tani_contacts";
const ALERTS_KEY = "tani_proactive_alerts";

const DEFAULT_PREFERENCES: UserPreferences = {
  userName: "",
  profilePhoto: "",
  onboardingCompleted: false,
  apiKey: "",
  hasCustomApiKey: false,
  personality: {
    mode: "Assistant",
    tone: "balanced",
    responseLength: "normal",
    language: "auto",
    friendliness: 4,
    technicalDepth: 3,
  },
  voiceEnabled: true,
  voiceSpeed: 1.0,
  autoSpeak: true,
  wakeWordEnabled: false,
  backgroundAssistant: false,
  continuousVoice: false,
  floatingAssistantEnabled: false,
  proactiveAssistant: true,
  theme: "midnight",
  darkMode: true,
  glowEffect: true,
  ambientGlowEnabled: true,
  ambientGlowIntensity: "medium",
  animationIntensity: "medium",
  appLockEnabled: false,
  pinCode: "",
  biometricEnabled: false,
  emotionTone: "Neutral",
};

const DEFAULT_CONTACTS: ContactItem[] = [
  { id: "c1", name: "Anik", phone: "+91 98765 43210", email: "anikmondal8680@gmail.com" },
  { id: "c2", name: "Rahul", phone: "+91 98300 12345", email: "rahul.dev@example.com" },
  { id: "c3", name: "Priya", phone: "+91 98123 45678", email: "priya.sharma@example.com" },
  { id: "c4", name: "Mom", phone: "+91 99000 88776", email: "family@example.com" },
];

export const StorageService = {
  getPreferences(): UserPreferences {
    try {
      const data = localStorage.getItem(PREFS_KEY);
      if (data) {
        return { ...DEFAULT_PREFERENCES, ...JSON.parse(data) };
      }
    } catch (e) {
      console.error("Failed to load preferences", e);
    }
    return DEFAULT_PREFERENCES;
  },

  savePreferences(prefs: UserPreferences): void {
    try {
      localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
    } catch (e) {
      console.error("Failed to save preferences", e);
    }
  },

  getConversations(): Conversation[] {
    try {
      const data = localStorage.getItem(CONVERSATIONS_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error("Failed to load conversations", e);
    }
    return [];
  },

  saveConversations(conversations: Conversation[]): void {
    try {
      localStorage.setItem(CONVERSATIONS_KEY, JSON.stringify(conversations));
    } catch (e) {
      console.error("Failed to save conversations", e);
    }
  },

  getTasks(): BackgroundTask[] {
    try {
      const data = localStorage.getItem(TASKS_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error("Failed to load tasks", e);
    }
    return [];
  },

  saveTasks(tasks: BackgroundTask[]): void {
    try {
      localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
    } catch (e) {
      console.error("Failed to save tasks", e);
    }
  },

  getReminders(): ReminderItem[] {
    try {
      const data = localStorage.getItem(REMINDERS_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error("Failed to load reminders", e);
    }
    return [];
  },

  saveReminders(reminders: ReminderItem[]): void {
    try {
      localStorage.setItem(REMINDERS_KEY, JSON.stringify(reminders));
    } catch (e) {
      console.error("Failed to save reminders", e);
    }
  },

  getContacts(): ContactItem[] {
    try {
      const data = localStorage.getItem(CONTACTS_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error("Failed to load contacts", e);
    }
    return DEFAULT_CONTACTS;
  },

  getMemoryNotes(): string[] {
    try {
      const data = localStorage.getItem(MEMORY_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error("Failed to load memory notes", e);
    }
    return [
      "User prefers natural conversation in Bengali, Hindi, and English.",
      "Developer & Creator is Anik.",
      "Support email is anikmondal8680@gmail.com.",
      "Always address user with warmth and high precision."
    ];
  },

  saveMemoryNotes(notes: string[]): void {
    try {
      localStorage.setItem(MEMORY_KEY, JSON.stringify(notes));
    } catch (e) {
      console.error("Failed to save memory notes", e);
    }
  },

  getAlerts(): ProactiveAlert[] {
    try {
      const data = localStorage.getItem(ALERTS_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error("Failed to load alerts", e);
    }
    return [
      {
        id: "alert_welcome",
        title: "Tani Ready",
        message: "Your neural assistant is calibrated and standing by.",
        timestamp: Date.now() - 3600000,
        type: "status",
        read: false,
      },
    ];
  },

  saveAlerts(alerts: ProactiveAlert[]): void {
    try {
      localStorage.setItem(ALERTS_KEY, JSON.stringify(alerts));
    } catch (e) {
      console.error("Failed to save alerts", e);
    }
  },

  addAlert(alert: Omit<ProactiveAlert, "id" | "timestamp">): ProactiveAlert {
    const list = this.getAlerts();
    const newAlert: ProactiveAlert = {
      ...alert,
      id: `alert_${Date.now()}`,
      timestamp: Date.now(),
      read: false,
    };
    const updated = [newAlert, ...list].slice(0, 20);
    this.saveAlerts(updated);
    return newAlert;
  },

  clearMemory(): void {
    localStorage.removeItem(MEMORY_KEY);
  },

  clearAllData(): void {
    localStorage.removeItem(PREFS_KEY);
    localStorage.removeItem(CONVERSATIONS_KEY);
    localStorage.removeItem(TASKS_KEY);
    localStorage.removeItem(REMINDERS_KEY);
    localStorage.removeItem(MEMORY_KEY);
    localStorage.removeItem(CONTACTS_KEY);
    localStorage.removeItem(ALERTS_KEY);
  },
};
