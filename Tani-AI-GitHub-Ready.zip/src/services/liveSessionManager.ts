import { ConversationalTurnState, DetectedLanguage } from "../types";
import { languageEngine } from "./languageEngine";

export interface LiveSessionCallbacks {
  onTurnStateChange?: (state: ConversationalTurnState) => void;
  onUserTranscript?: (text: string, isFinal: boolean) => void;
  onModelTranscript?: (text: string) => void;
  onAudioLevel?: (level: number) => void;
  onError?: (error: string) => void;
  onPermissionDenied?: () => void;
  onTurnComplete?: () => void;
  onSessionEnded?: () => void;
  onWakeWordDetected?: () => void;
}

export interface LiveSessionConfig {
  apiKey?: string;
  userName?: string;
  language?: string;
  continuousMode?: boolean;
  voiceName?: string;
  silenceThresholdMs?: number;
}

export class LiveSessionManager {
  private static instance: LiveSessionManager | null = null;

  // Connection & audio state
  private ws: WebSocket | null = null;
  private isConnecting: boolean = false;
  private isSessionActive: boolean = false;
  private turnState: ConversationalTurnState = "IDLE";
  private callbacks: LiveSessionCallbacks = {};
  private config: LiveSessionConfig = {
    continuousMode: true,
    voiceName: "Aoede",
    silenceThresholdMs: 1200,
  };

  // Web Audio pipeline
  private inputAudioCtx: AudioContext | null = null;
  private playbackAudioCtx: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private processorNode: ScriptProcessorNode | null = null;
  private activeSourceNodes: AudioBufferSourceNode[] = [];
  private nextPlaybackTime: number = 0;
  private isPlayingAudio: boolean = false;

  // Turn Detection & Silence state
  private speechStartTimestamp: number = 0;
  private lastSpeechTimestamp: number = 0;
  private silenceCheckTimer: any = null;
  private isUserSpeaking: boolean = false;
  private recentAudioLevels: number[] = [];
  private consecutiveSilentBuffers: number = 0;

  // Transcripts
  private accumulatedUserTranscript: string = "";
  private accumulatedModelTranscript: string = "";

  private constructor() {}

  public static getInstance(): LiveSessionManager {
    if (!LiveSessionManager.instance) {
      LiveSessionManager.instance = new LiveSessionManager();
    }
    return LiveSessionManager.instance;
  }

  public setCallbacks(callbacks: LiveSessionCallbacks): void {
    this.callbacks = { ...this.callbacks, ...callbacks };
  }

  public setConfig(config: Partial<LiveSessionConfig>): void {
    this.config = { ...this.config, ...config };
  }

  public getTurnState(): ConversationalTurnState {
    return this.turnState;
  }

  public isConnected(): boolean {
    return this.isSessionActive && this.ws !== null && this.ws.readyState === WebSocket.OPEN;
  }

  public isSpeaking(): boolean {
    return this.isPlayingAudio || this.turnState === "TANI_SPEAKING";
  }

  public isListening(): boolean {
    return (
      this.turnState === "USER_SPEAKING" ||
      this.turnState === "USER_PAUSED" ||
      this.turnState === "WAITING_FOR_COMPLETION" ||
      (this.isSessionActive && !this.isPlayingAudio)
    );
  }

  private setTurnState(state: ConversationalTurnState): void {
    if (this.turnState === state) return;
    this.turnState = state;
    this.callbacks.onTurnStateChange?.(state);
  }

  /**
   * Starts a persistent Live Session
   */
  public async connect(overrideConfig?: Partial<LiveSessionConfig>): Promise<void> {
    if (overrideConfig) {
      this.setConfig(overrideConfig);
    }

    if (this.isSessionActive || this.isConnecting) {
      console.log("Live session already active or connecting");
      return;
    }

    this.isConnecting = true;
    this.setTurnState("IDLE");

    try {
      // 1. Establish microphone access
      await this.initMicrophone();

      // 2. Establish WebSocket connection to backend Live API bridge
      await this.initWebSocket();

      this.isSessionActive = true;
      this.isConnecting = false;
      this.setTurnState("WAITING_FOR_COMPLETION");
    } catch (err: any) {
      this.isConnecting = false;
      this.isSessionActive = false;
      this.setTurnState("IDLE");
      console.error("Failed to start Live session:", err);
      this.callbacks.onError?.(err?.message || "Failed to initialize voice session.");
    }
  }

  /**
   * Initializes microphone capture & 16kHz resampler
   */
  private async initMicrophone(): Promise<void> {
    if (!navigator.mediaDevices?.getUserMedia) {
      throw new Error("Microphone is not supported in this browser.");
    }

    try {
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
        video: false,
      });
    } catch (err: any) {
      if (err?.name === "NotAllowedError" || err?.name === "PermissionDeniedError") {
        this.callbacks.onPermissionDenied?.();
      }
      throw err;
    }

    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    this.inputAudioCtx = new AudioContextClass();
    if (this.inputAudioCtx.state === "suspended") {
      await this.inputAudioCtx.resume();
    }

    this.sourceNode = this.inputAudioCtx.createMediaStreamSource(this.mediaStream);
    // Buffer size 2048 at ~44.1k/48k gives ~45ms updates
    this.processorNode = this.inputAudioCtx.createScriptProcessor(2048, 1, 1);

    this.processorNode.onaudioprocess = (e) => {
      if (!this.isSessionActive) return;

      const inputBuffer = e.inputBuffer.getChannelData(0);

      // 1. Compute RMS energy
      let sum = 0;
      for (let i = 0; i < inputBuffer.length; i++) {
        sum += inputBuffer[i] * inputBuffer[i];
      }
      const rms = Math.sqrt(sum / inputBuffer.length);
      this.callbacks.onAudioLevel?.(Math.min(1, rms * 4));

      // 2. Interruption Check:
      // If Tani is currently speaking and user voice energy exceeds threshold,
      // STOP TANI AUDIO IMMEDIATELY!
      if (this.isPlayingAudio && rms > 0.04) {
        console.log("Interruption triggered by user voice energy:", rms);
        this.interrupt();
      }

      // 3. Turn Detection & Silence management
      this.processTurnDetection(rms);

      // 4. Stream 16kHz PCM to Gemini
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        const resampled = this.resampleTo16k(inputBuffer, this.inputAudioCtx!.sampleRate);
        const pcm16 = this.floatTo16BitPCM(resampled);
        const base64Audio = this.pcm16ToBase64(pcm16);

        this.ws.send(
          JSON.stringify({
            type: "audio",
            audio: base64Audio,
          })
        );
      }
    };

    this.sourceNode.connect(this.processorNode);
    this.processorNode.connect(this.inputAudioCtx.destination);
  }

  /**
   * Evaluates RMS energy against speech thresholds and timing windows
   */
  private processTurnDetection(rms: number): void {
    const SPEECH_THRESHOLD = 0.025;
    const now = Date.now();

    if (rms > SPEECH_THRESHOLD) {
      this.consecutiveSilentBuffers = 0;
      this.lastSpeechTimestamp = now;

      if (!this.isUserSpeaking) {
        this.isUserSpeaking = true;
        this.speechStartTimestamp = now;
        this.setTurnState("USER_SPEAKING");
      }
    } else {
      this.consecutiveSilentBuffers++;
      if (this.isUserSpeaking) {
        const silenceDuration = now - this.lastSpeechTimestamp;

        // SHORT_PAUSE (400ms - 700ms): user paused mid-sentence -> WAITING_FOR_COMPLETION
        if (silenceDuration > 450 && silenceDuration <= (this.config.silenceThresholdMs || 1200)) {
          if (this.turnState === "USER_SPEAKING") {
            this.setTurnState("USER_PAUSED");
          }
        }
        // END_OF_TURN (>= 1200ms): user finished turn
        else if (silenceDuration > (this.config.silenceThresholdMs || 1200)) {
          this.isUserSpeaking = false;
          this.setTurnState("TANI_THINKING");
        }
      }
    }
  }

  /**
   * Initializes WebSocket connection to backend Live bridge
   */
  private async initWebSocket(): Promise<void> {
    return new Promise((resolve, reject) => {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/api/live`;

      this.ws = new WebSocket(wsUrl);

      const connTimeout = setTimeout(() => {
        if (this.ws && this.ws.readyState !== WebSocket.OPEN) {
          this.ws.close();
          reject(new Error("Voice connection timed out. Please retry."));
        }
      }, 10000);

      this.ws.onopen = () => {
        clearTimeout(connTimeout);
        // Send init message with locked language & voice config
        const lockedLang = languageEngine.getLockedLanguage();
        this.ws?.send(
          JSON.stringify({
            type: "init",
            apiKey: this.config.apiKey,
            userName: this.config.userName,
            language: lockedLang,
            voiceName: this.config.voiceName || "Aoede",
          })
        );
        resolve();
      };

      this.ws.onmessage = (event) => {
        this.handleServerMessage(event.data);
      };

      this.ws.onerror = (err) => {
        console.error("Live WebSocket error:", err);
      };

      this.ws.onclose = () => {
        this.handleSessionEnded();
      };
    });
  }

  /**
   * Handles incoming messages from Gemini Live backend bridge
   */
  private handleServerMessage(rawData: string): void {
    try {
      const msg = JSON.parse(rawData);

      switch (msg.type) {
        case "ready":
        case "connected":
          this.setTurnState("WAITING_FOR_COMPLETION");
          break;

        case "audio":
          if (msg.audio) {
            this.setTurnState("TANI_SPEAKING");
            this.enqueueAudioChunk(msg.audio);
          }
          break;

        case "modelTranscript":
          if (msg.text) {
            this.accumulatedModelTranscript += msg.text;
            this.callbacks.onModelTranscript?.(this.accumulatedModelTranscript);
          }
          break;

        case "userTranscript":
          if (msg.text) {
            this.accumulatedUserTranscript = msg.text;
            this.callbacks.onUserTranscript?.(msg.text, msg.isFinal ?? false);
          }
          break;

        case "interrupted":
          this.interrupt();
          break;

        case "turnComplete":
          // Gemini finished generating turn; wait for playback to drain
          break;

        case "error":
          this.callbacks.onError?.(msg.error || "Live session error occurred.");
          break;
      }
    } catch (e) {
      console.error("Failed to parse Live message:", e);
    }
  }

  /**
   * Resamples an audio buffer to 16000Hz using linear interpolation
   */
  private resampleTo16k(inputData: Float32Array, inputSampleRate: number): Float32Array {
    if (inputSampleRate === 16000) return inputData;
    const ratio = inputSampleRate / 16000;
    const newLength = Math.round(inputData.length / ratio);
    const result = new Float32Array(newLength);

    for (let i = 0; i < newLength; i++) {
      const origIndex = i * ratio;
      const index1 = Math.floor(origIndex);
      const index2 = Math.min(index1 + 1, inputData.length - 1);
      const frac = origIndex - index1;
      result[i] = inputData[index1] * (1 - frac) + inputData[index2] * frac;
    }
    return result;
  }

  private floatTo16BitPCM(input: Float32Array): Int16Array {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return output;
  }

  private pcm16ToBase64(int16: Int16Array): string {
    const uint8 = new Uint8Array(int16.buffer, int16.byteOffset, int16.byteLength);
    let binary = "";
    const len = uint8.byteLength;
    const chunkSize = 8192;
    for (let i = 0; i < len; i += chunkSize) {
      const chunk = uint8.subarray(i, Math.min(i + chunkSize, len));
      binary += String.fromCharCode.apply(null, Array.from(chunk));
    }
    return btoa(binary);
  }

  private base64ToFloat32Array(base64: string): Float32Array {
    const binaryStr = atob(base64);
    const len = binaryStr.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryStr.charCodeAt(i);
    }
    const int16 = new Int16Array(bytes.buffer, bytes.byteOffset, bytes.byteLength / 2);
    const float32 = new Float32Array(int16.length);
    for (let i = 0; i < int16.length; i++) {
      float32[i] = int16[i] / 32768.0;
    }
    return float32;
  }

  private getPlaybackContext(): AudioContext {
    if (!this.playbackAudioCtx || this.playbackAudioCtx.state === "closed") {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.playbackAudioCtx = new AudioContextClass();
    }
    if (this.playbackAudioCtx.state === "suspended") {
      this.playbackAudioCtx.resume();
    }
    return this.playbackAudioCtx;
  }

  /**
   * Enqueues 24kHz audio from Gemini into gapless playback queue
   */
  public enqueueAudioChunk(base64PCM: string): void {
    const ctx = this.getPlaybackContext();
    const float32 = this.base64ToFloat32Array(base64PCM);
    if (float32.length === 0) return;

    // 24kHz audio buffer
    const audioBuffer = ctx.createBuffer(1, float32.length, 24000);
    audioBuffer.getChannelData(0).set(float32);

    const source = ctx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(ctx.destination);

    const now = ctx.currentTime;
    const startTime = Math.max(now, this.nextPlaybackTime);
    source.start(startTime);
    this.nextPlaybackTime = startTime + audioBuffer.duration;
    this.activeSourceNodes.push(source);
    this.isPlayingAudio = true;

    source.onended = () => {
      const idx = this.activeSourceNodes.indexOf(source);
      if (idx !== -1) {
        this.activeSourceNodes.splice(idx, 1);
      }
      if (this.activeSourceNodes.length === 0) {
        this.isPlayingAudio = false;
        this.callbacks.onAudioLevel?.(0);
        this.handleTurnEnd();
      }
    };
  }

  /**
   * Instant Interruption: stops Tani audio playback immediately
   */
  public interrupt(): void {
    this.isPlayingAudio = false;
    for (const node of this.activeSourceNodes) {
      try {
        node.stop();
        node.disconnect();
      } catch {
        // ignore
      }
    }
    this.activeSourceNodes = [];
    if (this.playbackAudioCtx) {
      this.nextPlaybackTime = this.playbackAudioCtx.currentTime;
    }
    this.callbacks.onAudioLevel?.(0);

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: "interrupt" }));
    }

    this.setTurnState("USER_SPEAKING");
  }

  /**
   * Called when Tani audio playback queue drains
   */
  private handleTurnEnd(): void {
    if (this.activeSourceNodes.length > 0) return;

    this.callbacks.onTurnComplete?.();
    this.accumulatedModelTranscript = "";
    this.accumulatedUserTranscript = "";

    // Continuous Mode: Do NOT close session! Immediately return to listening
    if (this.config.continuousMode && this.isSessionActive) {
      this.setTurnState("WAITING_FOR_COMPLETION");
    } else {
      this.disconnect();
    }
  }

  private handleSessionEnded(): void {
    this.isSessionActive = false;
    this.isConnecting = false;
    this.interrupt();
    this.setTurnState("IDLE");
    this.callbacks.onSessionEnded?.();
  }

  /**
   * Full cleanup and disconnect
   */
  public disconnect(): void {
    this.isConnecting = false;
    this.isSessionActive = false;
    this.interrupt();

    if (this.processorNode) {
      try {
        this.processorNode.onaudioprocess = null;
        this.processorNode.disconnect();
      } catch {
        // ignore
      }
      this.processorNode = null;
    }

    if (this.sourceNode) {
      try {
        this.sourceNode.disconnect();
      } catch {
        // ignore
      }
      this.sourceNode = null;
    }

    if (this.mediaStream) {
      try {
        this.mediaStream.getTracks().forEach((t) => t.stop());
      } catch {
        // ignore
      }
      this.mediaStream = null;
    }

    if (this.inputAudioCtx && this.inputAudioCtx.state !== "closed") {
      try {
        this.inputAudioCtx.close();
      } catch {
        // ignore
      }
      this.inputAudioCtx = null;
    }

    if (this.ws) {
      try {
        if (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING) {
          this.ws.send(JSON.stringify({ type: "close" }));
          this.ws.close();
        }
      } catch {
        // ignore
      }
      this.ws = null;
    }

    this.setTurnState("IDLE");
  }

  public async reconnect(): Promise<void> {
    this.disconnect();
    await new Promise((r) => setTimeout(r, 300));
    await this.connect();
  }
}

export const liveSessionManager = LiveSessionManager.getInstance();
