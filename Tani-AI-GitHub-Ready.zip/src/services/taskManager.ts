import { MultiStepPlanStep, BackgroundTask } from "../types";
import { StorageService } from "./storageService";
import { toolRouter } from "./toolRouter";
import { unifiedContextManager } from "./unifiedContextManager";

export interface MultiStepExecutionResult {
  completedSteps: number;
  totalSteps: number;
  allSucceeded: boolean;
  finalMessage: string;
  steps: MultiStepPlanStep[];
}

export class TaskManager {
  private static instance: TaskManager | null = null;
  private activePlan: MultiStepPlanStep[] = [];
  private isExecuting: boolean = false;

  private constructor() {}

  public static getInstance(): TaskManager {
    if (!TaskManager.instance) {
      TaskManager.instance = new TaskManager();
    }
    return TaskManager.instance;
  }

  public getActivePlan(): MultiStepPlanStep[] {
    return this.activePlan;
  }

  public isBusy(): boolean {
    return this.isExecuting;
  }

  /**
   * Evaluates if a query represents a multi-step action, e.g.:
   * "Open YouTube and search for Bengali songs"
   */
  public planChainedTask(userPrompt: string): MultiStepPlanStep[] | null {
    const raw = userPrompt.trim().toLowerCase();

    // Check for "Open [App] and search for [Query]"
    const openAndSearchMatch = userPrompt.match(
      /(?:open|খুলো|খোলো)\s+([A-Za-z0-9]+)\s+(?:and|এবং|আর|তারপর)\s+(?:search|search\s+for|সার্চ\s+করো)\s+(.+)/i
    );

    if (openAndSearchMatch) {
      const app = openAndSearchMatch[1].trim();
      const query = openAndSearchMatch[2].trim();
      return [
        {
          id: "step_1",
          description: `Open ${app}`,
          tool: "openApp",
          args: { appName: app },
          status: "pending",
          verificationExpected: `${app} active`,
        },
        {
          id: "step_2",
          description: `Find search input in ${app}`,
          tool: "findUIElement",
          args: { query: "search" },
          status: "pending",
        },
        {
          id: "step_3",
          description: `Type search query "${query}"`,
          tool: "typeText",
          args: { text: query },
          status: "pending",
        },
        {
          id: "step_4",
          description: `Submit search query in ${app}`,
          tool: "webSearch",
          args: { query, app },
          status: "pending",
        },
      ];
    }

    return null;
  }

  /**
   * Executes a multi-step plan with verification at each step
   */
  public async executePlan(
    steps: MultiStepPlanStep[],
    userLang: "bn" | "en" | "hi" = "bn"
  ): Promise<MultiStepExecutionResult> {
    this.isExecuting = true;
    this.activePlan = steps;
    let completed = 0;

    for (const step of steps) {
      step.status = "executing";
      try {
        const result = await toolRouter.executeTool(step.tool, step.args, userLang);
        if (result.success && result.verified) {
          step.status = "verified";
          step.result = result.result;
          completed++;
        } else {
          step.status = "failed";
          step.result = result.result;
          this.isExecuting = false;
          return {
            completedSteps: completed,
            totalSteps: steps.length,
            allSucceeded: false,
            finalMessage: result.result || `Step ${step.description} failed verification.`,
            steps,
          };
        }
      } catch (err: any) {
        step.status = "failed";
        step.result = err?.message;
        this.isExecuting = false;
        return {
          completedSteps: completed,
          totalSteps: steps.length,
          allSucceeded: false,
          finalMessage: `Encountered issue executing ${step.description}.`,
          steps,
        };
      }
    }

    this.isExecuting = false;
    unifiedContextManager.setLastAction(`Completed ${steps.length}-step task`);

    const finalMessage =
      userLang === "bn"
        ? `সকল ধাপ সফলভাবে সম্পন্ন হয়েছে।`
        : `All task steps completed successfully.`;

    return {
      completedSteps: completed,
      totalSteps: steps.length,
      allSucceeded: true,
      finalMessage,
      steps,
    };
  }

  public static createBackgroundTask(
    title: string,
    codeOutput?: { language: string; code: string; htmlPreview?: string }
  ): BackgroundTask {
    const task: BackgroundTask = {
      id: `task_${Date.now()}`,
      title,
      status: "completed",
      progress: 100,
      createdTime: Date.now(),
      completedTime: Date.now(),
      result: "Completed successfully by Tani AI",
      codeOutput,
    };
    const tasks = StorageService.getTasks();
    StorageService.saveTasks([task, ...tasks]);

    StorageService.addAlert({
      title: "Task Completed",
      message: `${title} has finished processing.`,
      type: "task",
    });

    return task;
  }

  public createBackgroundTask(
    title: string,
    codeOutput?: { language: string; code: string; htmlPreview?: string }
  ): BackgroundTask {
    return TaskManager.createBackgroundTask(title, codeOutput);
  }
}

export const taskManager = TaskManager.getInstance();
