import { Message, PersonalityMode, LanguageCode } from "../types";

export interface ChatRequestParams {
  prompt: string;
  history?: Message[];
  personality?: PersonalityMode;
  language?: LanguageCode;
  image?: { data: string; mimeType: string };
  apiKey?: string;
  userName?: string;
}

export interface ChatResponse {
  text: string;
  codeBlocks: {
    language: string;
    code: string;
    isWebsite?: boolean;
  }[];
  detectedTool?: {
    name: string;
    arguments: Record<string, any>;
  };
  isWebsiteGeneration?: boolean;
  websiteHtml?: string;
}

export const AiService = {
  async testApiKey(apiKey?: string): Promise<{ success: boolean; message: string }> {
    try {
      const response = await fetch("/api/test-key", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ apiKey }),
      });
      const data = await response.json();
      if (!response.ok) {
        return { success: false, message: data.error || "Connection test failed." };
      }
      return { success: true, message: data.message || "Connection verified. Tani AI ready." };
    } catch (e: any) {
      return { success: false, message: e?.message || "Failed to reach server." };
    }
  },

  async sendMessage(params: ChatRequestParams): Promise<ChatResponse> {
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: params.prompt,
          history: params.history?.map((m) => ({
            role: m.role === "tani" ? "model" : "user",
            content: m.content,
          })),
          personality: params.personality,
          language: params.language,
          image: params.image,
          apiKey: params.apiKey,
          userName: params.userName,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        let errMsg = errorData.message || `Server error: ${response.status}`;
        try {
          const parsed = JSON.parse(errMsg);
          if (parsed?.error?.message) {
            errMsg = parsed.error.message;
          }
        } catch {
          // not json
        }
        if (
          errMsg.includes("503") ||
          errMsg.toLowerCase().includes("high demand") ||
          errMsg.toLowerCase().includes("unavailable")
        ) {
          errMsg = "Tani AI is currently experiencing high network demand. Please try again in a moment.";
        } else if (
          errMsg.includes("429") ||
          errMsg.toLowerCase().includes("quota") ||
          errMsg.toLowerCase().includes("resource_exhausted")
        ) {
          errMsg = "Gemini API request rate limit reached. Please wait a few moments and try again.";
        }
        throw new Error(errMsg);
      }

      const data = await response.json();
      const rawText: string = data.text || "";

      // Parse code blocks
      const codeBlocks = this.extractCodeBlocks(rawText);
      const isWebsite = codeBlocks.some((b) => b.isWebsite);
      const websiteHtml = codeBlocks.find((b) => b.isWebsite)?.code || "";

      // Detect tool triggers from user prompt or AI response
      const detectedTool = this.detectTool(params.prompt, rawText);

      return {
        text: rawText,
        codeBlocks,
        detectedTool,
        isWebsiteGeneration: isWebsite,
        websiteHtml,
      };
    } catch (error: any) {
      console.error("AI Service error:", error);
      throw error;
    }
  },

  extractCodeBlocks(text: string): { language: string; code: string; isWebsite?: boolean }[] {
    const codeBlockRegex = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g;
    const blocks: { language: string; code: string; isWebsite?: boolean }[] = [];
    let match;

    while ((match = codeBlockRegex.exec(text)) !== null) {
      const lang = (match[1] || "text").toLowerCase().trim();
      const code = match[2].trim();
      const isHtmlWebsite =
        lang === "html" ||
        code.includes("<!DOCTYPE html>") ||
        (code.includes("<html") && code.includes("</html>"));

      blocks.push({
        language: lang || "code",
        code,
        isWebsite: isHtmlWebsite,
      });
    }

    return blocks;
  },

  detectTool(userPrompt: string, _aiResponse: string): { name: string; arguments: Record<string, any> } | undefined {
    const p = userPrompt.toLowerCase();

    // Call Contact
    if (p.includes("call ") || p.includes("ফোন করো") || p.includes("কল করো") || p.includes("phone ")) {
      const match = userPrompt.match(/(?:call|ফোন করো|কল করো)\s+([A-Za-z0-9\u0980-\u09FF]+)/i);
      const contactName = match ? match[1].trim() : "Contact";
      return {
        name: "callContact",
        arguments: { name: contactName },
      };
    }

    // Send Message / WhatsApp
    if (p.includes("send message") || p.includes("whatsapp") || p.includes("মেসেজ পাঠাও") || p.includes("বার্তা পাঠাও")) {
      return {
        name: "sendMessage",
        arguments: { message: userPrompt },
      };
    }

    // Email
    if (p.includes("email") || p.includes("ইমেইল") || p.includes("মেইল পাঠাও")) {
      return {
        name: "composeEmail",
        arguments: { details: userPrompt },
      };
    }

    // Timer
    if (p.includes("timer") || p.includes("টাইমার")) {
      const minuteMatch = userPrompt.match(/(\d+)\s*(?:minutes?|min|মিনিট)/i);
      const secondMatch = userPrompt.match(/(\d+)\s*(?:seconds?|sec|সেকেন্ড)/i);
      let seconds = 60;
      if (minuteMatch) seconds = parseInt(minuteMatch[1], 10) * 60;
      else if (secondMatch) seconds = parseInt(secondMatch[1], 10);

      return {
        name: "setTimer",
        arguments: { durationSeconds: seconds },
      };
    }

    // Reminder
    if (p.includes("remind") || p.includes("মনে করিয়ে দিও") || p.includes("রিমাইন্ডার")) {
      return {
        name: "createReminder",
        arguments: { text: userPrompt },
      };
    }

    // Weather
    if (p.includes("weather") || p.includes("আবহাওয়া") || p.includes("मौसम") || p.includes("temperature")) {
      return {
        name: "getWeather",
        arguments: { location: "Current Location" },
      };
    }

    // App Launch
    if (p.includes("open ") || p.includes("খুলো") || p.includes("খোলো")) {
      const match = userPrompt.match(/(?:open|খুলো|খোলো)\s+([A-Za-z0-9]+)/i);
      if (match) {
        return {
          name: "openApp",
          arguments: { appName: match[1].trim() },
        };
      }
    }

    return undefined;
  },

  async fetchWeather(lat?: number, lon?: number, city?: string) {
    try {
      const query = new URLSearchParams();
      if (lat) query.set("lat", lat.toString());
      if (lon) query.set("lon", lon.toString());
      if (city) query.set("city", city);

      const res = await fetch(`/api/weather?${query.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch weather");
      return await res.json();
    } catch (e) {
      console.error("Weather fetch failed", e);
      return null;
    }
  },
};
