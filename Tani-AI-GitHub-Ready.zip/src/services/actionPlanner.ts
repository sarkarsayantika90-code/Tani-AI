import {
  StructuredAndroidAction,
  ActionRiskLevel,
  AndroidActionType,
} from "../types";
import { unifiedContextManager } from "./unifiedContextManager";
import { entityResolver } from "./entityResolver";

export class ActionPlanner {
  private static instance: ActionPlanner | null = null;

  private constructor() {}

  public static getInstance(): ActionPlanner {
    if (!ActionPlanner.instance) {
      ActionPlanner.instance = new ActionPlanner();
    }
    return ActionPlanner.instance;
  }

  /**
   * Plans a structured Android action from user prompt and context
   */
  public plan(userPrompt: string, lang: "bn" | "en" | "hi" = "bn"): StructuredAndroidAction | null {
    const raw = userPrompt.trim();
    const lower = raw.toLowerCase();

    // 1. OPEN APP ("Tani YouTube kholo", "Open YouTube", "ইউটিউব খোলো", "Chrome খুলে দাও")
    const openMatch = lower.match(
      /(?:open|launch|kholo|খুলো|খোলো|খুলে\s+দাও|চালু\s+করো)\s+([A-Za-z0-9\u0980-\u09FF]+)/i
    );
    const reverseOpenMatch = lower.match(
      /([A-Za-z0-9\u0980-\u09FF]+)\s+(?:kholo|khulbe|open\s+koro|খোলো|খুলো)/i
    );

    if (openMatch || reverseOpenMatch) {
      let rawApp = openMatch ? openMatch[1] : reverseOpenMatch![1];
      const app = this.normalizeAppName(rawApp);
      if (app) {
        return {
          action: "OPEN_APP",
          target: app,
          appName: app,
          riskLevel: "LOW",
          confirmation: false,
        };
      }
    }

    // 2. CLOSE APP ("Tani YouTube বন্ধ করো", "Close YouTube", "YouTube bondho koro")
    const closeMatch = lower.match(
      /([A-Za-z0-9\u0980-\u09FF]+)?\s*(?:close|exit|bondho\s+koro|বন্ধ\s+করো)\s*([A-Za-z0-9\u0980-\u09FF]+)?/i
    );
    if (closeMatch && (lower.includes("bondho") || lower.includes("বন্ধ") || lower.includes("close"))) {
      const candidate = closeMatch[1] || closeMatch[2] || unifiedContextManager.getActiveApp() || "App";
      const app = this.normalizeAppName(candidate);
      return {
        action: "CLOSE_APP",
        target: app,
        appName: app,
        riskLevel: "LOW",
        confirmation: false,
      };
    }

    // 3. SCROLL ("Tani নিচে scroll করো", "Tani আরও নিচে যাও", "এখন নিচে যাও", "Scroll down", "উপরে যাও")
    const isScrollDown =
      lower.includes("scroll down") ||
      lower.includes("নিচে scroll") ||
      lower.includes("নিচে যাও") ||
      lower.includes("আরও নিচে") ||
      lower.includes("aar niche") ||
      lower.includes("niche scroll") ||
      lower.includes("niche jao");

    const isScrollUp =
      lower.includes("scroll up") ||
      lower.includes("উপরে scroll") ||
      lower.includes("উপরে যাও") ||
      lower.includes("upore jao") ||
      lower.includes("upore scroll");

    if (isScrollDown) {
      return {
        action: "SCROLL",
        direction: "DOWN",
        riskLevel: "LOW",
        confirmation: false,
        target: unifiedContextManager.getActiveApp() || "Current Screen",
      };
    }

    if (isScrollUp) {
      return {
        action: "SCROLL",
        direction: "UP",
        riskLevel: "LOW",
        confirmation: false,
        target: unifiedContextManager.getActiveApp() || "Current Screen",
      };
    }

    // 4. NAVIGATION: HOME ("Tani home যাও", "Go home", "হোমে যাও")
    if (
      lower.includes("home jao") ||
      lower.includes("হোমে যাও") ||
      lower.includes("home যাও") ||
      lower.includes("go home") ||
      lower === "home"
    ) {
      return {
        action: "NAVIGATE_HOME",
        riskLevel: "LOW",
        confirmation: false,
      };
    }

    // 5. NAVIGATION: BACK ("Tani back যাও", "Go back", "ব্যাকে যাও", "ফিরে যাও")
    if (
      lower.includes("back jao") ||
      lower.includes("back যাও") ||
      lower.includes("go back") ||
      lower.includes("ব্যাকে যাও") ||
      lower.includes("ফিরে যাও") ||
      lower === "back"
    ) {
      return {
        action: "NAVIGATE_BACK",
        riskLevel: "LOW",
        confirmation: false,
      };
    }

    // 6. NAVIGATION: RECENTS ("Recent apps", "রিসেন্ট অ্যাপস", "recent apps kholo")
    if (lower.includes("recent") || lower.includes("রিসেন্ট")) {
      return {
        action: "RECENT_APPS",
        riskLevel: "LOW",
        confirmation: false,
      };
    }

    // 7. READ ACCESSIBILITY UI ("Read screen", "স্ক্রিন পড়ো", "স্ক্রিনে কী আছে")
    if (
      lower.includes("read screen") ||
      lower.includes("স্ক্রিন পড়ো") ||
      lower.includes("স্ক্রিনে কী আছে") ||
      lower.includes("what is on screen")
    ) {
      return {
        action: "READ_ACCESSIBILITY_UI",
        riskLevel: "LOW",
        confirmation: false,
      };
    }

    // 8. OPEN SETTINGS ("Open settings", "WiFi settings kholo", "Bluetooth settings")
    if (lower.includes("setting") || lower.includes("সেটিংস")) {
      let settingType = "General";
      if (lower.includes("wifi") || lower.includes("ওয়াইফাই")) settingType = "WiFi";
      else if (lower.includes("bluetooth") || lower.includes("ব্লুটুথ")) settingType = "Bluetooth";
      else if (lower.includes("display") || lower.includes("ডিসপ্লে")) settingType = "Display";
      else if (lower.includes("sound") || lower.includes("শব্দ")) settingType = "Sound";
      else if (lower.includes("accessibility") || lower.includes("অ্যাক্সেসিবিলিটি")) settingType = "Accessibility";

      return {
        action: "OPEN_SETTINGS",
        target: settingType,
        riskLevel: "LOW",
        confirmation: false,
      };
    }

    // 9. MEDIA CONTROLS ("Pause video", "Play video", "Volume up", "গান বন্ধ করো")
    if (
      lower.includes("pause") ||
      lower.includes("play") ||
      lower.includes("volume up") ||
      lower.includes("volume down") ||
      lower.includes("গান থামাও")
    ) {
      let cmd = "Play/Pause";
      if (lower.includes("volume up") || lower.includes("ভলিউম বাড়াও")) cmd = "Volume Up";
      else if (lower.includes("volume down") || lower.includes("ভলিউম কমাও")) cmd = "Volume Down";
      else if (lower.includes("pause") || lower.includes("থামাও")) cmd = "Pause";
      else if (lower.includes("play") || lower.includes("চালু করো")) cmd = "Play";

      return {
        action: "MEDIA_CONTROL",
        target: cmd,
        riskLevel: "LOW",
        confirmation: false,
      };
    }

    return null;
  }

  private normalizeAppName(raw: string): string {
    const clean = raw.trim().toLowerCase();
    const map: Record<string, string> = {
      youtube: "YouTube",
      ইউটিউব: "YouTube",
      chrome: "Chrome",
      ক্রোম: "Chrome",
      browser: "Chrome",
      ব্রাউজার: "Chrome",
      whatsapp: "WhatsApp",
      হোয়াটসঅ্যাপ: "WhatsApp",
      gmail: "Gmail",
      জিমেইল: "Gmail",
      camera: "Camera",
      ক্যামেরা: "Camera",
      settings: "Settings",
      সেটিংস: "Settings",
      maps: "Maps",
      ম্যাপস: "Maps",
      photos: "Photos",
      ফটোস: "Photos",
      gallery: "Gallery",
      গ্যালারি: "Gallery",
    };

    return map[clean] || (raw.charAt(0).toUpperCase() + raw.slice(1));
  }
}

export const actionPlanner = ActionPlanner.getInstance();
