import { ResolvedEntity } from "../types";

export interface ResolvedTurnEntities {
  rawText: string;
  resolvedText: string;
  entities: ResolvedEntity[];
  referencedEntity?: ResolvedEntity;
}

export class EntityResolver {
  private static instance: EntityResolver | null = null;
  private recentEntities: ResolvedEntity[] = [];

  private constructor() {}

  public static getInstance(): EntityResolver {
    if (!EntityResolver.instance) {
      EntityResolver.instance = new EntityResolver();
    }
    return EntityResolver.instance;
  }

  public getRecentEntities(): ResolvedEntity[] {
    return this.recentEntities;
  }

  public registerEntity(entity: ResolvedEntity): void {
    // Deduplicate and place at front
    this.recentEntities = [
      entity,
      ...this.recentEntities.filter((e) => e.name.toLowerCase() !== entity.name.toLowerCase()),
    ].slice(0, 10);
  }

  public findRecentEntityByType(type: ResolvedEntity["type"]): ResolvedEntity | undefined {
    return this.recentEntities.find((e) => e.type === type);
  }

  /**
   * Identifies entities in text, resolves pronouns against short-term entity memory,
   * and yields a resolved semantic text string.
   */
  public resolve(text: string): ResolvedTurnEntities {
    const raw = text.trim();
    const lower = raw.toLowerCase();
    const detectedEntities: ResolvedEntity[] = [];
    let resolvedText = raw;
    let referencedEntity: ResolvedEntity | undefined;

    // 1. Extract Named Person / Contact
    // Examples: "Rahul ke call koro", "call to Anik", "Anik ke message pathao"
    const personMatch = raw.match(
      /(?:call|message|text|phone|ফোন\s+করো|মেসেজ\s+করো|কল\s+করো)\s+([A-Za-z\u0980-\u09FF]+)(?:\s+ke|\s+কে|\s+to)?/i
    );
    if (personMatch && !["youtube", "chrome", "settings", "camera", "website"].includes(personMatch[1].toLowerCase())) {
      const contactName = personMatch[1].replace(/(?:ke|কে)$/i, "").trim();
      const entity: ResolvedEntity = {
        name: contactName,
        type: "contact",
        originalText: personMatch[0],
        confidence: 0.95,
      };
      detectedEntities.push(entity);
      this.registerEntity(entity);
    }

    // 2. Extract App Name
    // Examples: "YouTube", "Chrome", "Settings", "Camera", "WhatsApp", "Spotify"
    const appMatch = raw.match(/\b(youtube|chrome|settings|camera|whatsapp|spotify|calculator|clock|maps|gmail)\b/i);
    if (appMatch) {
      const entity: ResolvedEntity = {
        name: appMatch[1].charAt(0).toUpperCase() + appMatch[1].slice(1).toLowerCase(),
        type: "app",
        originalText: appMatch[0],
        confidence: 0.98,
      };
      detectedEntities.push(entity);
      this.registerEntity(entity);
    }

    // 3. Extract UI Elements (e.g. "button", "search bar", "header", "buttonটা")
    const uiMatch = raw.match(/\b(button|header|nav|card|modal|search\s*bar|বাটন|বটম|বোতাম)(?:টা|টি)?\b/i);
    if (uiMatch) {
      const entity: ResolvedEntity = {
        name: "button",
        type: "ui_element",
        originalText: uiMatch[0],
        confidence: 0.9,
      };
      detectedEntities.push(entity);
      this.registerEntity(entity);
    }

    // 4. Pronoun Resolution: "ওকে", "তাকে", "him", "her", "use", "usko" -> Contact
    const isContactPronoun =
      /\b(?:ওকে|তাকে|তার|him|her|use|usko|unhe)\b/i.test(raw) ||
      raw.includes("ওকে") ||
      raw.includes("তাকে");

    if (isContactPronoun) {
      const lastContact = this.findRecentEntityByType("contact");
      if (lastContact) {
        referencedEntity = lastContact;
        // Replace pronoun in resolvedText for clear AI reasoning
        resolvedText = resolvedText
          .replace(/\bওকে\b/g, `${lastContact.name}-কে`)
          .replace(/\bতাকে\b/g, `${lastContact.name}-কে`)
          .replace(/\bhim\b/gi, lastContact.name)
          .replace(/\bher\b/gi, lastContact.name)
          .replace(/\buse\b/gi, lastContact.name)
          .replace(/\busko\b/gi, lastContact.name);
      }
    }

    // 5. Object / Item Pronoun: "buttonটা", "it", "that", "এটার", "সেটার", "ওটা", "এটা"
    const isObjectPronoun =
      /\b(?:এটার|সেটার|ওটা|এটা|সেটা|it|that|this|iska|uska)\b/i.test(raw) ||
      raw.includes("এটার") ||
      raw.includes("সেটার") ||
      raw.includes("ওটা") ||
      raw.includes("এটা");

    if (isObjectPronoun) {
      const lastApp = this.findRecentEntityByType("app");
      const lastUI = this.findRecentEntityByType("ui_element");
      const lastEntity = lastUI || lastApp;
      if (lastEntity) {
        referencedEntity = lastEntity;
        resolvedText = resolvedText
          .replace(/\bওটা\b/g, `${lastEntity.name}`)
          .replace(/\bএটা\b/g, `${lastEntity.name}`)
          .replace(/\bএটার\b/g, `${lastEntity.name}-এর`)
          .replace(/\bসেটার\b/g, `${lastEntity.name}-এর`);
      }
    }

    return {
      rawText: raw,
      resolvedText,
      entities: detectedEntities,
      referencedEntity,
    };
  }
}

export const entityResolver = EntityResolver.getInstance();
