import {
  ActionVerification,
  StructuredAndroidAction,
  AndroidBridgeStatus,
} from "../types";
import { androidBridge } from "./androidBridge";
import { unifiedContextManager } from "./unifiedContextManager";

export interface AndroidScreenElement {
  id: string;
  text: string;
  type: "button" | "input" | "text" | "image" | "list_item";
  bounds: { x: number; y: number; width: number; height: number };
}

export class AndroidControlEngine {
  private static instance: AndroidControlEngine | null = null;
  private currentPackage: string = "com.google.android.youtube";
  private activeAppName: string = "YouTube";

  private constructor() {}

  public static getInstance(): AndroidControlEngine {
    if (!AndroidControlEngine.instance) {
      AndroidControlEngine.instance = new AndroidControlEngine();
    }
    return AndroidControlEngine.instance;
  }

  public getBridgeStatus(): AndroidBridgeStatus {
    return androidBridge.getStatus();
  }

  public getCurrentPackage(): string {
    return this.currentPackage;
  }

  public getActiveAppName(): string {
    return this.activeAppName;
  }

  /**
   * Executes any StructuredAndroidAction with verification
   */
  public async executeStructuredAction(
    action: StructuredAndroidAction,
    lang: "bn" | "en" | "hi" = "bn"
  ): Promise<ActionVerification> {
    const bridgeResult = await androidBridge.dispatchAction(action);

    // Context tracking on verified actions
    if (bridgeResult.verified) {
      if (action.action === "OPEN_APP") {
        this.activeAppName = action.target || "App";
        this.currentPackage = `com.android.${this.activeAppName.toLowerCase()}`;
        unifiedContextManager.setActiveApp(this.activeAppName);
        unifiedContextManager.setLastAction(`Open ${this.activeAppName}`, {
          package: this.currentPackage,
        });

        const localizedMsg =
          lang === "bn"
            ? `${this.activeAppName} খোলা হয়েছে।`
            : `${this.activeAppName} is open.`;

        return {
          verified: true,
          message: localizedMsg,
          details: bridgeResult.details,
        };
      }

      if (action.action === "CLOSE_APP") {
        const app = action.target || this.activeAppName;
        this.activeAppName = "Home Screen";
        this.currentPackage = "com.android.launcher";
        unifiedContextManager.setActiveApp("Home Screen");
        unifiedContextManager.setLastAction(`Close ${app}`);

        const localizedMsg =
          lang === "bn"
            ? `${app} বন্ধ করা হয়েছে।`
            : `${app} closed.`;

        return {
          verified: true,
          message: localizedMsg,
          details: bridgeResult.details,
        };
      }

      if (action.action === "SCROLL") {
        const dir = action.direction || "DOWN";
        const app = unifiedContextManager.getActiveApp() || this.activeAppName;
        unifiedContextManager.setLastAction(`Scroll ${dir}`, { app, direction: dir });

        const localizedMsg =
          lang === "bn"
            ? `${app}-এ ${dir === "DOWN" ? "নিচে" : "উপরে"} স্ক্রোল করা হলো।`
            : `Scrolled ${dir.toLowerCase()} in ${app}.`;

        return {
          verified: true,
          message: localizedMsg,
          details: bridgeResult.details,
        };
      }

      if (action.action === "NAVIGATE_HOME") {
        this.activeAppName = "Home Screen";
        this.currentPackage = "com.android.launcher";
        unifiedContextManager.setActiveApp("Home Screen");
        unifiedContextManager.setLastAction("Navigate Home");

        const localizedMsg =
          lang === "bn" ? "হোম স্ক্রিনে ফিরে আসা হলো।" : "Returned to Home screen.";

        return {
          verified: true,
          message: localizedMsg,
          details: bridgeResult.details,
        };
      }

      if (action.action === "NAVIGATE_BACK") {
        unifiedContextManager.setLastAction("Navigate Back");
        const localizedMsg = lang === "bn" ? "পেছনে যাওয়া হলো।" : "Navigated back.";
        return {
          verified: true,
          message: localizedMsg,
          details: bridgeResult.details,
        };
      }

      if (action.action === "RECENT_APPS") {
        this.activeAppName = "Recent Apps";
        this.currentPackage = "com.android.systemui.recents";
        unifiedContextManager.setLastAction("Open Recents");
        const localizedMsg =
          lang === "bn" ? "রিসেন্ট অ্যাপস খোলা হয়েছে।" : "Opened recent apps.";
        return {
          verified: true,
          message: localizedMsg,
          details: bridgeResult.details,
        };
      }
    }

    return bridgeResult;
  }

  /**
   * Backward-compatible convenience methods
   */
  public async openApp(appName: string, lang: "bn" | "en" | "hi" = "bn"): Promise<ActionVerification> {
    return this.executeStructuredAction(
      {
        action: "OPEN_APP",
        target: appName,
        appName,
        riskLevel: "LOW",
        confirmation: false,
      },
      lang
    );
  }

  public async closeApp(appName?: string, lang: "bn" | "en" | "hi" = "bn"): Promise<ActionVerification> {
    return this.executeStructuredAction(
      {
        action: "CLOSE_APP",
        target: appName || this.activeAppName,
        appName: appName || this.activeAppName,
        riskLevel: "LOW",
        confirmation: false,
      },
      lang
    );
  }

  public async scroll(
    direction: "up" | "down",
    lang: "bn" | "en" | "hi" = "bn"
  ): Promise<ActionVerification> {
    return this.executeStructuredAction(
      {
        action: "SCROLL",
        direction: direction.toUpperCase() as "UP" | "DOWN",
        riskLevel: "LOW",
        confirmation: false,
      },
      lang
    );
  }

  public async goHome(lang: "bn" | "en" | "hi" = "bn"): Promise<ActionVerification> {
    return this.executeStructuredAction(
      {
        action: "NAVIGATE_HOME",
        riskLevel: "LOW",
        confirmation: false,
      },
      lang
    );
  }

  public async goBack(lang: "bn" | "en" | "hi" = "bn"): Promise<ActionVerification> {
    return this.executeStructuredAction(
      {
        action: "NAVIGATE_BACK",
        riskLevel: "LOW",
        confirmation: false,
      },
      lang
    );
  }

  public async openRecents(lang: "bn" | "en" | "hi" = "bn"): Promise<ActionVerification> {
    return this.executeStructuredAction(
      {
        action: "RECENT_APPS",
        riskLevel: "LOW",
        confirmation: false,
      },
      lang
    );
  }

  public async typeText(text: string): Promise<ActionVerification> {
    return this.executeStructuredAction({
      action: "TYPE_TEXT",
      text,
      riskLevel: "MEDIUM",
      confirmation: false,
    });
  }

  public async tap(target: string): Promise<ActionVerification> {
    return this.executeStructuredAction({
      action: "TAP_ELEMENT",
      target,
      riskLevel: "MEDIUM",
      confirmation: false,
    });
  }

  public async longPress(target: string): Promise<ActionVerification> {
    return this.executeStructuredAction({
      action: "LONG_PRESS",
      target,
      riskLevel: "MEDIUM",
      confirmation: false,
    });
  }

  public async readScreen(): Promise<string> {
    const res = await this.executeStructuredAction({
      action: "READ_ACCESSIBILITY_UI",
      riskLevel: "LOW",
      confirmation: false,
    });
    return res.message;
  }
}

export const androidControlEngine = AndroidControlEngine.getInstance();
