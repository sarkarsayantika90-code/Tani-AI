import { GEMINI_MODELS } from "../config/GeminiConfig";

export type VoiceState = "IDLE" | "CONNECTING" | "LISTENING" | "THINKING" | "SPEAKING" | "ERROR";

export interface VoiceEngineCallbacks {
  onStateChange?: (state: VoiceState) => void;
  onUserTranscript?: (text: string) => void;
  onModelTranscript?: (text: string) => void;
  onAudioLevel?: (level: number) => void;
  onError?: (error: string, code?: string) => void;
  onPermissionDenied?: () => void;
  onTurnComplete?: () => void;
  onSessionEnded?: () => void;
}

export interface VoiceEngineConfig {
  apiKey?: string;
  userName?: string;
  personality?: string;
  language?: string;
  voiceName?: string;
  continuousMode?: boolean;
}

export class VoiceEngine {
  private static instance: VoiceEngine | null = null;

  private state: VoiceState = "IDLE";
  private callbacks: VoiceEngineCallbacks = {};
  private config: VoiceEngineConfig = {};

  // Audio Capture
  private mediaStream: MediaStream | null = null;
  private inputAudioCtx: AudioContext | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private processorNode: ScriptProcessorNode | null = null;

  // Audio Playback
  private playbackAudioCtx: AudioContext | null = null;
  private nextPlaybackTime: number = 0;
  private activeSourceNodes: AudioBufferSourceNode[] = [];
  private isPlayingAudio: boolean = false;

  // WebSocket Connection
  private ws: WebSocket | null = null;
  private isConnecting: boolean = false;
  private isSessionActive: boolean = false;
  private turnEndTimeout: any = null;

  // User speech detector for auto-interruption
  private speechDetectionCount: number = 0;

  private constructor() {}

  public static getInstance(): VoiceEngine {
    if (!VoiceEngine.instance) {
      VoiceEngine.instance = new VoiceEngine();
    }
    return VoiceEngine.instance;
  }

  public setCallbacks(callbacks: VoiceEngineCallbacks) {
    this.callbacks = callbacks;
  }

  public setConfig(config: Partial<VoiceEngineConfig>) {
    this.config = { ...this.config, ...config };
  }

  public getState(): VoiceState {
    return this.state;
  }

  private setState(newState: VoiceState) {
    if (this.state === newState) return;
    this.state = newState;
    this.callbacks.onStateChange?.(newState);
  }

  /**
   * Initializes or resumes playback AudioContext on user gesture
   */
  private getOrCreatePlaybackContext(): AudioContext {
    if (!this.playbackAudioCtx || this.playbackAudioCtx.state === "closed") {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.playbackAudioCtx = new AudioCtxClass();
    }
    if (this.playbackAudioCtx.state === "suspended") {
      this.playbackAudioCtx.resume().catch((e) => {
        console.warn("Could not resume playback AudioContext:", e);
      });
    }
    return this.playbackAudioCtx;
  }

  /**
   * Starts a voice session with Gemini Live
   */
  public async startVoiceSession(configOverride?: Partial<VoiceEngineConfig>): Promise<void> {
    if (configOverride) {
      this.setConfig(configOverride);
    }

    // Prevent duplicate simultaneous session startups
    if (this.isConnecting || this.isSessionActive) {
      if (this.state === "SPEAKING") {
        this.interrupt();
        return;
      }
      return;
    }

    this.isConnecting = true;
    this.setState("CONNECTING");

    try {
      // 1. Prepare Playback AudioContext inside user gesture
      const playbackCtx = this.getOrCreatePlaybackContext();
      if (playbackCtx.state === "suspended") {
        await playbackCtx.resume();
      }

      // 2. Request Microphone Access
      let stream: MediaStream;
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error("Microphone API not supported on this browser.");
        }

        stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            channelCount: 1,
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
      } catch (err: any) {
        this.isConnecting = false;
        this.setState("ERROR");
        if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
          this.callbacks.onPermissionDenied?.();
          this.callbacks.onError?.(
            "Microphone access is blocked. Allow microphone permission and try again.",
            "PERMISSION_DENIED"
          );
        } else if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") {
          this.callbacks.onError?.("No microphone was detected on your device.", "NO_MICROPHONE");
        } else {
          this.callbacks.onError?.(
            "Could not access microphone: " + (err.message || "Unknown error"),
            "MIC_ACCESS_ERROR"
          );
        }
        return;
      }

      this.mediaStream = stream;

      // 3. Connect WebSocket to server Live API bridge
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/api/live`;

      const ws = new WebSocket(wsUrl);
      this.ws = ws;

      ws.onopen = () => {
        // Send initialization payload to establish gemini-3.8-live session
        ws.send(
          JSON.stringify({
            type: "init",
            apiKey: this.config.apiKey,
            userName: this.config.userName || "User",
            personality: this.config.personality || "Assistant",
            language: this.config.language || "auto",
            voiceName: this.config.voiceName || "Aoede",
          })
        );
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.type === "ready" || msg.type === "connected") {
            this.isConnecting = false;
            this.isSessionActive = true;
            this.setState("LISTENING");
            this.startMicrophoneCapture(stream);
          } else if (msg.type === "audio" && msg.audio) {
            // When Tani begins speaking:
            if (this.state !== "SPEAKING") {
              this.setState("SPEAKING");
            }
            this.enqueueAudio(msg.audio);
          } else if (msg.type === "modelTranscript" && msg.text) {
            this.callbacks.onModelTranscript?.(msg.text);
          } else if (msg.type === "userTranscript" && msg.text) {
            this.callbacks.onUserTranscript?.(msg.text);
          } else if (msg.type === "turnComplete") {
            this.handleTurnEnd();
          } else if (msg.type === "interrupted") {
            this.interrupt();
          } else if (msg.type === "error") {
            console.error("Live session server error:", msg.error);
            this.callbacks.onError?.(msg.error || "Voice error occurred.");
            this.setState("ERROR");
          } else if (msg.type === "sessionClosed") {
            this.handleSessionClosed();
          }
        } catch (e) {
          console.warn("Failed to parse Live WS message:", e);
        }
      };

      ws.onerror = (e) => {
        console.error("WebSocket connection error:", e);
        this.isConnecting = false;
        this.setState("ERROR");
        this.callbacks.onError?.(
          "Tani lost the voice connection. Tap retry to reconnect.",
          "CONNECTION_ERROR"
        );
      };

      ws.onclose = () => {
        this.isConnecting = false;
        if (this.isSessionActive) {
          this.handleSessionClosed();
        }
      };
    } catch (err: any) {
      console.error("Failed to start voice session:", err);
      this.isConnecting = false;
      this.setState("ERROR");
      this.callbacks.onError?.(err?.message || "Failed to establish voice session.");
    }
  }

  /**
   * Starts capturing microphone audio, downsampling to 16kHz PCM 16-bit mono, and streaming
   */
  private startMicrophoneCapture(stream: MediaStream) {
    try {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      const inputCtx = new AudioCtxClass();
      this.inputAudioCtx = inputCtx;

      const source = inputCtx.createMediaStreamSource(stream);
      this.sourceNode = source;

      // 4096 samples provides ~90-250ms chunks depending on hardware sample rate
      const processor = inputCtx.createScriptProcessor(4096, 1, 1);
      this.processorNode = processor;

      processor.onaudioprocess = (e) => {
        if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;

        const inputChannel = e.inputBuffer.getChannelData(0);

        // 1. Calculate input audio level for visualizer and interruption detection
        let sumSquares = 0;
        for (let i = 0; i < inputChannel.length; i++) {
          sumSquares += inputChannel[i] * inputChannel[i];
        }
        const rms = Math.sqrt(sumSquares / inputChannel.length);

        // If listening, inform visualizer
        if (this.state === "LISTENING") {
          this.callbacks.onAudioLevel?.(Math.min(1, rms * 5));
        }

        // Interruption Check: If Tani is speaking and user starts speaking loudly enough
        if (this.state === "SPEAKING" && rms > 0.045) {
          this.speechDetectionCount++;
          if (this.speechDetectionCount >= 2) {
            this.speechDetectionCount = 0;
            this.interrupt();
          }
        } else {
          this.speechDetectionCount = 0;
        }

        // 2. Resample to 16kHz
        const resampled = this.resampleTo16k(inputChannel, inputCtx.sampleRate);

        // 3. Convert to 16-bit PCM
        const pcm16 = this.floatTo16BitPCM(resampled);

        // 4. Encode to Base64
        const base64Audio = this.pcm16ToBase64(pcm16);

        // 5. Send realtime input chunk to Gemini
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
          this.ws.send(
            JSON.stringify({
              type: "audio",
              audio: base64Audio,
            })
          );
        }
      };

      source.connect(processor);
      processor.connect(inputCtx.destination);
    } catch (err) {
      console.error("Microphone capture setup failed:", err);
      this.callbacks.onError?.("Audio processing setup failed on this browser.");
    }
  }

  /**
   * Resamples an audio buffer to 16000Hz using linear interpolation
   */
  private resampleTo16k(inputData: Float32Array, inputSampleRate: number): Float32Array {
    if (inputSampleRate === 16000) return inputData;
    const ratio = inputSampleRate / 16000;
    const newLength = Math.round(inputData.length / ratio);
    const result = new Float32Array(newLength);

    for (let i = 0; i < newLength; i++) {
      const origIndex = i * ratio;
      const index1 = Math.floor(origIndex);
      const index2 = Math.min(index1 + 1, inputData.length - 1);
      const frac = origIndex - index1;
      result[i] = inputData[index1] * (1 - frac) + inputData[index2] * frac;
    }
    return result;
  }

  /**
   * Converts Float32Array (-1.0 to 1.0) to Int16Array
   */
  private floatTo16BitPCM(input: Float32Array): Int16Array {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return output;
  }

  /**
   * Encodes Int16Array PCM to base64
   */
  private pcm16ToBase64(int16: Int16Array): string {
    const uint8 = new Uint8Array(int16.buffer, int16.byteOffset, int16.byteLength);
    let binary = "";
    const len = uint8.byteLength;
    const chunkSize = 8192;
    for (let i = 0; i < len; i += chunkSize) {
      const chunk = uint8.subarray(i, Math.min(i + chunkSize, len));
      binary += String.fromCharCode.apply(null, Array.from(chunk));
    }
    return btoa(binary);
  }

  /**
   * Decodes Base64 24kHz PCM from Gemini into Float32Array
   */
  private base64ToFloat32Array(base64: string): Float32Array {
    const binaryStr = atob(base64);
    const len = binaryStr.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryStr.charCodeAt(i);
    }
    const int16 = new Int16Array(bytes.buffer, bytes.byteOffset, bytes.byteLength / 2);
    const float32 = new Float32Array(int16.length);
    for (let i = 0; i < int16.length; i++) {
      float32[i] = int16[i] / 32768.0;
    }
    return float32;
  }

  /**
   * Queues and plays a 24kHz PCM chunk with gapless AudioBufferSourceNode scheduling
   */
  public enqueueAudio(base64PCM: string): void {
    const ctx = this.getOrCreatePlaybackContext();
    const float32 = this.base64ToFloat32Array(base64PCM);
    if (float32.length === 0) return;

    // Output audio level calculation for TaniEnergyRing reactive pulse
    let sumSquares = 0;
    for (let i = 0; i < float32.length; i++) {
      sumSquares += float32[i] * float32[i];
    }
    const rms = Math.sqrt(sumSquares / float32.length);
    this.callbacks.onAudioLevel?.(Math.min(1, rms * 3.5));

    // Create 24kHz buffer - Web Audio automatically handles hardware resampling
    const audioBuffer = ctx.createBuffer(1, float32.length, 24000);
    audioBuffer.getChannelData(0).set(float32);

    const source = ctx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(ctx.destination);

    const now = ctx.currentTime;
    const startTime = Math.max(now, this.nextPlaybackTime);
    source.start(startTime);
    this.nextPlaybackTime = startTime + audioBuffer.duration;
    this.activeSourceNodes.push(source);
    this.isPlayingAudio = true;

    source.onended = () => {
      const idx = this.activeSourceNodes.indexOf(source);
      if (idx !== -1) {
        this.activeSourceNodes.splice(idx, 1);
      }
      if (this.activeSourceNodes.length === 0) {
        this.isPlayingAudio = false;
        this.callbacks.onAudioLevel?.(0);
        this.handleTurnEnd();
      }
    };
  }

  /**
   * Stop active audio playback immediately
   */
  public stopPlayback(): void {
    this.isPlayingAudio = false;
    for (const node of this.activeSourceNodes) {
      try {
        node.stop();
        node.disconnect();
      } catch {
        // ignore
      }
    }
    this.activeSourceNodes = [];
    if (this.playbackAudioCtx) {
      this.nextPlaybackTime = this.playbackAudioCtx.currentTime;
    }
    this.callbacks.onAudioLevel?.(0);
  }

  /**
   * Clears pending queue
   */
  public clearAudioQueue(): void {
    this.stopPlayback();
  }

  /**
   * Interrupts Tani immediately when user speaks or clicks
   */
  public interrupt(): void {
    this.stopPlayback();
    this.clearAudioQueue();

    if (this.state === "SPEAKING") {
      this.setState("LISTENING");
    }

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: "interrupt" }));
    }
  }

  /**
   * Handles completion of Tani's turn
   */
  private handleTurnEnd(): void {
    if (this.activeSourceNodes.length > 0) {
      // Still audio playing out
      return;
    }

    this.callbacks.onTurnComplete?.();

    if (this.config.continuousMode && this.isSessionActive) {
      // Continuous mode active: Return to listening
      this.setState("LISTENING");
    } else {
      // Single turn mode: Return to IDLE
      this.stopVoiceSession();
    }
  }

  /**
   * Graceful close of session
   */
  private handleSessionClosed(): void {
    this.isSessionActive = false;
    this.isConnecting = false;
    this.stopPlayback();
    this.setState("IDLE");
    this.callbacks.onSessionEnded?.();
  }

  /**
   * Stops voice session and cleans up all audio/stream/websocket resources
   */
  public stopVoiceSession(): void {
    this.isConnecting = false;
    this.isSessionActive = false;

    // 1. Stop audio playback
    this.stopPlayback();

    // 2. Stop microphone capture
    if (this.processorNode) {
      try {
        this.processorNode.onaudioprocess = null;
        this.processorNode.disconnect();
      } catch {
        // ignore
      }
      this.processorNode = null;
    }

    if (this.sourceNode) {
      try {
        this.sourceNode.disconnect();
      } catch {
        // ignore
      }
      this.sourceNode = null;
    }

    if (this.mediaStream) {
      try {
        this.mediaStream.getTracks().forEach((track) => track.stop());
      } catch {
        // ignore
      }
      this.mediaStream = null;
    }

    if (this.inputAudioCtx && this.inputAudioCtx.state !== "closed") {
      try {
        this.inputAudioCtx.close();
      } catch {
        // ignore
      }
      this.inputAudioCtx = null;
    }

    // 3. Close WebSocket
    if (this.ws) {
      try {
        if (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING) {
          this.ws.send(JSON.stringify({ type: "close" }));
          this.ws.close();
        }
      } catch {
        // ignore
      }
      this.ws = null;
    }

    this.setState("IDLE");
  }

  /**
   * Reconnects fresh session
   */
  public async reconnect(): Promise<void> {
    this.stopVoiceSession();
    await new Promise((resolve) => setTimeout(resolve, 300));
    await this.startVoiceSession();
  }

  /**
   * Checks whether microphone is available on this browser/environment
   */
  public static isMicrophoneSupported(): boolean {
    return typeof navigator !== "undefined" && Boolean(navigator.mediaDevices?.getUserMedia);
  }
}

export const voiceEngine = VoiceEngine.getInstance();
