import {
  ConversationTurnContext,
  DetectedLanguage,
  ResolvedEntity,
} from "../types";
import { entityResolver } from "./entityResolver";

export interface UnifiedContextState {
  recentTurns: ConversationTurnContext[];
  currentTopic: string | null;
  activeApp: string | null;
  lastAction: string | null;
  lastToolResult: any | null;
  pendingAction: {
    tool: string;
    arguments: Record<string, any>;
    prompt: string;
    description: string;
  } | null;
  currentTaskTitle: string | null;
}

export class UnifiedContextManager {
  private static instance: UnifiedContextManager | null = null;
  private state: UnifiedContextState = {
    recentTurns: [],
    currentTopic: null,
    activeApp: null,
    lastAction: null,
    lastToolResult: null,
    pendingAction: null,
    currentTaskTitle: null,
  };

  private constructor() {}

  public static getInstance(): UnifiedContextManager {
    if (!UnifiedContextManager.instance) {
      UnifiedContextManager.instance = new UnifiedContextManager();
    }
    return UnifiedContextManager.instance;
  }

  public getState(): UnifiedContextState {
    return this.state;
  }

  public recordTurn(turn: {
    modality: "voice" | "text";
    role: "user" | "tani";
    content: string;
    language: DetectedLanguage;
    intent?: string;
  }): void {
    const turnContext: ConversationTurnContext = {
      id: `turn_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      timestamp: Date.now(),
      modality: turn.modality,
      role: turn.role,
      content: turn.content,
      language: turn.language,
      intent: turn.intent,
      activeApp: this.state.activeApp || undefined,
      toolResult: this.state.lastToolResult,
    };

    this.state.recentTurns.push(turnContext);
    if (this.state.recentTurns.length > 15) {
      this.state.recentTurns.shift();
    }
  }

  public setActiveApp(app: string | null): void {
    this.state.activeApp = app;
    if (app) {
      entityResolver.registerEntity({
        name: app,
        type: "app",
        confidence: 1.0,
      });
    }
  }

  public getActiveApp(): string | null {
    return this.state.activeApp;
  }

  public setCurrentTopic(topic: string | null): void {
    this.state.currentTopic = topic;
  }

  public setLastAction(action: string | null, result?: any): void {
    this.state.lastAction = action;
    this.state.lastToolResult = result;
  }

  public getLastAction(): string | null {
    return this.state.lastAction;
  }

  public getLastToolResult(): any | null {
    return this.state.lastToolResult;
  }

  public setPendingAction(action: UnifiedContextState["pendingAction"]): void {
    this.state.pendingAction = action;
  }

  public getPendingAction(): UnifiedContextState["pendingAction"] {
    return this.state.pendingAction;
  }

  public clearPendingAction(): void {
    this.state.pendingAction = null;
  }

  /**
   * Resolves elliptical follow-ups using active context.
   * e.g., "একটা search করো" while activeApp is YouTube -> "YouTube-এ একটা search করো"
   * e.g., "আর একটু নিচে যাও" while activeApp is YouTube -> "YouTube নিচে scroll করো"
   * e.g., "আরো" -> repeats last action (e.g. scroll down)
   * e.g., "ওটা আবার করো" -> repeats last action
   */
  public resolveFollowUpWithContext(text: string): {
    augmentedPrompt: string;
    inferredApp?: string;
    isFollowUp: boolean;
    inferredAction?: string;
  } {
    const raw = text.trim();
    const lower = raw.toLowerCase();

    // 1. Repeat / More: "aro", "aaro", "আরও", "aur"
    if (/^(?:aro|aaro|aaroo|আরও|aur)\s*$/i.test(lower)) {
      if (this.state.lastAction) {
        return {
          augmentedPrompt: `${this.state.lastAction} again in ${this.state.activeApp || "current screen"}`,
          inferredApp: this.state.activeApp || undefined,
          isFollowUp: true,
          inferredAction: this.state.lastAction,
        };
      }
    }

    // 2. Repeat previous action: "ওটা আবার করো", "abar koro", "repeat koro"
    if (
      /(?:ota\s+abar\s+koro|ওটা\s+আবার\s+করো|abar\s+koro|আবার\s+করো|repeat\s+koro|do\s+it\s+again)/i.test(
        lower
      )
    ) {
      if (this.state.lastAction) {
        return {
          augmentedPrompt: `Repeat ${this.state.lastAction} on ${this.state.activeApp || "screen"}`,
          inferredApp: this.state.activeApp || undefined,
          isFollowUp: true,
          inferredAction: this.state.lastAction,
        };
      }
    }

    // 3. Search without specifying app when activeApp exists (e.g. YouTube)
    // User: "Tani YouTube kholo" -> "Opening YouTube."
    // User: "একটা search করো" or "Bengali songs search koro"
    if (
      /(?:search\s+koro|সার্চ\s+করো|search|খুঁজে\s+দাও)/i.test(lower) &&
      !lower.includes("google") &&
      !lower.includes("youtube") &&
      this.state.activeApp
    ) {
      return {
        augmentedPrompt: `${this.state.activeApp}-এ ${raw}`,
        inferredApp: this.state.activeApp,
        isFollowUp: true,
        inferredAction: "SEARCH",
      };
    }

    // 4. Scroll without specifying app when activeApp exists
    // User: "আর একটু নিচে যাও", "উপরে যাও", "scroll koro"
    if (
      /(?:নিচে\s+যাও|উপরে\s+যাও|scroll|স্ক্রোল)/i.test(lower) &&
      this.state.activeApp
    ) {
      return {
        augmentedPrompt: `${this.state.activeApp} অ্যাপে ${raw}`,
        inferredApp: this.state.activeApp,
        isFollowUp: true,
        inferredAction: "SCROLL",
      };
    }

    return {
      augmentedPrompt: raw,
      isFollowUp: false,
    };
  }

  /**
   * Generates a concise context overview for Gemini prompt injection
   */
  public buildContextSummary(): string {
    const lines: string[] = [];
    if (this.state.activeApp) {
      lines.push(`Active Application: ${this.state.activeApp}`);
    }
    if (this.state.currentTopic) {
      lines.push(`Current Topic: ${this.state.currentTopic}`);
    }
    if (this.state.lastAction) {
      lines.push(`Last Action Executed: ${this.state.lastAction}`);
    }
    const recentEntities = entityResolver.getRecentEntities();
    if (recentEntities.length > 0) {
      lines.push(
        `Recent Mentioned Entities: ${recentEntities.map((e) => `${e.name} (${e.type})`).join(", ")}`
      );
    }
    return lines.join("\n");
  }
}

export const unifiedContextManager = UnifiedContextManager.getInstance();
