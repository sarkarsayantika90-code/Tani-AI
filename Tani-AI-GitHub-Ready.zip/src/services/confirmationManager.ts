import { DetectedLanguage } from "../types";

export interface PendingConfirmation {
  id: string;
  actionType: "call" | "message" | "delete" | "system_setting";
  target: string;
  description: string;
  payload: Record<string, any>;
  promptLanguage: DetectedLanguage;
  timestamp: number;
}

export class ConfirmationManager {
  private static instance: ConfirmationManager | null = null;
  private pending: PendingConfirmation | null = null;

  private constructor() {}

  public static getInstance(): ConfirmationManager {
    if (!ConfirmationManager.instance) {
      ConfirmationManager.instance = new ConfirmationManager();
    }
    return ConfirmationManager.instance;
  }

  public setPendingConfirmation(item: PendingConfirmation): void {
    this.pending = item;
  }

  public getPendingConfirmation(): PendingConfirmation | null {
    return this.pending;
  }

  public clearPending(): void {
    this.pending = null;
  }

  /**
   * Generates a natural, polite confirmation inquiry matching the user's language
   */
  public generateConfirmationQuestion(actionType: string, target: string, lang: DetectedLanguage): string {
    switch (lang) {
      case "bn":
      case "bn-en":
        if (actionType === "call") {
          return `আমি কি ${target}-কে call করব?`;
        }
        if (actionType === "message") {
          return `আমি কি ${target}-কে মেসেজটি পাঠাব?`;
        }
        if (actionType === "delete") {
          return `আপনি কি নিশ্চিত যে এটি মুছে ফেলতে চান?`;
        }
        return `আপনি কি নিশ্চিত যে এটি সম্পাদন করতে চান?`;

      case "hi":
      case "hi-en":
        if (actionType === "call") {
          return `क्या मैं ${target} को कॉल करूँ?`;
        }
        if (actionType === "message") {
          return `क्या मैं ${target} को मैसेज भेज दूँ?`;
        }
        return `क्या आप इसे आगे बढ़ाना चाहते हैं?`;

      case "en":
      default:
        if (actionType === "call") {
          return `Should I place a call to ${target}?`;
        }
        if (actionType === "message") {
          return `Should I send this message to ${target}?`;
        }
        if (actionType === "delete") {
          return `Are you sure you want to delete this item?`;
        }
        return `Would you like me to proceed with this action?`;
    }
  }

  /**
   * Evaluates if user's reply is an affirmative confirmation or rejection
   */
  public evaluateUserResponse(text: string): "CONFIRMED" | "REJECTED" | "NEUTRAL" {
    const raw = text.toLowerCase().trim();
    const compact = raw.replace(/[^a-zA-Z\u0980-\u09FF\u0900-\u097F]/g, "");

    const affirmativePatterns = [
      "হ্যাঁ", "হাঁ", "করো", "কর", "কলকরো", "পাঠাও", "পাঠিয়েদাও", "হ্যাঁকরো", "ঠিকআছে", "হ্যাঁকর",
      "yes", "yeah", "yep", "doit", "call", "sure", "ok", "okay", "proceed", "sendit",
      "haan", "karo", "kar", "bhejdo", "haando", "theekhai", "kardo"
    ];

    const rejectionPatterns = [
      "না", "করোনা", "থাক", "ক্যানসেল", "বাতিল", "দরকারনেই",
      "no", "nope", "dont", "cancel", "stop", "abort", "nevermind",
      "nahi", "matkaro", "rehnado", "rukja"
    ];

    if (affirmativePatterns.some((p) => compact.includes(p) || raw.includes(p))) {
      return "CONFIRMED";
    }

    if (rejectionPatterns.some((p) => compact.includes(p) || raw.includes(p))) {
      return "REJECTED";
    }

    return "NEUTRAL";
  }
}

export const confirmationManager = ConfirmationManager.getInstance();
