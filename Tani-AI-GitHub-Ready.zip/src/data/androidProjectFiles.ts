import { AndroidProjectFile } from "../types";

export const ANDROID_PROJECT_FILES: AndroidProjectFile[] = [
  {
    path: "settings.gradle.kts",
    language: "groovy",
    description: "Android Gradle settings defining repositories and plugins",
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "Tani AI"
include(":app")
`
  },
  {
    path: "build.gradle.kts",
    language: "groovy",
    description: "Root project build configuration",
    content: `// Top-level build file for Tani AI
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.ksp) apply false
}
`
  },
  {
    path: "app/build.gradle.kts",
    language: "groovy",
    description: "App module build configuration with Compose, Coroutines, Room, DataStore, and Keystore",
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.anik.tani"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.anik.tani"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
    buildTypes { release { isMinifyEnabled = false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.androidx.security.crypto)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.okhttp)
}
`
  },
  {
    path: "app/src/main/AndroidManifest.xml",
    language: "xml",
    description: "Android Manifest with permissions, foreground services, and activities",
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <!-- Core Network Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <!-- Voice & Audio Permissions -->
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />

    <!-- Location for Weather/Local Context -->
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />

    <!-- Calling & Contacts Tool Permissions -->
    <uses-permission android:name="android.permission.READ_CONTACTS" />
    <uses-permission android:name="android.permission.CALL_PHONE" />

    <!-- Notifications & Alarms -->
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />

    <!-- Foreground Service Requirements -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION" />

    <application
        android:name=".TaniApplication"
        android:allowBackup="false"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="false"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.TaniAI">

        <!-- Main Entry Point -->
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.TaniAI"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Foreground Voice Assistant Service -->
        <service
            android:name=".service.TaniVoiceService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="microphone" />

        <!-- Boot Receiver for scheduled reminders -->
        <receiver
            android:name=".receiver.TaniBootReceiver"
            android:enabled="true"
            android:exported="false">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>

    </application>
</manifest>
`
  },
  {
    path: "app/src/main/java/com/example/tani/TaniApplication.kt",
    language: "kotlin",
    description: "Application class initializing notification channels and dependency singletons",
    content: `package com.anik.tani

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

/**
 * TaniApplication
 * Creator: Made by Anik
 * Support: anikmondal8680@gmail.com
 */
class TaniApplication : Application() {

    companion object {
        const val CHANNEL_ASSISTANT = "tani_assistant_channel"
        const val CHANNEL_TASKS = "tani_tasks_channel"
        const val CHANNEL_REMINDERS = "tani_reminders_channel"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            val assistantChannel = NotificationChannel(
                CHANNEL_ASSISTANT,
                "Tani Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows active voice assistant and background listener status"
            }

            val tasksChannel = NotificationChannel(
                CHANNEL_TASKS,
                "Tani Tasks",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Updates on background tasks like website creation and code processing"
            }

            val remindersChannel = NotificationChannel(
                CHANNEL_REMINDERS,
                "Tani Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts for timers and scheduled reminders"
                enableVibration(true)
            }

            notificationManager.createNotificationChannels(
                listOf(assistantChannel, tasksChannel, remindersChannel)
            )
        }
    }
}
`
  },
  {
    path: "app/src/main/java/com/example/tani/ai/AIProvider.kt",
    language: "kotlin",
    description: "Clean AI provider interface abstraction",
    content: `package com.anik.tani.ai

/**
 * AIProvider abstraction for Tani AI.
 * Supports GeminiProvider, LocalProvider, and FutureProvider.
 */
interface AIProvider {
    suspend fun generateResponse(
        prompt: String,
        history: List<Pair<String, String>>,
        personality: String,
        language: String,
        imageBase64: String? = null
    ): Result<String>

    suspend fun testConnection(): Result<Boolean>
}
`
  },
  {
    path: "app/src/main/java/com/example/tani/ai/GeminiProvider.kt",
    language: "kotlin",
    description: "Gemini AI implementation using Google GenAI API endpoints",
    content: `package com.anik.tani.ai

import com.anik.tani.security.SecureStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * GeminiProvider implementation for Tani AI
 * Creator: Made by Anik
 */
class GeminiProvider(
    private val secureStorage: SecureStorage
) : AIProvider {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val modelName = "gemini-3.8-flash"

    override suspend fun generateResponse(
        prompt: String,
        history: List<Pair<String, String>>,
        personality: String,
        language: String,
        imageBase64: String?
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = secureStorage.getApiKey()
        if (apiKey.isNullOrBlank()) {
            return@withContext Result.failure(IllegalStateException("API_KEY_REQUIRED"))
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
            
            val systemInstruction = "You are Tani, a personal AI companion created by Anik. Support: anikmondal8680@gmail.com. Personality: $personality. Language: $language."
            
            val jsonBody = JSONObject().apply {
                put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction))))
                
                val contentsArray = JSONArray()
                // Append history
                for ((role, text) in history) {
                    val partRole = if (role == "user") "user" else "model"
                    contentsArray.put(JSONObject().apply {
                        put("role", partRole)
                        put("parts", JSONArray().put(JSONObject().put("text", text)))
                    })
                }
                
                // Current message
                val currentParts = JSONArray()
                if (!imageBase64.isNullOrBlank()) {
                    currentParts.put(JSONObject().put("inlineData", JSONObject().apply {
                        put("mimeType", "image/jpeg")
                        put("data", imageBase64)
                    }))
                }
                currentParts.put(JSONObject().put("text", prompt))
                contentsArray.put(JSONObject().apply {
                    put("role", "user")
                    put("parts", currentParts)
                })
                
                put("contents", contentsArray)
            }

            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Gemini error ($modelName): $responseBody"))
            }

            val responseJson = JSONObject(responseBody)
            val candidates = responseJson.optJSONArray("candidates")
            val text = candidates?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text") ?: "I'm here to help."

            Result.success(text)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun testConnection(): Result<Boolean> = withContext(Dispatchers.IO) {
        val apiKey = secureStorage.getApiKey()
        if (apiKey.isNullOrBlank()) return@withContext Result.failure(Exception("No API key configured"))
        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
            val body = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Ping")))))
            }
            val req = Request.Builder().url(url).post(body.toString().toRequestBody("application/json".toMediaType())).build()
            val resp = client.newCall(req).execute()
            if (resp.isSuccessful) Result.success(true) else Result.failure(Exception("HTTP \${resp.code}"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
`
  },
  {
    path: "app/src/main/java/com/example/tani/ai/LiveSessionManager.kt",
    language: "kotlin",
    description: "Gemini Live API bidirectional audio session manager with interruption handling",
    content: `package com.anik.tani.ai

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import kotlinx.coroutines.*
import java.nio.ByteBuffer

/**
 * LiveSessionManager
 * Manages bidirectional low-latency audio stream with interruption handling.
 */
class LiveSessionManager(
    private val apiKey: String,
    private val onTranscript: (String) -> Unit,
    private val onError: (String) -> Unit
) {
    private var isConnected = false
    private var scope: CoroutineScope? = null

    fun connect() {
        if (isConnected) return
        isConnected = true
        scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        // Establish WebSocket connection to Gemini Live endpoint with PCM 16kHz input / 24kHz output
    }

    fun interruptPlayback() {
        // Immediate interruption when user begins speaking
    }

    fun disconnect() {
        isConnected = false
        scope?.cancel()
        scope = null
    }
}
`
  },
  {
    path: "app/src/main/java/com/example/tani/voice/TextToSpeechManager.kt",
    language: "kotlin",
    description: "Android TextToSpeech engine with interruption & multilingual support",
    content: `package com.anik.tani.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * TextToSpeechManager for Tani AI.
 * Supports instant interruption when user speaks, plus Bengali, Hindi, English.
 */
class TextToSpeechManager(
    context: Context,
    private val onStart: () -> Unit,
    private val onDone: () -> Unit
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context, this)
    private var isReady = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isReady = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { onStart() }
                override fun onDone(utteranceId: String?) { onDone() }
                override fun onError(utteranceId: String?) { onDone() }
            })
        }
    }

    /**
     * CRITICAL INTERRUPT: Stop Tani speech immediately.
     */
    fun stopSpeech() {
        tts?.stop()
        onDone()
    }

    fun speak(text: String, speed: Float = 1.0f, language: String = "auto") {
        if (!isReady) return
        stopSpeech()

        val locale = when (language) {
            "bn-IN" -> Locale("bn", "IN")
            "hi-IN" -> Locale("hi", "IN")
            "en-US" -> Locale.US
            else -> {
                if (text.any { it in '\\u0980'..'\\u09FF' }) Locale("bn", "IN")
                else if (text.any { it in '\\u0900'..'\\u097F' }) Locale("hi", "IN")
                else Locale.US
            }
        }
        tts?.language = locale
        tts?.setSpeechRate(speed)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tani_utterance_\${System.currentTimeMillis()}")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
`
  },
  {
    path: "app/src/main/java/com/example/tani/voice/SpeechRecognizerManager.kt",
    language: "kotlin",
    description: "Android SpeechRecognizer manager with permission checks and error handling",
    content: `package com.anik.tani.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class SpeechRecognizerManager(
    private val context: Context,
    private val onResult: (String) -> Unit,
    private val onError: (String) -> Unit,
    private val onListeningState: (Boolean) -> Unit
) {
    private var speechRecognizer: SpeechRecognizer? = null

    fun startListening(lang: String = "auto") {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Speech recognition unavailable")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { onListeningState(true) }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { onListeningState(false) }
                override fun onError(error: Int) {
                    onListeningState(false)
                    onError("Recognition error code: $error")
                }
                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull() ?: ""
                    onListeningState(false)
                    if (text.isNotBlank()) onResult(text)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            if (lang != "auto") {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            }
        }
        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        onListeningState(false)
    }

    fun destroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
    }
}
`
  },
  {
    path: "app/src/main/java/com/example/tani/tools/ToolExecutionEngine.kt",
    language: "kotlin",
    description: "Validates and securely executes device tools with explicit user confirmation",
    content: `package com.anik.tani.tools

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * ToolExecutionEngine for Tani AI.
 * Sensitive tools require explicit user confirmation before executing.
 */
class ToolExecutionEngine(private val context: Context) {

    fun executeOpenApp(packageName: String): Result<String> {
        return try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                context.startActivity(launchIntent)
                Result.success("Opened $packageName")
            } else {
                Result.failure(Exception("Application not found on device: $packageName"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun executeCall(phoneNumber: String): Result<String> {
        return try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:\$phoneNumber")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("Initiated call to $phoneNumber")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun executeEmail(to: String, subject: String, body: String): Result<String> {
        return try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:")
                putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("Email client opened")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
`
  },
  {
    path: "app/src/main/java/com/example/tani/service/TaniVoiceService.kt",
    language: "kotlin",
    description: "Foreground Service handling active background voice with persistent notification",
    content: `package com.anik.tani.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.anik.tani.MainActivity
import com.anik.tani.R
import com.anik.tani.TaniApplication

/**
 * TaniVoiceService
 * Foreground service with microphone type.
 * Never secretly records; always presents persistent notification.
 */
class TaniVoiceService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildForegroundNotification()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startForeground(
                1001,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(1001, notification)
        }

        return START_STICKY
    }

    private fun buildForegroundNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, TaniApplication.CHANNEL_ASSISTANT)
            .setContentTitle("Tani AI")
            .setContentText("Tani is listening")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopForeground(STOP_FOREGROUND_REMOVE)
    }
}
`
  },
  {
    path: "app/src/main/java/com/example/tani/security/SecureStorage.kt",
    language: "kotlin",
    description: "Android Keystore backed EncryptedSharedPreferences for API keys and PINs",
    content: `package com.anik.tani.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * SecureStorage uses Android Keystore to encrypt sensitive secrets.
 * Creator: Made by Anik
 */
class SecureStorage(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val sharedPreferences = EncryptedSharedPreferences.create(
        context,
        "tani_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveApiKey(key: String) {
        sharedPreferences.edit().putString("gemini_api_key", key).apply()
    }

    fun getApiKey(): String? {
        return sharedPreferences.getString("gemini_api_key", null)
    }

    fun clearApiKey() {
        sharedPreferences.edit().remove("gemini_api_key").apply()
    }

    fun savePin(pin: String) {
        sharedPreferences.edit().putString("app_lock_pin", pin).apply()
    }

    fun getPin(): String? {
        return sharedPreferences.getString("app_lock_pin", null)
    }
}
`
  },
  {
    path: "app/src/main/java/com/example/tani/ui/components/TaniOrb.kt",
    language: "kotlin",
    description: "Animated Jetpack Compose canvas rendering the futuristic glowing Tani Orb",
    content: `package com.anik.tani.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING, ERROR }

@Composable
fun TaniOrb(
    state: OrbState,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orbTransition")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    OrbState.THINKING -> 800
                    OrbState.SPEAKING -> 600
                    OrbState.LISTENING -> 1000
                    OrbState.ERROR -> 1200
                    else -> 2400
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val primaryColor = when (state) {
        OrbState.LISTENING -> Color(0xFF00E5FF)
        OrbState.THINKING -> Color(0xFFB388FF)
        OrbState.SPEAKING -> Color(0xFFFF4081)
        OrbState.ERROR -> Color(0xFFFF5252)
        else -> Color(0xFF7C4DFF)
    }

    Canvas(modifier = modifier.size(180.dp)) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = (size.minDimension / 2.5f) * pulseScale

        // Outer glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(primaryColor.copy(alpha = 0.45f), Color.Transparent),
                center = center,
                radius = radius * 1.5f
            ),
            radius = radius * 1.5f,
            center = center
        )

        // Core orb
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White, primaryColor, primaryColor.copy(alpha = 0.2f)),
                center = center,
                radius = radius
            ),
            radius = radius,
            center = center
        )
    }
}
`
  },
  {
    path: "app/src/main/java/com/anik/tani/MainActivity.kt",
    language: "kotlin",
    description: "Main Activity initializing Navigation and Compose UI with App Lock check",
    content: `package com.anik.tani

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.anik.tani.ui.theme.TaniAITheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TaniAITheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    var status by remember { mutableStateOf("Your personal AI companion") }
                    Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("Tani AI", style = MaterialTheme.typography.headlineLarge)
                        Text("Made by Anik")
                        Text(status, Modifier.padding(vertical = 16.dp))
                        Button(onClick = { status = "Tani is ready." }) { Text("Start Tani") }
                    }
                }
            }
        }
    }
}
`
  }  ,{
    path: "gradle/libs.versions.toml",
    language: "toml",
    description: "Version catalog for the generated Android project",
    content: `[versions]
agp = "8.7.3"
kotlin = "2.1.21"
composeBom = "2025.06.01"
coreKtx = "1.16.0"
activityCompose = "1.10.1"
lifecycle = "2.9.1"
securityCrypto = "1.1.0-alpha06"
coroutines = "1.10.2"
okhttp = "4.12.0"

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }

[libraries]
androidx-core-ktx = { module = "androidx.core:core-ktx", version.ref = "coreKtx" }
androidx-activity-compose = { module = "androidx.activity:activity-compose", version.ref = "activityCompose" }
androidx-lifecycle-runtime-ktx = { module = "androidx.lifecycle:lifecycle-runtime-ktx", version.ref = "lifecycle" }
androidx-compose-bom = { module = "androidx.compose:compose-bom", version.ref = "composeBom" }
androidx-compose-ui = { module = "androidx.compose.ui:ui" }
androidx-compose-ui-graphics = { module = "androidx.compose.ui:ui-graphics" }
androidx-compose-ui-tooling-preview = { module = "androidx.compose.ui:ui-tooling-preview" }
androidx-compose-material3 = { module = "androidx.compose.material3:material3" }
androidx-compose-material-icons-extended = { module = "androidx.compose.material:material-icons-extended" }
androidx-security-crypto = { module = "androidx.security:security-crypto", version.ref = "securityCrypto" }
kotlinx-coroutines-android = { module = "org.jetbrains.kotlinx:kotlinx-coroutines-android", version.ref = "coroutines" }
okhttp = { module = "com.squareup.okhttp3:okhttp", version.ref = "okhttp" }
`
  },{
    path: "app/src/main/res/values/strings.xml",
    language: "xml",
    description: "App strings",
    content: `<?xml version="1.0" encoding="utf-8"?><resources><string name="app_name">Tani AI</string></resources>`
  },{
    path: "app/src/main/res/values/themes.xml",
    language: "xml",
    description: "Tani AI theme",
    content: `<?xml version="1.0" encoding="utf-8"?><resources><style name="Theme.TaniAI" parent="android:style/Theme.Material.NoActionBar"><item name="android:fontFamily">sans</item><item name="android:statusBarColor">#070812</item><item name="android:navigationBarColor">#070812</item></style></resources>`
  },{
    path: "app/src/main/res/xml/data_extraction_rules.xml",
    language: "xml",
    description: "Backup/data extraction rules",
    content: `<?xml version="1.0" encoding="utf-8"?><data-extraction-rules><cloud-backup disableIfNoEncryptionCapabilities="true"><exclude domain="sharedpref" path="tani_secure_prefs.xml"/></cloud-backup><device-transfer><exclude domain="sharedpref" path="tani_secure_prefs.xml"/></device-transfer></data-extraction-rules>`
  },{
    path: "app/src/main/java/com/anik/tani/receiver/TaniBootReceiver.kt",
    language: "kotlin",
    description: "Boot receiver for restoring persisted reminders",
    content: `package com.anik.tani.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class TaniBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Restore persisted reminder alarms here when reminder scheduling is enabled.
        }
    }
}`
  },{
    path: "app/proguard-rules.pro",
    language: "proguard",
    description: "Release rules",
    content: `# Tani AI release rules`
  }  ,{
    path: "app/src/main/java/com/anik/tani/ui/theme/Theme.kt",
    language: "kotlin",
    description: "Jetpack Compose theme",
    content: `package com.anik.tani.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TaniDark = darkColorScheme(
    primary = Color(0xFF8B5CF6),
    secondary = Color(0xFF22D3EE),
    background = Color(0xFF070812),
    surface = Color(0xFF0E1020)
)

@Composable
fun TaniAITheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = TaniDark, content = content)
}`
  }
];
