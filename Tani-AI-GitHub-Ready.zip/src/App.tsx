import React, { useState, useEffect, useRef } from "react";
import {
  OrbState,
  UserPreferences,
  Conversation,
  Message,
  BackgroundTask,
  ReminderItem,
  ConfirmationState,
  ProactiveAlert,
} from "./types";
import { StorageService } from "./services/storageService";
import { voiceManager } from "./services/voiceService";
import { TaniBrain } from "./services/taniBrain";

import { LoadingScreen } from "./components/LoadingScreen";
import { OnboardingScreen } from "./components/OnboardingScreen";
import { AppLockScreen } from "./components/AppLockScreen";
import { HomeView } from "./components/HomeView";
import { ChatView } from "./components/ChatView";
import { TasksView } from "./components/TasksView";
import { HistoryView } from "./components/HistoryView";
import { SettingsView } from "./components/SettingsView";
import { PermissionsView } from "./components/PermissionsView";
import { ConfirmationDialog } from "./components/ConfirmationDialog";
import { AboutModal } from "./components/AboutModal";
import { AndroidCodeModal } from "./components/AndroidCodeModal";

import { MenuDrawer } from "./components/MenuDrawer";
import { AlertsModal } from "./components/AlertsModal";
import { ProfileModal } from "./components/ProfileModal";
import { MemoryModal } from "./components/MemoryModal";
import { AmbientGlow } from "./components/AmbientGlow";
import { FloatingAssistant } from "./components/FloatingAssistant";
import { TaniBrainStatusPanel } from "./components/TaniBrainStatusPanel";

import {
  Home,
  MessageSquare,
  Activity,
  History as HistoryIcon,
  Settings,
} from "lucide-react";

export default function App() {
  // App Lifecycle States
  const [isLoadingApp, setIsLoadingApp] = useState(true);
  const [preferences, setPreferences] = useState<UserPreferences>(() =>
    StorageService.getPreferences()
  );
  const [isLocked, setIsLocked] = useState<boolean>(() => {
    const prefs = StorageService.getPreferences();
    return !!(prefs.appLockEnabled && prefs.pinCode);
  });

  // Navigation Tabs: 'home' | 'chat' | 'tasks' | 'history' | 'settings' | 'permissions'
  const [currentTab, setCurrentTab] = useState<
    "home" | "chat" | "tasks" | "history" | "settings" | "permissions"
  >("home");

  // Visualizer & AI State
  const [orbState, setOrbState] = useState<OrbState>("idle");
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [liveTranscript, setLiveTranscript] = useState<{ user?: string; tani?: string }>({});
  const [permissionDenied, setPermissionDenied] = useState<boolean>(false);

  // Conversations & Messages
  const [conversations, setConversations] = useState<Conversation[]>(() =>
    StorageService.getConversations()
  );
  const [activeConversationId, setActiveConversationId] = useState<string | null>(() => {
    const list = StorageService.getConversations();
    return list.length > 0 ? list[0].id : null;
  });

  // Background Tasks & Proactive Alerts
  const [tasks, setTasks] = useState<BackgroundTask[]>(() => StorageService.getTasks());
  const [alerts, setAlerts] = useState<ProactiveAlert[]>(() => StorageService.getAlerts());
  const [memories, setMemories] = useState<string[]>(() => StorageService.getMemoryNotes());

  // Active Timer state
  const [activeTimerSeconds, setActiveTimerSeconds] = useState<number | null>(null);

  // Modals
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAlertsOpen, setIsAlertsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isMemoryOpen, setIsMemoryOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isAndroidCodeOpen, setIsAndroidCodeOpen] = useState(false);
  const [confirmation, setConfirmation] = useState<ConfirmationState>({ isOpen: false });

  const continuousSilenceTimerRef = useRef<any>(null);

  // Current active conversation
  const activeConversation = conversations.find((c) => c.id === activeConversationId);
  const messages = activeConversation?.messages || [];

  // Continuous silence timeout handler
  const handleContinuousSilenceTimeout = () => {
    voiceManager.stopListening();
    setOrbState("idle");
  };

  // Voice Callbacks Setup
  useEffect(() => {
    voiceManager.setCallbacks({
      onListeningStart: () => {
        if (continuousSilenceTimerRef.current) {
          clearTimeout(continuousSilenceTimerRef.current);
          continuousSilenceTimerRef.current = null;
        }
        setLiveTranscript({});
        setOrbState("listening");
      },
      onListeningEnd: () => {
        setOrbState((prev) => (prev === "listening" ? "idle" : prev));
      },
      onSpeakingStart: () => {
        if (continuousSilenceTimerRef.current) {
          clearTimeout(continuousSilenceTimerRef.current);
          continuousSilenceTimerRef.current = null;
        }
        setOrbState("speaking");
      },
      onSpeakingEnd: () => {
        setOrbState("idle");
        // Clear live transcript after 5 seconds if idle
        setTimeout(() => {
          setLiveTranscript({});
        }, 5000);
      },
      onSpeechResult: (transcript) => {
        if (continuousSilenceTimerRef.current) {
          clearTimeout(continuousSilenceTimerRef.current);
          continuousSilenceTimerRef.current = null;
        }
        if (transcript.trim()) {
          setLiveTranscript((prev) => ({ ...prev, user: transcript.trim() }));
          // If in text fallback, handle message
          if (!voiceManager.isLiveActive()) {
            handleSendMessage(transcript.trim());
          }
        }
      },
      onModelTranscript: (taniText) => {
        setLiveTranscript((prev) => ({
          ...prev,
          tani: (prev.tani || "") + taniText,
        }));
      },
      onAudioLevel: (lvl) => {
        setAudioLevel(lvl);
      },
      onPermissionDenied: () => {
        setPermissionDenied(true);
        setOrbState("idle");
      },
      onError: (err) => {
        console.warn("Voice notice:", err);
        setOrbState("error");
        setErrorMessage(err || "Tani voice session encountered an issue.");
      },
    });
  }, [preferences, conversations, activeConversationId]);

  // Active Timer interval
  useEffect(() => {
    if (activeTimerSeconds === null || activeTimerSeconds <= 0) return;

    const timer = setInterval(() => {
      setActiveTimerSeconds((prev) => {
        if (prev === null || prev <= 1) {
          clearInterval(timer);
          // Timer finished: Proactive notification
          const finishedAlert: ProactiveAlert = {
            id: `alert_timer_${Date.now()}`,
            title: "Timer Finished",
            message: "Your scheduled timer has completed.",
            timestamp: Date.now(),
            type: "timer",
            read: false,
          };
          const updatedAlerts = [finishedAlert, ...StorageService.getAlerts()].slice(0, 20);
          StorageService.saveAlerts(updatedAlerts);
          setAlerts(updatedAlerts);

          if (preferences.proactiveAssistant && preferences.voiceEnabled) {
            voiceManager.speak("Your timer has finished.", preferences.voiceSpeed);
          }
          return null;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [activeTimerSeconds, preferences]);

  // Sync Preferences to LocalStorage
  const handleUpdatePreferences = (updated: Partial<UserPreferences>) => {
    setPreferences((prev) => {
      const next = { ...prev, ...updated };
      StorageService.savePreferences(next);
      return next;
    });
  };

  // Helper to ensure active conversation exists
  const getOrCreateActiveConversation = (): Conversation => {
    if (activeConversationId) {
      const existing = conversations.find((c) => c.id === activeConversationId);
      if (existing) return existing;
    }
    const newConv: Conversation = {
      id: `conv_${Date.now()}`,
      title: "New Conversation",
      lastMessage: "",
      timestamp: Date.now(),
      messages: [],
    };
    const updated = [newConv, ...conversations];
    setConversations(updated);
    StorageService.saveConversations(updated);
    setActiveConversationId(newConv.id);
    return newConv;
  };

  // Create New Conversation
  const handleCreateNewChat = () => {
    const newConv: Conversation = {
      id: `conv_${Date.now()}`,
      title: "New Conversation",
      lastMessage: "",
      timestamp: Date.now(),
      messages: [],
    };
    const updated = [newConv, ...conversations];
    setConversations(updated);
    StorageService.saveConversations(updated);
    setActiveConversationId(newConv.id);
    setCurrentTab("chat");
  };

  // Handle User Message Sending
  const handleSendMessage = async (
    text: string,
    image?: { data: string; mimeType: string }
  ) => {
    if (!text.trim() && !image) return;

    // Critical Interruptibility: Stop Tani speaking immediately upon user interaction
    voiceManager.stopSpeaking();
    voiceManager.stopListening();
    setErrorMessage(null);

    const conv = getOrCreateActiveConversation();
    const userMsgId = `msg_user_${Date.now()}`;
    const userMessage: Message = {
      id: userMsgId,
      role: "user",
      content: text,
      timestamp: Date.now(),
      image: image ? `data:${image.mimeType};base64,${image.data}` : undefined,
    };

    const updatedMessages = [...conv.messages, userMessage];
    const newTitle =
      conv.messages.length === 0 ? text.slice(0, 30) || "Conversation" : conv.title;

    const updatedConv: Conversation = {
      ...conv,
      title: newTitle,
      lastMessage: text,
      timestamp: Date.now(),
      messages: updatedMessages,
    };

    const newConversations = conversations.map((c) =>
      c.id === updatedConv.id ? updatedConv : c
    );
    if (!conversations.some((c) => c.id === updatedConv.id)) {
      newConversations.unshift(updatedConv);
    }
    setConversations(newConversations);
    StorageService.saveConversations(newConversations);

    // Update Context Manager
    TaniBrain.contextManager.updateHistory(updatedMessages);

    // Set UI State to Thinking
    setOrbState("thinking");
    setIsAiProcessing(true);

    try {
      const result = await TaniBrain.processUserInput({
        prompt: text,
        userName: preferences.userName,
        personality: preferences.personality,
        image,
        apiKey: preferences.hasCustomApiKey ? preferences.apiKey : undefined,
      });

      // If sensitive tool detected, open confirmation dialog
      if (result.intent.isSensitive) {
        handleSensitiveConfirmation(result.intent.type, result.intent.parameters);
      }

      // Check if a timer command was given
      if (result.intent.type === "timer") {
        const secs = result.intent.parameters.durationSeconds || 300;
        setActiveTimerSeconds(secs);
      }

      // Build Tani assistant response message
      const taniMsgId = `msg_tani_${Date.now()}`;
      const taniMessage: Message = {
        id: taniMsgId,
        role: "tani",
        content: result.text,
        timestamp: Date.now(),
        codeBlocks: result.codeBlocks,
        toolCall: result.detectedTool
          ? {
              name: result.detectedTool.name,
              arguments: result.detectedTool.arguments,
              status: "executed",
            }
          : undefined,
        confirmationAction: result.confirmationAction,
      };

      const finalMessages = [...updatedMessages, taniMessage];
      const finalConv: Conversation = {
        ...updatedConv,
        lastMessage: result.text.slice(0, 60),
        timestamp: Date.now(),
        messages: finalMessages,
      };

      const finalConversations = newConversations.map((c) =>
        c.id === finalConv.id ? finalConv : c
      );
      setConversations(finalConversations);
      StorageService.saveConversations(finalConversations);

      setOrbState("idle");
      setIsAiProcessing(false);

      // Refresh tasks and alerts
      setTasks(StorageService.getTasks());
      setAlerts(StorageService.getAlerts());

      // Proactive TTS speech
      if (preferences.voiceEnabled && preferences.autoSpeak) {
        voiceManager.speak(result.spokenText || result.text, preferences.voiceSpeed, () => {
          setOrbState("idle");
        });
      }
    } catch (error: any) {
      console.error("AI Request Encountered Error:", error);
      setOrbState("error");
      setIsAiProcessing(false);

      const rawErr = error?.message || "Connection error";
      setErrorMessage(rawErr);

      const errorMsg: Message = {
        id: `msg_err_${Date.now()}`,
        role: "tani",
        content:
          rawErr.includes("API key") || rawErr.includes("403")
            ? "AI connection needs attention. Please verify your API key in Settings."
            : rawErr.includes("quota") || rawErr.includes("rate limit") || rawErr.includes("429") || rawErr.includes("resource_exhausted")
            ? "AI request quota reached for the moment. Please wait a few seconds and try again."
            : rawErr.includes("offline") || rawErr.includes("network")
            ? "You're currently offline. Please check your internet connection."
            : rawErr.includes("high demand") || rawErr.includes("503")
            ? "Tani AI is currently experiencing high demand. Please try again shortly."
            : "Tani couldn't connect right now. Tap retry or check your network.",
        timestamp: Date.now(),
        isError: true,
      };

      const finalMessages = [...updatedMessages, errorMsg];
      const finalConv: Conversation = {
        ...updatedConv,
        lastMessage: "Error processing request",
        timestamp: Date.now(),
        messages: finalMessages,
      };

      const finalConversations = newConversations.map((c) =>
        c.id === finalConv.id ? finalConv : c
      );
      setConversations(finalConversations);
      StorageService.saveConversations(finalConversations);

      setTimeout(() => setOrbState("idle"), 3000);
    }
  };

  // Sensitive Confirmation
  const handleSensitiveConfirmation = (type: string, params: Record<string, any>) => {
    let title = "Confirm Action";
    let desc = "Are you sure you want to proceed?";

    if (type === "call") {
      title = `Place Call to ${params.target || "Contact"}?`;
      desc = `Tani will initiate a cellular or VOIP phone call to ${params.target || "the recipient"}.`;
    } else if (type === "email") {
      title = "Send Email?";
      desc = `Tani will compose and dispatch an email with the provided details.`;
    } else if (type === "message") {
      title = "Send Message?";
      desc = `Tani will send an outgoing message with the specified text.`;
    }

    setConfirmation({
      isOpen: true,
      title,
      description: desc,
      confirmLabel: "Proceed",
      cancelLabel: "Cancel",
      onConfirm: () => {
        setConfirmation({ isOpen: false });
        // Execute tool safely
      },
      onCancel: () => setConfirmation({ isOpen: false }),
    });
  };

  const handleActionConfirm = async (messageId: string, confirmed: boolean) => {
    const activeConv = conversations.find((c) => c.id === activeConversationId);
    if (!activeConv) return;

    if (confirmed) {
      const execResult = await TaniBrain.communicationEngine.executePending();
      const updatedMessages: Message[] = activeConv.messages.map((m) => {
        if (m.id === messageId && m.confirmationAction) {
          return {
            ...m,
            confirmationAction: {
              ...m.confirmationAction,
              status: "confirmed" as const,
            },
            toolCall: {
              name: m.confirmationAction.type,
              arguments: m.confirmationAction.payload || {},
              status: "executed" as const,
              result: execResult.message,
            },
          };
        }
        return m;
      });

      const followUpMsg: Message = {
        id: `msg_tani_conf_${Date.now()}`,
        role: "tani",
        content: execResult.message,
        timestamp: Date.now(),
      };
      const allMsgs = [...updatedMessages, followUpMsg];

      const updatedConv: Conversation = {
        ...activeConv,
        messages: allMsgs,
        lastMessage: execResult.message.slice(0, 60),
        timestamp: Date.now(),
      };

      const newConvs = conversations.map((c) => (c.id === updatedConv.id ? updatedConv : c));
      setConversations(newConvs);
      StorageService.saveConversations(newConvs);

      if (preferences.voiceEnabled && preferences.autoSpeak) {
        voiceManager.speak(execResult.message, preferences.voiceSpeed);
      }
    } else {
      TaniBrain.communicationEngine.clearPending();
      const cancelText = "Action cancelled.";
      const updatedMessages: Message[] = activeConv.messages.map((m) => {
        if (m.id === messageId && m.confirmationAction) {
          return {
            ...m,
            confirmationAction: {
              ...m.confirmationAction,
              status: "cancelled" as const,
            },
            toolCall: {
              name: m.confirmationAction.type,
              arguments: m.confirmationAction.payload || {},
              status: "cancelled" as const,
              result: cancelText,
            },
          };
        }
        return m;
      });

      const followUpMsg: Message = {
        id: `msg_tani_cancel_${Date.now()}`,
        role: "tani",
        content: cancelText,
        timestamp: Date.now(),
      };
      const allMsgs = [...updatedMessages, followUpMsg];

      const updatedConv: Conversation = {
        ...activeConv,
        messages: allMsgs,
        lastMessage: cancelText,
        timestamp: Date.now(),
      };

      const newConvs = conversations.map((c) => (c.id === updatedConv.id ? updatedConv : c));
      setConversations(newConvs);
      StorageService.saveConversations(newConvs);

      if (preferences.voiceEnabled && preferences.autoSpeak) {
        voiceManager.speak(cancelText, preferences.voiceSpeed);
      }
    }
  };

  // Voice Controls
  const handleStartVoice = () => {
    setErrorMessage(null);
    setPermissionDenied(false);
    voiceManager.startListening(
      preferences.personality.language,
      preferences.apiKey,
      preferences.userName,
      preferences.continuousVoice
    );
  };

  const handleStopVoice = () => {
    if (continuousSilenceTimerRef.current) {
      clearTimeout(continuousSilenceTimerRef.current);
      continuousSilenceTimerRef.current = null;
    }
    voiceManager.stopListening();
    setOrbState("idle");
  };

  const handleStopSpeaking = () => {
    voiceManager.stopSpeaking();
    setOrbState("idle");
  };

  const handleRetryVoice = () => {
    setErrorMessage(null);
    voiceManager.reconnect();
  };

  const handleToggleContinuousVoice = () => {
    const updated = !preferences.continuousVoice;
    handleUpdatePreferences({ continuousVoice: updated });
    voiceManager.setContinuousMode(updated);
  };

  const handleToggleVoice = () => {
    if (orbState === "listening") {
      handleStopVoice();
    } else if (orbState === "speaking") {
      handleStopSpeaking();
    } else {
      handleStartVoice();
    }
  };

  // Memory operations
  const handleAddMemory = (fact: string) => {
    TaniBrain.memoryManager.addFact(fact);
    setMemories(StorageService.getMemoryNotes());
  };

  const handleDeleteMemory = (index: number) => {
    const list = [...memories];
    list.splice(index, 1);
    StorageService.saveMemoryNotes(list);
    setMemories(list);
  };

  const handleClearMemories = () => {
    StorageService.clearMemory();
    setMemories([]);
  };

  // Clear all app data
  const handleClearAllData = () => {
    setConfirmation({
      isOpen: true,
      title: "Reset All App Data?",
      description:
        "This will permanently remove conversations, tasks, custom keys, and preferences.",
      confirmLabel: "Reset Everything",
      isDestructive: true,
      onConfirm: () => {
        StorageService.clearAllData();
        setConversations([]);
        setTasks([]);
        setAlerts([]);
        setMemories([]);
        setPreferences({
          ...StorageService.getPreferences(),
          userName: "",
          onboardingCompleted: false,
        });
        setConfirmation({ isOpen: false });
        setCurrentTab("home");
      },
      onCancel: () => setConfirmation({ isOpen: false }),
    });
  };

  // Theme styling
  const getThemeBg = () => {
    switch (preferences.theme) {
      case "aurora":
        return "bg-[#061410]";
      case "ocean":
        return "bg-[#050e1c]";
      case "violet":
        return "bg-[#0e0717]";
      case "crimson":
        return "bg-[#14060b]";
      case "emerald":
        return "bg-[#041409]";
      case "midnight":
      default:
        return "bg-[#07090e]";
    }
  };

  const unreadAlertsCount = alerts.filter((a) => !a.read).length;

  // 1. Loading Intro Screen
  if (isLoadingApp) {
    return <LoadingScreen onFinish={() => setIsLoadingApp(false)} />;
  }

  // 2. Onboarding Screen if not completed
  if (!preferences.onboardingCompleted) {
    return (
      <OnboardingScreen
        onComplete={(name) => {
          handleUpdatePreferences({
            userName: name,
            onboardingCompleted: true,
          });
        }}
      />
    );
  }

  // 3. App Lock Screen if locked
  if (isLocked) {
    return (
      <AppLockScreen
        storedPin={preferences.pinCode}
        biometricEnabled={preferences.biometricEnabled}
        onUnlock={() => setIsLocked(false)}
        onResetData={() => {
          handleUpdatePreferences({ appLockEnabled: false, pinCode: "" });
          setIsLocked(false);
        }}
      />
    );
  }

  return (
    <div
      id="tani-app-root"
      className={`relative flex flex-col h-screen w-full ${getThemeBg()} text-white font-sans overflow-hidden select-none transition-colors duration-500`}
    >
      {/* Ambient RGB Edge Lighting Effect */}
      <AmbientGlow
        enabled={preferences.ambientGlowEnabled}
        intensity={preferences.ambientGlowIntensity}
        state={orbState}
        theme={preferences.theme}
      />

      {/* Floating Tani Assistant Button (Quick trigger overlay) */}
      <FloatingAssistant
        enabled={preferences.floatingAssistantEnabled}
        state={orbState}
        onClick={handleToggleVoice}
        theme={preferences.theme}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full flex flex-col overflow-hidden relative z-10">
        {currentTab === "home" && (
          <HomeView
            orbState={orbState}
            userName={preferences.userName}
            profilePhoto={preferences.profilePhoto}
            theme={preferences.theme}
            unreadAlertsCount={unreadAlertsCount}
            continuousVoice={preferences.continuousVoice}
            onToggleContinuousVoice={handleToggleContinuousVoice}
            audioLevel={audioLevel}
            liveTranscript={liveTranscript}
            onSendMessage={handleSendMessage}
            onStartVoice={handleStartVoice}
            onStopVoice={handleStopVoice}
            onStopSpeaking={handleStopSpeaking}
            onOpenMenu={() => setIsMenuOpen(true)}
            onOpenAlerts={() => setIsAlertsOpen(true)}
            onOpenProfile={() => setIsProfileOpen(true)}
            onOpenChat={() => setCurrentTab("chat")}
            onOpenMemory={() => setIsMemoryOpen(true)}
            onOpenSettings={() => setCurrentTab("settings")}
            onStartQuickTimer={(mins) => setActiveTimerSeconds(mins * 60)}
            errorMessage={errorMessage}
            onClearError={() => setErrorMessage(null)}
            permissionDenied={permissionDenied}
            onClosePermissionDialog={() => setPermissionDenied(false)}
            onRetryVoice={handleRetryVoice}
          />
        )}

        {currentTab === "chat" && (
          <div className="flex-1 flex flex-col h-full overflow-hidden">
            {/* Chat View Header */}
            <div className="px-4 py-3 bg-[#0e121d]/90 border-b border-white/10 flex items-center justify-between z-10 backdrop-blur-md">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
                <h2 className="text-sm font-semibold tracking-wide text-white">
                  {activeConversation?.title || "Tani AI Chat"}
                </h2>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCreateNewChat}
                  className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-semibold border border-cyan-500/30 transition-colors cursor-pointer"
                >
                  New Chat
                </button>
              </div>
            </div>

            <ChatView
              messages={messages}
              isLoading={isAiProcessing}
              onRetry={(msgId) => {
                const failed = messages.find((m) => m.id === msgId);
                if (failed) handleSendMessage(failed.content);
              }}
              onRegenerate={() => {
                const lastUser = [...messages].reverse().find((m) => m.role === "user");
                if (lastUser) handleSendMessage(lastUser.content);
              }}
              onSpeak={(text) => {
                voiceManager.speak(text, preferences.voiceSpeed);
              }}
              onActionConfirm={handleActionConfirm}
            />

            {/* In-Chat Minimal Composer */}
            <div className="p-3 bg-[#0d1017]/95 border-t border-white/10">
              <div className="max-w-3xl mx-auto flex items-center gap-2">
                <input
                  id="chat-view-input"
                  type="text"
                  placeholder="Ask Tani anything..."
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && e.currentTarget.value.trim()) {
                      handleSendMessage(e.currentTarget.value.trim());
                      e.currentTarget.value = "";
                    }
                  }}
                  className="flex-1 px-4 py-2.5 rounded-2xl bg-white/[0.07] border border-white/10 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400/60 select-text"
                />
                <button
                  onClick={() => {
                    const input = document.getElementById("chat-view-input") as HTMLInputElement;
                    if (input && input.value.trim()) {
                      handleSendMessage(input.value.trim());
                      input.value = "";
                    }
                  }}
                  className="px-4 py-2.5 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-xs font-semibold text-black shadow-md transition-all cursor-pointer"
                >
                  Send
                </button>
              </div>
            </div>
          </div>
        )}

        {currentTab === "tasks" && (
          <TasksView
            tasks={tasks}
            onClearTasks={() => {
              setTasks([]);
              StorageService.saveTasks([]);
            }}
            onCancelTask={(id) => {
              const updated = tasks.map((t) =>
                t.id === id ? { ...t, status: "cancelled" as const } : t
              );
              setTasks(updated);
              StorageService.saveTasks(updated);
            }}
            onRetryTask={(id) => {
              const task = tasks.find((t) => t.id === id);
              if (task) {
                const updated = tasks.map((t) =>
                  t.id === id ? { ...t, status: "running" as const, progress: 30 } : t
                );
                setTasks(updated);
                StorageService.saveTasks(updated);
              }
            }}
          />
        )}

        {currentTab === "history" && (
          <HistoryView
            conversations={conversations}
            activeId={activeConversationId}
            onSelectConversation={(id) => {
              setActiveConversationId(id);
              setCurrentTab("chat");
            }}
            onRenameConversation={(id, newTitle) => {
              const updated = conversations.map((c) =>
                c.id === id ? { ...c, title: newTitle } : c
              );
              setConversations(updated);
              StorageService.saveConversations(updated);
            }}
            onDeleteConversation={(id) => {
              const updated = conversations.filter((c) => c.id !== id);
              setConversations(updated);
              StorageService.saveConversations(updated);
              if (activeConversationId === id) {
                setActiveConversationId(updated[0]?.id || null);
              }
            }}
            onClearAll={() => {
              setConversations([]);
              StorageService.saveConversations([]);
              setActiveConversationId(null);
            }}
            onNewChat={handleCreateNewChat}
          />
        )}

        {currentTab === "settings" && (
          <SettingsView
            preferences={preferences}
            onUpdatePreferences={handleUpdatePreferences}
            onClearMemory={handleClearMemories}
            onClearAllData={handleClearAllData}
            onOpenAbout={() => setIsAboutOpen(true)}
            onOpenPermissions={() => setCurrentTab("permissions")}
            onOpenAndroidCode={() => setIsAndroidCodeOpen(true)}
          />
        )}

        {currentTab === "permissions" && (
          <PermissionsView onBack={() => setCurrentTab("settings")} />
        )}
      </main>

      {/* Five Bottom Navigation Tabs: Home, Chat, Tasks, History, Settings */}
      <nav
        id="tani-bottom-nav"
        className="w-full bg-[#0b0e17]/95 border-t border-white/10 px-3 py-2 backdrop-blur-xl flex items-center justify-around z-20"
      >
        <button
          onClick={() => setCurrentTab("home")}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all cursor-pointer ${
            currentTab === "home"
              ? "text-cyan-400 font-semibold"
              : "text-gray-400 hover:text-gray-200"
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] tracking-wide">Home</span>
        </button>

        <button
          onClick={() => setCurrentTab("chat")}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all cursor-pointer ${
            currentTab === "chat"
              ? "text-cyan-400 font-semibold"
              : "text-gray-400 hover:text-gray-200"
          }`}
        >
          <MessageSquare className="w-5 h-5" />
          <span className="text-[10px] tracking-wide">Chat</span>
        </button>

        <button
          onClick={() => setCurrentTab("tasks")}
          className={`relative flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all cursor-pointer ${
            currentTab === "tasks"
              ? "text-cyan-400 font-semibold"
              : "text-gray-400 hover:text-gray-200"
          }`}
        >
          <Activity className="w-5 h-5" />
          <span className="text-[10px] tracking-wide">Tasks</span>
          {tasks.some((t) => t.status === "running") && (
            <span className="absolute top-1 right-2 w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          )}
        </button>

        <button
          onClick={() => setCurrentTab("history")}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all cursor-pointer ${
            currentTab === "history"
              ? "text-cyan-400 font-semibold"
              : "text-gray-400 hover:text-gray-200"
          }`}
        >
          <HistoryIcon className="w-5 h-5" />
          <span className="text-[10px] tracking-wide">History</span>
        </button>

        <button
          onClick={() => setCurrentTab("settings")}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all cursor-pointer ${
            currentTab === "settings" || currentTab === "permissions"
              ? "text-cyan-400 font-semibold"
              : "text-gray-400 hover:text-gray-200"
          }`}
        >
          <Settings className="w-5 h-5" />
          <span className="text-[10px] tracking-wide">Settings</span>
        </button>
      </nav>

      {/* Top Bar Drawer: Home, New Chat, Voice Mode, Tasks, History, Memory, Settings, About */}
      <MenuDrawer
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        onNavigate={(tab) => {
          if (tab === "memory") {
            setIsMemoryOpen(true);
          } else {
            setCurrentTab(tab);
          }
        }}
        onNewChat={handleCreateNewChat}
        onVoiceMode={() => {
          setCurrentTab("home");
          handleStartVoice();
        }}
        onOpenAbout={() => setIsAboutOpen(true)}
      />

      {/* Proactive Updates Modal */}
      <AlertsModal
        isOpen={isAlertsOpen}
        onClose={() => setIsAlertsOpen(false)}
        alerts={alerts}
        onClearAll={() => {
          StorageService.saveAlerts([]);
          setAlerts([]);
        }}
        onOpenTasks={() => setCurrentTab("tasks")}
      />

      {/* Personalization & Profile Modal */}
      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        preferences={preferences}
        onUpdatePreferences={handleUpdatePreferences}
      />

      {/* Long-Term Memory Modal */}
      <MemoryModal
        isOpen={isMemoryOpen}
        onClose={() => setIsMemoryOpen(false)}
        memories={memories}
        onAddMemory={handleAddMemory}
        onDeleteMemory={handleDeleteMemory}
        onClearMemories={handleClearMemories}
      />

      {/* Confirmation Dialog for Sensitive Actions */}
      <ConfirmationDialog
        isOpen={confirmation.isOpen}
        title={confirmation.title || "Confirm Action"}
        description={confirmation.description || "Are you sure you want to proceed?"}
        confirmLabel={confirmation.confirmLabel}
        cancelLabel={confirmation.cancelLabel}
        isDestructive={confirmation.isDestructive}
        onConfirm={confirmation.onConfirm || (() => setConfirmation({ isOpen: false }))}
        onCancel={confirmation.onCancel || (() => setConfirmation({ isOpen: false }))}
      />

      {/* About Modal */}
      <AboutModal
        isOpen={isAboutOpen}
        onClose={() => setIsAboutOpen(false)}
        onOpenPermissions={() => {
          setIsAboutOpen(false);
          setCurrentTab("permissions");
        }}
      />

      {/* Android Native Source Code Modal */}
      <AndroidCodeModal
        isOpen={isAndroidCodeOpen}
        onClose={() => setIsAndroidCodeOpen(false)}
      />

      {/* Tani AI Brain V2 Real-Time Conversational Status Panel */}
      <TaniBrainStatusPanel />
    </div>
  );
}
