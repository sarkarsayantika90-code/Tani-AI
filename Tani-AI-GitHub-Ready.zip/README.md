<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/f5f5f09c-2761-4819-833a-b5805986427c

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Tani AI Gemini configuration (updated September 2026)
- Main text/agent model: `gemini-3.8-flash`
- Fallback text model: `gemini-3.6-flash`
- Live voice model: `gemini-3.8-live`
- Gemini 3.8 Flash does not use the legacy `temperature` setting in this project.
- Keep `GEMINI_API_KEY` on the server in production; do not hardcode a key into the app bundle.
