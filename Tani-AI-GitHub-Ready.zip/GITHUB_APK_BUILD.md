# Tani AI — GitHub APK Build

## Phone-only build
1. Create a GitHub repository named `Tani-AI`.
2. Upload the **contents of this project**, not the ZIP itself.
3. Make sure `.github/workflows/build-apk.yml` is present.
4. Commit/push to `main`.
5. Open **Actions → Build Tani AI APK → Run workflow**.
6. When the workflow completes, open the run and download **Tani-AI-debug-apk** from Artifacts.

## Important
The APK packages the Vite frontend. Server endpoints such as `/api/chat` and `/api/live` require a deployed backend URL; they do not run automatically inside a Capacitor APK. Keep Gemini secrets on the backend and configure the app to use that backend before production use.

This workflow creates a debug APK. A Play Store release needs a signing key and release build configuration.
