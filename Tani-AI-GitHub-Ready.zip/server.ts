import express from "express";
import http from "http";
import path from "path";
import { fileURLToPath } from "url";
import { WebSocketServer, WebSocket } from "ws";
import { GoogleGenAI, LiveServerMessage, Modality } from "@google/genai";
import dotenv from "dotenv";
import { GEMINI_MODELS } from "./src/config/GeminiConfig";

dotenv.config();

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true });
const PORT = 3000;

app.use(express.json({ limit: "25mb" }));

// System instructions for Tani AI (Multilingual Conversational Brain V2)
const BASE_TANI_SYSTEM_INSTRUCTION = `You are Tani, a brilliant, warm, fast, and natural multilingual personal AI assistant created by Anik.
Assistant Name: Tani
Creator: Made by Anik
Support: anikmondal8680@gmail.com

Key Rules:
1. Always identify as Tani. Tone: warm, smart, fast, natural, helpful, slightly friendly. Do not overuse "Boss".
2. Multilingual Fluency & Language Lock:
- Native understanding of Bengali (বাংলা), English, Hindi (हिंदी), Banglish (Bengali in Latin alphabet), Hinglish, and mixed speech.
- If the user speaks or writes in Bengali or Banglish (e.g. "তানি আজকে আমার সাথে বাংলায় কথা বলো", "Tani ekta website baniye dao", "weather kemon"), respond warmly and fluently in Bengali. Keep technical terms or app names (e.g., YouTube, Chrome, website, button) natural in English letters or common Bengali transliteration.
- If the user speaks in English (e.g. "Open YouTube", "Can you open Chrome?"), respond cleanly and naturally in English.
- If the user switches language, follow their lead. Never switch language randomly mid-conversation.
3. Turn & Context Awareness:
- Understand follow-up requests in context (e.g., after opening YouTube, "একটা search করো" means search on YouTube; "নিচে scroll করো" or "আরো" means scroll YouTube; "ওটা আবার করো" means repeat the previous action).
- Pronoun resolution: "ওকে" refers to the recently mentioned contact or entity; "buttonটা" refers to the element being discussed.
4. Voice Conciseness:
- For spoken conversation, keep responses short, natural, and conversational (e.g., "YouTube খুলছি।", "Sure, opening YouTube."). Do NOT speak out long boilerplate code or raw markdown.
5. Versatile Excellence:
- Expert at web development (clean HTML/CSS/JS), programming, reasoning, daily scheduling, device control, and creative tasks.`;

// API routes
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    name: "Tani AI",
    creator: "Made by Anik",
    supportEmail: "anikmondal8680@gmail.com",
    hasServerKey: Boolean(process.env.GEMINI_API_KEY)
  });
});

// Test API Key connection
app.post("/api/test-key", async (req, res) => {
  try {
    const userKey = req.body?.apiKey;
    const apiKey = userKey || process.env.GEMINI_API_KEY;

    if (!apiKey) {
      return res.status(400).json({
        success: false,
        error: "No API key provided. Please enter a Gemini API Key."
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });

    // Helper to generate content with fallback on 503 / high demand
    async function generateWithFallback(models: string[], contents: any, systemInstruction: string) {
      let lastError: any = null;
      for (const model of models) {
        for (let attempt = 0; attempt < 2; attempt++) {
          try {
            const resp = await ai.models.generateContent({
              model,
              contents,
              config: {
                systemInstruction
              }
            });
            return resp;
          } catch (err: any) {
            lastError = err;
            const msg = (err?.message || JSON.stringify(err)).toLowerCase();
            const isRetryable =
              msg.includes("503") ||
              msg.includes("unavailable") ||
              msg.includes("high demand") ||
              msg.includes("resource_exhausted") ||
              msg.includes("429") ||
              msg.includes("quota");

            if (!isRetryable) {
              throw err;
            }
            // Wait briefly before retrying or falling back
            await new Promise((resolve) => setTimeout(resolve, 600));
          }
        }
      }
      throw lastError;
    }

    const testResponse = await generateWithFallback(
      [GEMINI_MODELS.TEXT, GEMINI_MODELS.FALLBACK_TEXT],
      "Hello Tani! Respond with exactly: 'Connection verified. Tani AI ready.'",
      "You are Tani AI assistant."
    );

    return res.json({
      success: true,
      message: testResponse.text || "Connection verified. Tani AI ready."
    });
  } catch (error: any) {
    console.error("API test error:", error);
    let readableError = error?.message || "Failed to verify Gemini API key.";
    try {
      const parsed = JSON.parse(readableError);
      if (parsed?.error?.message) readableError = parsed.error.message;
    } catch {
      // not JSON
    }
    if (
      readableError.includes("429") ||
      readableError.toLowerCase().includes("quota") ||
      readableError.toLowerCase().includes("resource_exhausted")
    ) {
      readableError = "Gemini API rate limit reached. Please wait a few seconds and try again.";
    }
    return res.status(400).json({
      success: false,
      error: readableError
    });
  }
});

// Live Chat API with Gemini
app.post("/api/chat", async (req, res) => {
  try {
    const {
      prompt,
      history = [],
      personality = "Assistant",
      language = "auto",
      image,
      apiKey: customKey,
      userName = "User"
    } = req.body;

    const apiKey = customKey || process.env.GEMINI_API_KEY;

    if (!apiKey) {
      return res.status(400).json({
        error: "NO_API_KEY",
        message: "Gemini API key is not configured. Please add your key in AI API Setup or set GEMINI_API_KEY."
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });

    // Custom system instruction tuned for personality
    let personalityPrompt = `Active Personality Mode: ${personality}.`;
    if (personality === "Friend") {
      personalityPrompt += " Be warm, cheerful, enthusiastic, and supportive like a trusted companion.";
    } else if (personality === "Study") {
      personalityPrompt += " Be pedagogically clear, breaking complex concepts down with step-by-step reasoning and intuitive examples.";
    } else if (personality === "Coding") {
      personalityPrompt += " Prioritize clean, modern, secure, and production-ready code with concise explanations and best practices.";
    } else if (personality === "Custom") {
      personalityPrompt += " Be flexible, ultra-precise, and adapt quickly to the user's style.";
    } else {
      personalityPrompt += " Be polished, efficient, highly intelligent, and proactive.";
    }

    const fullSystemInstruction = `${BASE_TANI_SYSTEM_INSTRUCTION}
${personalityPrompt}
The user's preferred name is "${userName}".
Preferred language setting: "${language}". If set to auto, reply in the same language the user spoke (Bengali, Hindi, English, etc.).`;

    // Construct contents
    const contents: any[] = [];

    // Append past history context if available
    for (const msg of history.slice(-8)) {
      if (msg.role === "user" || msg.role === "model") {
        contents.push({
          role: msg.role === "user" ? "user" : "model",
          parts: [{ text: msg.content }]
        });
      }
    }

    // Build current turn parts
    const currentTurnParts: any[] = [];
    if (image && image.data && image.mimeType) {
      currentTurnParts.push({
        inlineData: {
          data: image.data,
          mimeType: image.mimeType
        }
      });
    }

    currentTurnParts.push({ text: prompt });
    contents.push({
      role: "user",
      parts: currentTurnParts
    });

    // Execute generation with fallback for 503 high demand or 429 quota spikes
    const candidateModels = [GEMINI_MODELS.TEXT, GEMINI_MODELS.FALLBACK_TEXT];
    let response: any = null;
    let lastError: any = null;

    for (const model of candidateModels) {
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          response = await ai.models.generateContent({
            model,
            contents,
            config: {
              systemInstruction: fullSystemInstruction
            }
          });
          if (response) break;
        } catch (err: any) {
          lastError = err;
          const msg = (err?.message || JSON.stringify(err)).toLowerCase();
          const isRetryable =
            msg.includes("503") ||
            msg.includes("unavailable") ||
            msg.includes("high demand") ||
            msg.includes("resource_exhausted") ||
            msg.includes("429") ||
            msg.includes("quota");

          if (!isRetryable) {
            throw err;
          }
          await new Promise((resolve) => setTimeout(resolve, 600));
        }
      }
      if (response) break;
    }

    if (!response && lastError) {
      throw lastError;
    }

    const text = response?.text || "I'm here to help you.";
    res.json({
      text,
      success: true
    });
  } catch (error: any) {
    console.error("Chat error:", error);
    let readableMessage = error?.message || "Failed to generate response.";
    try {
      const parsed = JSON.parse(readableMessage);
      if (parsed?.error?.message) {
        readableMessage = parsed.error.message;
      }
    } catch {
      // not JSON
    }

    if (
      readableMessage.includes("503") ||
      readableMessage.toLowerCase().includes("high demand") ||
      readableMessage.toLowerCase().includes("unavailable")
    ) {
      readableMessage = "The AI model is experiencing temporarily high demand. Please try sending your message again in a few seconds.";
    } else if (
      readableMessage.includes("429") ||
      readableMessage.toLowerCase().includes("quota") ||
      readableMessage.toLowerCase().includes("resource_exhausted")
    ) {
      readableMessage = "Gemini API request rate limit reached. Please wait a few moments and try again.";
    }

    res.status(500).json({
      error: "GENERATION_FAILED",
      message: readableMessage
    });
  }
});

// Real Weather endpoint using Open-Meteo
app.get("/api/weather", async (req, res) => {
  try {
    const lat = req.query.lat || "22.5726"; // Default Kolkata / Bengal coords if not specified
    const lon = req.query.lon || "88.3639";
    const city = req.query.city || "Current Location";

    const response = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&hourly=temperature_2m,relativehumidity_2m,windspeed_10m`
    );

    if (!response.ok) {
      throw new Error("Weather service returned error");
    }

    const data = await response.json();
    const current = data.current_weather;

    res.json({
      city,
      temperature: current?.temperature ?? 28,
      windSpeed: current?.windspeed ?? 12,
      weatherCode: current?.weathercode ?? 0,
      time: current?.time,
      isDay: current?.is_day === 1,
      source: "Open-Meteo Live API"
    });
  } catch (err: any) {
    res.status(500).json({
      error: "WEATHER_UNAVAILABLE",
      message: err?.message || "Weather service is not configured or reachable yet."
    });
  }
});

// Gemini Live WebSocket Bridge (gemini-3.8-live)
wss.on("connection", (clientWs) => {
  let liveSession: any = null;
  let isClosed = false;

  clientWs.on("message", async (rawData) => {
    try {
      const dataStr = rawData.toString();
      const msg = JSON.parse(dataStr);

      if (msg.type === "init") {
        const apiKey = msg.apiKey || process.env.GEMINI_API_KEY;
        if (!apiKey) {
          clientWs.send(JSON.stringify({
            type: "error",
            error: "NO_API_KEY",
            message: "Gemini API key is not configured. Please add your key or set GEMINI_API_KEY."
          }));
          return;
        }

        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: {
            headers: {
              "User-Agent": "aistudio-build",
            },
          },
        });

        const personality = msg.personality || "Assistant";
        const language = msg.language || "auto";
        const userName = msg.userName || "User";
        const voiceName = msg.voiceName || "Aoede";

        const liveSystemInstruction = `${BASE_TANI_SYSTEM_INSTRUCTION}
Active Personality: ${personality}.
User name: "${userName}".
Preferred language: "${language}". If set to auto, speak in the language the user speaks to you (Bengali, English, Hindi, Hinglish).
Voice Response Rules:
- Answer naturally, conversationally, concisely, and warmly.
- Avoid very long spoken answers unless explicitly requested.
- Avoid markdown symbols or code syntax in spoken output.
- If the user asks for code, website creation, or tool actions, acknowledge naturally that you are doing it.`;

        // Connect to gemini-3.8-live session (NO thinking_config or thinking_level!)
        liveSession = await ai.live.connect({
          model: GEMINI_MODELS.LIVE,
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName,
                },
              },
            },
            systemInstruction: liveSystemInstruction,
            outputAudioTranscription: {},
            inputAudioTranscription: {},
          },
          callbacks: {
            onopen: () => {
              if (clientWs.readyState === WebSocket.OPEN) {
                clientWs.send(JSON.stringify({ type: "ready" }));
              }
            },
            onmessage: (serverMessage: LiveServerMessage) => {
              if (clientWs.readyState !== WebSocket.OPEN) return;

              // 1. Audio data from Gemini (24kHz PCM base64)
              const parts = serverMessage.serverContent?.modelTurn?.parts;
              if (parts && parts.length > 0) {
                for (const part of parts) {
                  if (part.inlineData?.data) {
                    clientWs.send(JSON.stringify({
                      type: "audio",
                      audio: part.inlineData.data,
                    }));
                  }
                  if (part.text) {
                    clientWs.send(JSON.stringify({
                      type: "modelTranscript",
                      text: part.text,
                    }));
                  }
                }
              }

              // 2. Interruption notice from Gemini
              if (serverMessage.serverContent?.interrupted) {
                clientWs.send(JSON.stringify({ type: "interrupted" }));
              }

              // 3. Turn complete
              if ((serverMessage.serverContent as any)?.turnComplete) {
                clientWs.send(JSON.stringify({ type: "turnComplete" }));
              }
            },
            onerror: (err: any) => {
              console.error("Gemini Live session error:", err);
              if (clientWs.readyState === WebSocket.OPEN) {
                let readable = err?.message || "Tani voice session encountered an issue.";
                if (readable.includes("503") || readable.toLowerCase().includes("high demand")) {
                  readable = "Tani voice is experiencing high network demand. Please try again.";
                }
                clientWs.send(JSON.stringify({
                  type: "error",
                  error: readable,
                }));
              }
            },
            onclose: () => {
              if (!isClosed && clientWs.readyState === WebSocket.OPEN) {
                clientWs.send(JSON.stringify({ type: "sessionClosed" }));
              }
            },
          },
        });

        if (clientWs.readyState === WebSocket.OPEN) {
          clientWs.send(JSON.stringify({ type: "connected" }));
        }
      } else if (msg.type === "audio" && msg.audio) {
        if (liveSession) {
          liveSession.sendRealtimeInput({
            audio: {
              data: msg.audio,
              mimeType: "audio/pcm;rate=16000",
            },
          });
        }
      } else if (msg.type === "text" && msg.text) {
        if (liveSession) {
          liveSession.sendRealtimeInput({
            text: msg.text,
          });
        }
      } else if (msg.type === "interrupt") {
        // Interruption handled
      }
    } catch (err: any) {
      console.error("WebSocket message handling error:", err);
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(JSON.stringify({
          type: "error",
          error: err?.message || "Failed to process voice message.",
        }));
      }
    }
  });

  clientWs.on("close", () => {
    isClosed = true;
    if (liveSession) {
      try {
        liveSession.close();
      } catch {
        // ignore
      }
      liveSession = null;
    }
  });
});

// Upgrade HTTP connection to WebSocket for /api/live
server.on("upgrade", (request, socket, head) => {
  const url = new URL(request.url || "", `http://${request.headers.host || "localhost"}`);
  if (url.pathname === "/api/live") {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit("connection", ws, request);
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Tani AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
