# Tani AI — Fix Pass

This package contains the source-level fix pass for Tani AI.

## Fixed
- Removed legacy Gemini model references from the project.
- Centralized Gemini models: `gemini-3.8-flash`, fallback `gemini-3.6-flash`, Live `gemini-3.8-live`.
- Kept voice/live routing on the Live model.
- Added missing Android Gradle version catalog and basic Android resources.
- Fixed generated Android package namespace/applicationId to `com.anik.tani`.
- Added missing boot receiver, theme, strings, backup rules and ProGuard file.
- Added a functional minimal native MainActivity so the generated Android project is not an empty Compose shell.
- Updated the Android code modal package label.

## Verification limitation
The environment could not complete `npm install` within the available execution window, so a full TypeScript/Vite production build and Android Gradle build could not be executed here. The ZIP should therefore be treated as a corrected source package, not as a claim that a release APK has already been compiled and signed.

## API key
For deployment, prefer the server `GEMINI_API_KEY` secret. If users enter a personal key in the UI, that key is intentionally passed to the backend for that session; do not ship a shared private API key inside a public APK.
